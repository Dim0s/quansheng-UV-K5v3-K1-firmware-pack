'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const test = require('node:test');

const catalog = require('../js/flash-catalog.js');
const {
  parseFirmwareName,
  compareVersionDesc,
  categorize,
  formatOptionLabel,
  hasSharedChirpDriver,
  isOffered,
  isSlotOffered
} = catalog;

// Real filenames from armel/uv-k1-k5v3-firmware-custom/archive.
const SAMPLE = [
  { name: 'f4hwn.fusion.development.bin', size: 104000, download_url: 'https://x/f4hwn.fusion.development.bin' },
  { name: 'f4hwn.fusion.v5.7.0.bin', size: 85708, download_url: 'https://x/f4hwn.fusion.v5.7.0.bin' },
  { name: 'f4hwn.fusion.v5.7.0.sa818.bin', size: 85708, download_url: 'https://x/f4hwn.fusion.v5.7.0.sa818.bin' },
  { name: 'f4hwn.fusion.v5.0.1.beta.bin', size: 84304, download_url: 'https://x/f4hwn.fusion.v5.0.1.beta.bin' },
  { name: 'f4hwn.fusion.v5.10.0.bin', size: 86000, download_url: 'https://x/f4hwn.fusion.v5.10.0.bin' },
  { name: 'f4hwn.fieldops.v6.0.0.bin', size: 85000, download_url: 'https://x/f4hwn.fieldops.v6.0.0.bin' },
  { name: 'f4hwn.transfer.v6.0.0.bin', size: 85000, download_url: 'https://x/f4hwn.transfer.v6.0.0.bin' },
  { name: 'f4hwn.labs.v6.0.0.bin', size: 85000, download_url: 'https://x/f4hwn.labs.v6.0.0.bin' },
  { name: 'f4hwn.max.v6.0.0.bin', size: 85000, download_url: 'https://x/f4hwn.max.v6.0.0.bin' },
  { name: 'f4hwn.k1.fusion.v4.3.2.bin', size: 84000, download_url: 'https://x/f4hwn.k1.fusion.v4.3.2.bin' },
  { name: 'f4hwn.k5v3.fusion.v4.3.bin', size: 84000, download_url: 'https://x/f4hwn.k5v3.fusion.v4.3.bin' },
  { name: 'quansheng.k1.stock.firmware.v7.03.01.bin', size: 62000, download_url: 'https://x/quansheng.k1.stock.firmware.v7.03.01.bin' },
  { name: 'quansheng.k5v3.stock.firmware.v7.00.11.bin', size: 62000, download_url: 'https://x/quansheng.k5v3.stock.firmware.v7.00.11.bin' },
  { name: 'f4hwn.logo.v1.png', size: 1024, download_url: 'https://x/f4hwn.logo.v1.png' },
  { name: 'quansheng.stock.logo.png', size: 1024, download_url: 'https://x/quansheng.stock.logo.png' }
];

test('ignores non-F4HWN files such as boot logos and stock images', () => {
  assert.equal(parseFirmwareName('f4hwn.logo.v1.png'), null);
  assert.equal(parseFirmwareName('quansheng.stock.logo.png'), null);
  assert.equal(parseFirmwareName('quansheng.k1.stock.firmware.v7.03.01.bin'), null);
  assert.equal(parseFirmwareName('quansheng.k5v3.stock.firmware.v7.00.11.bin'), null);
  assert.equal(parseFirmwareName(null), null);
});

test('classifies the general Fusion line and its variants', () => {
  assert.deepEqual(parseFirmwareName('f4hwn.fusion.v5.7.0.bin'), {
    name: 'f4hwn.fusion.v5.7.0.bin', group: 'fusion', model: '',
    version: '5.7.0', isBeta: false, isSa818: false
  });
  assert.equal(parseFirmwareName('f4hwn.fusion.v5.0.1.beta.bin').isBeta, true);
  assert.equal(parseFirmwareName('f4hwn.fusion.v5.7.0.sa818.bin').isSa818, true);
});

test('never offers the unversioned rolling Fusion development build', () => {
  const development = parseFirmwareName('f4hwn.fusion.development.bin');
  assert.equal(development.version, '');
  assert.equal(isOffered(development), false);
  assert.equal(isSlotOffered(development), false);
  assert.equal(hasSharedChirpDriver(development), false);
});

test('reads only the stable archive listing', () => {
  const source = fs.readFileSync(require.resolve('../js/flash-catalog.js'), 'utf8');
  assert.doesNotMatch(source, /feature_update_v\d/);
  assert.doesNotMatch(source, /fusion\.development\.bin/);
});

test('routes model-specific firmwares to their groups', () => {
  assert.equal(parseFirmwareName('f4hwn.k1.fusion.v4.3.2.bin').group, 'fusion_k1');
  assert.equal(parseFirmwareName('f4hwn.k1.fusion.v4.3.2.bin').model, 'K1');
  assert.equal(parseFirmwareName('f4hwn.k5v3.fusion.v4.3.bin').group, 'fusion_k5v3');
  assert.equal(parseFirmwareName('f4hwn.k5v3.fusion.v4.3.bin').model, 'K5v3');
});

test('routes each stable F4HWN edition to its own catalog section', () => {
  assert.equal(parseFirmwareName('f4hwn.fusion.v5.8.0.bin').group, 'fusion');
  assert.equal(parseFirmwareName('f4hwn.fieldops.v6.0.0.bin').group, 'fieldops');
  assert.equal(parseFirmwareName('f4hwn.transfer.v6.0.0.bin').group, 'transfer');
  assert.equal(parseFirmwareName('f4hwn.labs.v6.0.0.bin').group, 'labs');
  assert.equal(parseFirmwareName('f4hwn.max.v6.0.0.bin').group, 'max');
});

test('sorts versions numerically, not alphabetically', () => {
  assert.ok(compareVersionDesc('5.10.0', '5.9.0') < 0);  // 5.10 is newer
  assert.ok(compareVersionDesc('5.9.0', '5.10.0') > 0);
  assert.equal(compareVersionDesc('4.3', '4.3.0'), 0);
});

test('offers only current stable builds: v5+ without beta or SA818', () => {
  assert.equal(isOffered(parseFirmwareName('f4hwn.fusion.v5.7.0.bin')), true);
  assert.equal(isOffered(parseFirmwareName('f4hwn.fusion.v5.0.1.beta.bin')), false); // beta
  assert.equal(isOffered(parseFirmwareName('f4hwn.fusion.v5.7.0.sa818.bin')), false); // SA818
  assert.equal(isOffered(parseFirmwareName('f4hwn.k1.fusion.v4.3.2.bin')), false); // legacy < 5
});

test('offers every stable F4HWN edition in the multiboot slot picker', () => {
  assert.equal(isSlotOffered(parseFirmwareName('f4hwn.fusion.v6.0.0.bin')), true);
  assert.equal(isSlotOffered(parseFirmwareName('f4hwn.fieldops.v6.0.0.bin')), true);
  assert.equal(isSlotOffered(parseFirmwareName('f4hwn.transfer.v6.0.0.bin')), true);
  assert.equal(isSlotOffered(parseFirmwareName('f4hwn.labs.v6.0.0.bin')), true);
  assert.equal(isSlotOffered(parseFirmwareName('f4hwn.fusion.v5.9.0.bin')), false);
});

test('shares one versioned CHIRP driver across every offered stable F4HWN edition', () => {
  for (const edition of ['fusion', 'fieldops', 'transfer', 'labs']) {
    assert.equal(hasSharedChirpDriver(parseFirmwareName(`f4hwn.${edition}.v6.0.0.bin`)), true);
  }
  assert.equal(hasSharedChirpDriver(parseFirmwareName('f4hwn.fieldops.v6.0.0.beta.bin')), false);
  assert.equal(hasSharedChirpDriver(parseFirmwareName('quansheng.k1.stock.firmware.v7.03.01.bin')), false);
  assert.equal(hasSharedChirpDriver(null), false);
});

test('groups offered entries newest-first and drops everything else', () => {
  const groups = categorize(SAMPLE);
  assert.deepEqual([...groups.keys()], [
    'fusion', 'fieldops', 'transfer', 'labs', 'fusion_k1', 'fusion_k5v3'
  ]);

  const fusion = groups.get('fusion');
  // Newest first: v5.10.0 must precede v5.7.0 despite the string order.
  assert.equal(fusion[0].version, '5.10.0');
  // Only stable v5+ remain: v5.10.0 and v5.7.0 (development, beta, sa818 and
  // legacy dropped).
  assert.deepEqual(fusion.map(e => e.version), ['5.10.0', '5.7.0']);
  assert.deepEqual(groups.get('fieldops').map(e => e.version), ['6.0.0']);
  assert.deepEqual(groups.get('transfer').map(e => e.version), ['6.0.0']);
  assert.deepEqual(groups.get('labs').map(e => e.version), ['6.0.0']);
  assert.equal(groups.has('max'), false);
  // Legacy v4.3 model-specific lines are filtered out entirely.
  assert.equal(groups.get('fusion_k1').length, 0);
  assert.equal(groups.get('fusion_k5v3').length, 0);
  // Neither the rolling development build nor stock images get a section.
  assert.equal(groups.has('development'), false);
  assert.equal(groups.has('stock'), false);
  const names = [...groups.values()].flat().map(e => e.name);
  assert.ok(!names.includes('f4hwn.fusion.development.bin'));
  assert.ok(!names.some(name => name.startsWith('quansheng')));
});

test('formats compact, human option labels', () => {
  const fusion = { group: 'fusion', model: '', version: '5.7.0', size: 59542 };
  assert.match(formatOptionLabel(fusion), /^v5\.7\.0 · \d+ KB$/);
});
