// Firmware catalog: lists stable F4HWN archive/ files from the main branch
// through the GitHub Contents API. Selected builds feed into either the main
// flash pipeline or the multiboot-slot pipeline through window.UVStudioFlash. Pure helpers are exported
// for Node tests; the browser runtime is guarded and self-boots.
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.UVStudioFlashCatalog = api;

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => api.boot());
    } else {
      api.boot();
    }
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const REPO = 'armel/uv-k1-k5v3-firmware-custom';
  const ARCHIVE_PATH = 'archive';
  // main, or the development branch when the hidden developer switch is on.
  const STABLE_BRANCH = (typeof globalThis !== 'undefined' && globalThis.UVStudioPreferences &&
    typeof globalThis.UVStudioPreferences.catalogBranch === 'function')
    ? globalThis.UVStudioPreferences.catalogBranch()
    : 'main';
  const API_URL =
    `https://api.github.com/repos/${REPO}/contents/${ARCHIVE_PATH}` +
    `?ref=${encodeURIComponent(STABLE_BRANCH)}`;
  // Only current firmwares are offered: v5.0 and newer, no beta or SA818 builds.
  // Unversioned images (such as a rolling development build) are never offered.
  const MIN_MAJOR_VERSION = 5;
  // Multiboot first ships with v6; older images cannot return to the slot menu.
  const MIN_SLOT_MAJOR_VERSION = 6;

  // Group labels are technical terms shared across every language.
  const GROUP_ORDER = [
    'fusion', 'service', 'fieldops', 'transfer', 'labs', 'fusion_k1', 'fusion_k5v3'
  ];
  const GROUP_LABELS = {
    fusion: 'F4HWN Fusion (stable)',
    service: 'F4HWN Service',
    fieldops: 'F4HWN FieldOps',
    transfer: 'F4HWN Transfer',
    labs: 'F4HWN Labs',
    fusion_k1: 'F4HWN Fusion · K1',
    fusion_k5v3: 'F4HWN Fusion · K5v3'
  };

  // ========== PURE HELPERS (Node-testable) ==========

  // Parse an F4HWN archive filename into a structured entry, or null when the
  // file is not an F4HWN firmware image (logos, stock images and other assets
  // are ignored).
  function parseFirmwareName(name) {
    if (typeof name !== 'string') return null;
    const lower = name.toLowerCase();
    const editionMatch = lower.match(
      /^f4hwn[._-](?:(k1|k5v3)[._-])?([a-z][a-z0-9-]*)(?:[._-].*)?\.bin$/
    );
    if (!editionMatch) return null;

    const isBeta = /\.beta\b/.test(lower);
    const isSa818 = /\.sa818\b/.test(lower);
    const versionMatch = lower.match(/[._-]v(\d+(?:\.\d+)*)/);
    const version = versionMatch ? versionMatch[1] : '';

    const modelToken = editionMatch[1] || '';
    const editionToken = editionMatch[2];
    const model = modelToken === 'k1' ? 'K1' : (modelToken === 'k5v3' ? 'K5v3' : '');
    const group = model && editionToken === 'fusion' ? `fusion_${modelToken}` : editionToken;

    return { name, group, model, version, isBeta, isSa818 };
  }

  // Descending semantic comparison so v5.10.0 correctly outranks v5.9.0.
  function compareVersionDesc(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const da = pa[i] || 0;
      const db = pb[i] || 0;
      if (da !== db) return db - da;
    }
    return 0;
  }

  function majorVersion(version) {
    const major = parseInt(String(version).split('.')[0], 10);
    return Number.isFinite(major) ? major : -1;
  }

  // Keep only current, stable, non-SA818 firmware images (v5.0 and newer).
  function isOffered(entry) {
    return Boolean(entry) && !entry.isBeta && !entry.isSa818 &&
      majorVersion(entry.version) >= MIN_MAJOR_VERSION;
  }

  // Multiboot slots offer stable v6+ F4HWN editions; older images do not embed
  // multiboot.
  function isSlotOffered(entry) {
    return isOffered(entry) && majorVersion(entry.version) >= MIN_SLOT_MAJOR_VERSION;
  }

  // Every offered F4HWN edition shares the CHIRP driver published for that
  // firmware version.
  function hasSharedChirpDriver(entry) {
    return isOffered(entry);
  }

  // Group GitHub file entries ({ name, size, download_url }) into an ordered map
  // of firmware families, newest version first within each family.
  function categorize(files) {
    const groups = new Map();
    GROUP_ORDER.forEach(id => groups.set(id, []));

    (Array.isArray(files) ? files : []).forEach(file => {
      const parsed = parseFirmwareName(file && file.name);
      if (!parsed || !groups.has(parsed.group) || !isOffered(parsed)) return;
      groups.get(parsed.group).push(Object.assign(parsed, {
        size: file.size,
        url: file.download_url
      }));
    });

    groups.forEach(list => list.sort((a, b) => compareVersionDesc(a.version, b.version)));
    return groups;
  }

  // Compact option label, e.g. "v5.7.0 · 58 KB".
  function formatOptionLabel(entry) {
    let label = entry.version ? `v${entry.version}` : entry.name;
    if (Number.isFinite(entry.size)) label += ` · ${Math.round(entry.size / 1024)} KB`;
    return label;
  }

  const pureApi = {
    parseFirmwareName,
    compareVersionDesc,
    categorize,
    formatOptionLabel,
    hasSharedChirpDriver,
    isOffered,
    isSlotOffered
  };

  // ========== BROWSER RUNTIME ==========

  function boot() {
    const select = document.getElementById('firmwareCatalogSelect');
    const section = document.getElementById('firmwareCatalogSection');
    const divider = document.getElementById('firmwareCatalogOr');
    const slotSelect = document.getElementById('slotFirmwareCatalogSelect');
    const slotSection = document.getElementById('slotFirmwareCatalogSection');
    const slotDivider = document.getElementById('slotFirmwareCatalogOr');
    const selects = [select, slotSelect].filter(Boolean);
    if (!selects.length) return; // Catalog markup absent.

    // Purge the obsolete persistent listing cache written by earlier versions.
    if (window.UVStudioPreferences) {
      try { window.UVStudioPreferences.remove('uvstudio.firmwareCatalog'); } catch (e) {}
    }

    // Kept only in memory for the lifetime of the page. When the listing cannot be
    // fetched (no connection), the whole picker stays hidden and only the local
    // file input remains — exactly the pre-catalog experience.
    let groups = null;
    let loaded = false;
    let loading = false;
    let retryUntil = 0; // epoch ms before which we must not re-hit a rate-limited API

    function t(key) {
      return window.uvStudioI18n ? window.uvStudioI18n.t(key) : key;
    }

    function showCatalog(flashVisible, slotVisible = flashVisible) {
      if (section) section.hidden = !flashVisible;
      if (divider) divider.hidden = !flashVisible;
      if (slotSection) slotSection.hidden = !slotVisible;
      if (slotDivider) slotDivider.hidden = !slotVisible;
    }

    // Build the menu and return how many firmware options it holds.
    function renderSelect(targetSelect, entryFilter = () => true) {
      const previous = targetSelect.value;
      targetSelect.textContent = '';

      const placeholder = document.createElement('option');
      placeholder.value = '';
      placeholder.textContent = t('flash_catalog_placeholder');
      placeholder.disabled = true;
      placeholder.selected = true;
      targetSelect.appendChild(placeholder);

      let optionCount = 0;
      GROUP_ORDER.forEach(id => {
        const entries = (groups.get(id) || []).filter(entryFilter);
        if (!entries.length) return;

        const optgroup = document.createElement('optgroup');
        optgroup.label = GROUP_LABELS[id];
        entries.forEach(entry => {
          const option = document.createElement('option');
          option.value = entry.url;
          option.textContent = formatOptionLabel(entry);
          optgroup.appendChild(option);
          optionCount += 1;
        });
        targetSelect.appendChild(optgroup);
      });

      // Preserve the current choice across a re-render (e.g. language change).
      if (previous && targetSelect.querySelector(`option[value="${CSS.escape(previous)}"]`)) {
        targetSelect.value = previous;
      }
      return optionCount;
    }

    function render() {
      if (!groups) return { flash: 0, slots: 0 };
      return {
        flash: select ? renderSelect(select) : 0,
        slots: slotSelect ? renderSelect(slotSelect, isSlotOffered) : 0
      };
    }

    async function load() {
      if (loading || loaded || Date.now() < retryUntil) return;
      loading = true;
      try {
        const response = await fetch(API_URL, { cache: 'no-cache' });
        if (!response.ok) {
          // Rate limited: back off until GitHub's window resets so we stop
          // hammering the API on every Flash-view open.
          const remaining = response.headers.get('x-ratelimit-remaining');
          const reset = Number(response.headers.get('x-ratelimit-reset'));
          if ((response.status === 403 || response.status === 429) && remaining === '0' && reset) {
            retryUntil = reset * 1000;
          }
          throw new Error(`HTTP ${response.status}`);
        }
        groups = categorize(await response.json());
        const counts = render();
        showCatalog(counts.flash > 0, counts.slots > 0);
        loaded = counts.flash > 0 || counts.slots > 0;
        const slotEntries = [];
        groups.forEach(entries => {
          const latest = entries.find(entry => isSlotOffered(entry) && !entry.model);
          if (latest) slotEntries.push(latest);
        });
        window.dispatchEvent(new CustomEvent('uvstudio:slotcatalogversions', {
          detail: { entries: slotEntries }
        }));
      } catch (error) {
        // No connection, or the API is unreachable / rate limited: keep the whole
        // picker hidden so only the local-file input remains — same as offline.
        // loaded stays false, so reopening the view (or coming back online, once
        // any rate-limit window has passed) retries the fetch.
        groups = null;
        showCatalog(false, false);
      } finally {
        loading = false;
      }
    }

    if (select) {
      select.addEventListener('change', () => {
        const url = select.value;
        if (!url) return;
        const flash = window.UVStudioFlash;
        if (flash && typeof flash.loadFirmwareFromURL === 'function') {
          flash.loadFirmwareFromURL(url);
        }
      });
    }

    if (slotSelect) {
      slotSelect.addEventListener('change', () => {
        const url = slotSelect.value;
        if (!url) return;
        const flash = window.UVStudioFlash;
        if (flash && typeof flash.loadSlotFirmwareFromURL === 'function') {
          flash.loadSlotFirmwareFromURL(url);
        }
      });
    }

    // Re-localize the placeholder and option groups when the language changes.
    window.addEventListener('uvstudio:languagechange', () => {
      if (groups) render();
    });

    // Mutual exclusivity: when a local file is picked, drop the catalog selection
    // back to its placeholder so only one firmware source ever looks selected.
    window.addEventListener('uvstudio:firmwareselect', event => {
      if (select && event.detail && event.detail.source === 'local' && select.options.length) {
        select.selectedIndex = 0;
      }
    });

    window.addEventListener('uvstudio:slotfirmwareselect', event => {
      if (slotSelect && event.detail && event.detail.source === 'local' && slotSelect.options.length) {
        slotSelect.selectedIndex = 0;
      }
    });

    // Lazily fetch the shared catalog the first time either firmware view is
    // opened, so users who never manage firmware do not spend a GitHub API call.
    window.addEventListener('uvstudio:toolviewchange', event => {
      if (event.detail && (event.detail.view === 'flash' || event.detail.view === 'slots')) load();
    });

    // Retry once connectivity comes back after a failed load.
    window.addEventListener('online', () => { if (!loaded) load(); });

    // Load immediately only when one of the firmware views is actually shown on
    // arrival (flash-content is "active" by default, so also require the tools pane
    // to be visible — otherwise Live Viewer users would trigger a needless call).
    const paneTools = document.getElementById('pane-tools');
    const flashView = document.getElementById('flash-content');
    const slotsView = document.getElementById('slots-content');
    if (paneTools && paneTools.classList.contains('active') &&
        ((flashView && flashView.classList.contains('active')) ||
         (slotsView && slotsView.classList.contains('active')))) {
      load();
    }
  }

  return Object.assign({}, pureApi, { boot });
});
