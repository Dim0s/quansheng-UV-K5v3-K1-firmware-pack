;(function(){
// js/flash.js
// UV-K5 Web Flasher core logic (Web Serial + protocol)
// Adds: 
// - Auto-load of firmware from URL param ?firmwareURL=... (or ?fw=...)
// - Uses the shared UV Studio i18n runtime (window.uvStudioI18n).
// - Refreshes dynamic tool labels after the shared language changes.
// - Shows progress bar during flashing, hides it after successful completion.
// - Percentage text is centered via #progressLabel overlay.
// - Dump and restore
// - RF Log CSV export

'use strict';

// ========== CONSTANTS ==========
const BAUDRATE = 38400;

// Message types
const MSG_NOTIFY_DEV_INFO = 0x0518;
const MSG_NOTIFY_BL_VER = 0x0530;
const MSG_PROG_FW = 0x0519;
const MSG_PROG_FW_RESP = 0x051A;
const MSG_DEV_INFO_REQ = 0x0514;
const MSG_DEV_INFO_RESP = 0x0515;
const MSG_READ_EEPROM = 0x051B;
const MSG_READ_EEPROM_RESP = 0x051C;
const MSG_WRITE_EEPROM = 0x051D;
const MSG_WRITE_EEPROM_RESP = 0x051E;
const MSG_REBOOT = 0x05DD;

const OBFUS_TBL = new Uint8Array([
  0x16, 0x6c, 0x14, 0xe6, 0x2e, 0x91, 0x0d, 0x40,
  0x21, 0x35, 0xd5, 0x40, 0x13, 0x03, 0xe9, 0x80
]);

// Calibration memory layout
const CALIB_SIZE = 512; // bytes
const CHUNK_SIZE = 16;
let CALIB_OFFSET = 0x1E00; // Default for firmware < v5.0.0

// Boot logo memory layout (mirrors firmware App/ui/welcome.c)
// Layout in flash sector starting at PY25Q16 0x011000, exposed via EEPROM
// compat at 0x00C000:
//   [0x00..0x07] 8-byte magic header "F4HWNLGO"
//   [0x08..0x407] 1024-byte bitmap, ST7565-native column-major LSB-top
const LOGO_EEPROM_OFFSET = 0xC000;
const LOGO_HEADER_SIZE = 8;
const LOGO_BITMAP_SIZE = 1024;
const LOGO_TOTAL_SIZE = LOGO_HEADER_SIZE + LOGO_BITMAP_SIZE; // 1032
// Padded to a CHUNK_SIZE multiple so we can stream by 16-byte chunks like calib.
const LOGO_PADDED_SIZE = Math.ceil(LOGO_TOTAL_SIZE / CHUNK_SIZE) * CHUNK_SIZE; // 1040
const LOGO_MAGIC = new Uint8Array([0x46, 0x34, 0x48, 0x57, 0x4E, 0x4C, 0x47, 0x4F]); // "F4HWNLGO"
const LOGO_WIDTH = 128;
const LOGO_HEIGHT = 64;

// RF Log export timings. History pages are emitted by the firmware at most
// once per display/update cycle, normally every 500 ms.
const RF_LOG_KEEPALIVE_INTERVAL_MS = 200;
const RF_LOG_INITIAL_TIMEOUT_MS = 5000;
const RF_LOG_HISTORY_IDLE_MS = 1500;
const RF_LOG_EXPORT_TIMEOUT_MS = 20000;

// ========== STATE ==========
let port = null;
let reader = null;
let writer = null;
let firmwareData = null;
let firmwareFileName = 'firmware.bin';
// Out-of-order guard: only the most recent selection may commit firmwareData.
let firmwareLoadSeq = 0;
let firmwareLoadAbort = null;
// Version of the CHIRP driver currently offered for download, or null when none.
let chirpDriverVersion = null;
let calibData = null;
let activeOperationToken = null;
let activeToolsView = 'flash';
let readBuffer = [];
let isReading = false;
let rfLogDownloadUrl = null;
const serialSupported = 'serial' in navigator;

// Logo state
let logoSourceImage = null;       // HTMLImageElement of the user-picked file
let logoBitmap = null;            // Uint8Array(1024) ST7565-native, after threshold/invert

// ========== UI ELEMENTS ==========
const flashBtn = document.getElementById('flashBtn');
const dumpBtn = document.getElementById('dumpBtn');
const restoreBtn = document.getElementById('restoreBtn');
const firmwareFileInput = document.getElementById('firmwareFile');
const calibFileInput = document.getElementById('calibFile');
const labelFwFileEl = document.getElementById('labelFirmwareFile');
const labelCalibFileEl = document.getElementById('labelCalibFile');
const logDiv = document.getElementById('log');
const infoBoxEl = document.getElementById('infoBox');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressLabel = document.getElementById('progressLabel');
const logToggle = document.getElementById('logToggle');
const languageSelect = document.getElementById('languageSelect');
const dumpDownload = document.getElementById('dumpDownload');
const dumpLink = document.getElementById('dumpLink');
const chirpDriverDownload = document.getElementById('chirpDriverDownload');
const chirpDriverLink = document.getElementById('chirpDriverLink');
const chirpDriverText = document.getElementById('chirpDriverText');

// File input labels
const fileLabel = document.getElementById('fileLabel');
const fileName = document.getElementById('fileName');
const fileButton = document.getElementById('fileButton');
const calibFileLabel = document.getElementById('calibFileLabel');
const calibFileName = document.getElementById('calibFileName');
const calibFileButton = document.getElementById('calibFileButton');

// Logo UI
const logoFileInput = document.getElementById('logoFile');
const logoFileLabel = document.getElementById('logoFileLabel');
const logoFileName = document.getElementById('logoFileName');
const logoFileButton = document.getElementById('logoFileButton');
const logoControls = document.getElementById('logoControls');
const logoThresholdInput = document.getElementById('logoThreshold');
const logoThresholdValue = document.getElementById('logoThresholdValue');
const logoInvertInput = document.getElementById('logoInvert');
const logoPreviewCanvas = document.getElementById('logoPreviewCanvas');
const logoUploadBtn = document.getElementById('logoUploadBtn');
const logoDumpBtn = document.getElementById('logoDumpBtn');
const logoDumpResult = document.getElementById('logoDumpResult');
const logoDumpedCanvas = document.getElementById('logoDumpedCanvas');
const logoDumpLink = document.getElementById('logoDumpLink');
const rfLogExportBtn = document.getElementById('rfLogExportBtn');
const rfLogDownload = document.getElementById('rfLogDownload');
const rfLogLink = document.getElementById('rfLogLink');

// ========== VERSION COMPARISON ==========
function isBootloaderCompatible(version, minVersion) {
  // Parse version strings (e.g., "7.02.02")
  const parseVersion = (v) => {
    const parts = v.split('.').map(p => parseInt(p, 10) || 0);
    while (parts.length < 3) parts.push(0);
    return parts;
  };
  
  const current = parseVersion(version);
  const required = parseVersion(minVersion);
  
  // Compare major.minor.patch
  for (let i = 0; i < 3; i++) {
    if (current[i] > required[i]) return true;
    if (current[i] < required[i]) return false;
  }
  
  return true; // Equal versions are compatible
}

// ========== i18n HELPER ==========
function t(key, ...args) {
  return window.uvStudioI18n ? window.uvStudioI18n.t(key, ...args) : key;
}

// ========== UI UPDATE ==========
function refreshLocalizedToolsState() {
  if (labelFwFileEl) labelFwFileEl.textContent = t('labelFirmwareFile');
  if (labelCalibFileEl) labelCalibFileEl.textContent = t('labelCalibFile');

  // Update info box based on active tab
  updateInfoBox();
  
  if (flashBtn) flashBtn.textContent = t('flashBtn');
  if (dumpBtn) dumpBtn.textContent = t('dumpBtn');
  if (restoreBtn) restoreBtn.textContent = t('restoreBtn');
  if (fileButton) fileButton.textContent = t('fileChoose');
  if (calibFileButton) calibFileButton.textContent = t('fileChoose');

  // Description
  const dumpDesc = document.getElementById('dumpDescription');
  const downloadText = document.getElementById('downloadText');
  if (dumpDesc) dumpDesc.textContent = t('dumpDescription');
  if (downloadText) downloadText.textContent = t('downloadText');

  // RF Log labels
  const rfLogDescription = document.getElementById('rfLogDescription');
  const rfLogDownloadText = document.getElementById('rfLogDownloadText');
  if (rfLogDescription) rfLogDescription.textContent = t('rfLogDescription');
  if (rfLogDownloadText) rfLogDownloadText.textContent = t('rfLogDownloadText');
  if (rfLogExportBtn) rfLogExportBtn.textContent = t('rfLogExportBtn');

  // Logo labels
  const labelLogoFile = document.getElementById('labelLogoFile');
  const labelLogoThreshold = document.getElementById('labelLogoThreshold');
  const labelLogoInvert = document.getElementById('labelLogoInvert');
  const labelLogoPreview = document.getElementById('labelLogoPreview');
  const logoUploadDesc = document.getElementById('logoUploadDescription');
  const logoDumpDesc = document.getElementById('logoDumpDescription');
  const logoDumpedLabel = document.getElementById('logoDumpedLabel');
  const logoDumpDownloadText = document.getElementById('logoDumpDownloadText');
  if (labelLogoFile) labelLogoFile.textContent = t('labelLogoFile');
  if (labelLogoThreshold) labelLogoThreshold.textContent = t('labelLogoThreshold');
  if (labelLogoInvert) labelLogoInvert.textContent = t('labelLogoInvert');
  if (labelLogoPreview) labelLogoPreview.textContent = t('labelLogoPreview');
  if (logoUploadDesc) logoUploadDesc.textContent = t('logoUploadDescription');
  if (logoDumpDesc) logoDumpDesc.textContent = t('logoDumpDescription');
  if (logoDumpedLabel) logoDumpedLabel.textContent = t('logoDumpedLabel');
  if (logoDumpDownloadText) logoDumpDownloadText.textContent = t('logoDumpDownloadText');
  if (logoUploadBtn) logoUploadBtn.textContent = t('logoUploadBtn');
  if (logoDumpBtn) logoDumpBtn.textContent = t('logoDumpBtn');
  if (logoFileButton) logoFileButton.textContent = t('fileChoose');
  if (logoFileName && !logoSourceImage) {
    logoFileName.textContent = t('fileNoFile');
    logoFileName.classList.remove('has-file');
    if (logoFileLabel) logoFileLabel.classList.remove('has-file');
  }

  // Log toggle
  if (logToggle) {
    const visible = logDiv && logDiv.classList.contains('visible');
    logToggle.textContent = visible ? t('logHide') : t('logShow');
    logToggle.setAttribute('aria-expanded', visible ? 'true' : 'false');
  }

  // File names
  if (fileName && !firmwareData) {
    fileName.textContent = t('fileNoFile');
    fileName.classList.remove('has-file');
    if (fileLabel) fileLabel.classList.remove('has-file');
  }

  if (calibFileName && !calibData) {
    calibFileName.textContent = t('fileNoFile');
    calibFileName.classList.remove('has-file');
    if (calibFileLabel) calibFileLabel.classList.remove('has-file');
  }

  if (chirpDriverText && chirpDriverVersion) {
    chirpDriverText.textContent = t('flash_chirp_driver_download', chirpDriverVersion);
  }

  if (languageSelect && window.uvStudioI18n) {
    languageSelect.value = window.uvStudioI18n.lang;
  }
}

// Update info box based on active tab
function updateInfoBox() {
  if (!infoBoxEl) return;

  const tabName = activeToolsView;

  if (tabName === 'flash') {
    infoBoxEl.innerHTML = t('infoBox');
  } else if (tabName === 'rf-log') {
    infoBoxEl.innerHTML = t('infoBoxRfLog');
  } else if (tabName === 'logo-upload' || tabName === 'logo-dump') {
    infoBoxEl.innerHTML = t('infoBoxLogo');
  } else {
    infoBoxEl.innerHTML = t('infoBoxDump');
  }
}

// Refresh dynamic tool labels after the shared language changes.
window.addEventListener('uvstudio:languagechange', () => {
  refreshLocalizedToolsState();
});

window.addEventListener('uvstudio:toolviewchange', event => {
  activeToolsView = event.detail?.view || 'flash';
  updateInfoBox();
});

// Initial i18n sync
(async () => {
  if (window.uvStudioI18nReady) await window.uvStudioI18nReady;
  refreshLocalizedToolsState();
  await maybeLoadFirmwareFromQuery();
})();

// ========== LOG VISIBILITY ==========
if (logToggle) {
  logToggle.addEventListener('click', () => {
    if (!logDiv) return;
    logDiv.classList.toggle('visible');
    logToggle.textContent = logDiv.classList.contains('visible') ? t('logHide') : t('logShow');
    logToggle.setAttribute('aria-expanded', logDiv.classList.contains('visible') ? 'true' : 'false');
  });
}

// ========== FIRMWARE FILE INPUT ==========
if (firmwareFileInput) {
  firmwareFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const seq = beginFirmwareLoad('local');
    const fr = new FileReader();
    fr.onload = (ev) => { if (seq === firmwareLoadSeq) setFirmwareBuffer(ev.target.result, file.name); };
    fr.readAsArrayBuffer(file);
  });
}

// Start a new firmware selection: bump the generation so any earlier in-flight
// load is ignored on completion, cancel a pending download, and keep the two
// sources (catalog vs local file) mutually exclusive.
function beginFirmwareLoad(source) {
  const seq = ++firmwareLoadSeq;
  if (firmwareLoadAbort) { try { firmwareLoadAbort.abort(); } catch (e) {} firmwareLoadAbort = null; }
  // The previous firmware is no longer current: make it unavailable so Flash is
  // disabled until the new selection has finished loading.
  firmwareData = null;
  updateFlashButton();
  if (source === 'url' && firmwareFileInput) firmwareFileInput.value = '';
  window.dispatchEvent(new CustomEvent('uvstudio:firmwareselect', { detail: { source } }));
  return seq;
}

function clearFirmware() {
  firmwareData = null;
  if (fileName) { fileName.textContent = t('fileNoFile'); fileName.classList.remove('has-file'); }
  if (fileLabel) fileLabel.classList.remove('has-file');
  updateFlashButton();
}

function setFirmwareBuffer(buf, name = 'firmware.bin') {
  firmwareData = new Uint8Array(buf);
  firmwareFileName = name;
  hideChirpDriverOffer();
  if (fileName) {
    fileName.textContent = name;
    fileName.classList.add('has-file');
  }
  if (fileLabel) fileLabel.classList.add('has-file');
  log(t('firmwareLoaded', name, firmwareData.length), 'success');
  updateFlashButton();
}

// ---------- CHIRP driver offer ----------
// F4HWN Fusion firmwares ship a matching CHIRP driver as a release asset named
// f4hwn.fusion.chirp.v<version>.py (one driver covers UV-K1 and UV-K5 V3). After
// a successful flash we resolve the driver for the flashed version and offer it.
const CHIRP_DRIVER_REPO = 'armel/uv-k1-k5v3-firmware-custom';

function hideChirpDriverOffer() {
  chirpDriverVersion = null;
  if (chirpDriverDownload) chirpDriverDownload.style.display = 'none';
}

function showChirpDriverOffer(version, url) {
  if (!chirpDriverDownload || !chirpDriverLink) return;
  chirpDriverVersion = version;
  chirpDriverLink.href = url;
  if (chirpDriverText) chirpDriverText.textContent = t('flash_chirp_driver_download', version);
  chirpDriverDownload.style.display = 'block';
  log(t('chirpDriverAvailable', version), 'success');
}

// Best-effort: resolve and offer the CHIRP driver for the flashed firmware.
// Never throws — a missing driver or network hiccup must not disturb the flash.
async function maybeOfferChirpDriver(fname) {
  try {
    const parse = window.UVStudioFlashCatalog?.parseFirmwareName;
    const info = parse ? parse(fname) : null;
    // Only versioned F4HWN Fusion builds have a matching driver (not stock
    // Quansheng, not the unversioned development build).
    if (!info || info.brand !== 'f4hwn' || info.isDevelopment || !info.version) return;

    const tag = `v${info.version}`;
    const apiUrl =
      `https://api.github.com/repos/${CHIRP_DRIVER_REPO}/releases/tags/${encodeURIComponent(tag)}`;
    const res = await fetch(apiUrl, { cache: 'no-cache', mode: 'cors' });
    if (!res.ok) return; // no release for this version → nothing to offer

    const release = await res.json();
    const asset = (release.assets || []).find(
      a => /chirp/i.test(a.name) && /\.py$/i.test(a.name)
    );
    if (!asset || !asset.browser_download_url) return;

    showChirpDriverOffer(info.version, asset.browser_download_url);
  } catch (e) {
    // Swallowed on purpose: the driver offer is a bonus, never a failure path.
  }
}

// ---------- Auto-load firmware from URL ----------

async function loadFirmwareFromURL(url) {
  const seq = beginFirmwareLoad('url');
  const controller = new AbortController();
  firmwareLoadAbort = controller;
  try {
    log(t('loadingFromUrl', url), 'info');

    const urlObj = new URL(url);

    // Only HTTPS
    if (urlObj.protocol !== 'https:') {
      throw new Error(t('urlHttpNotHttps'));
    }

    // GitHub convenience: github.com/.../raw/... → raw.githubusercontent.com/...
    if (urlObj.hostname === 'github.com' && urlObj.pathname.includes('/raw/')) {
      const parts = urlObj.pathname.split('/').filter(Boolean);
      const i = parts.indexOf('raw');
      if (i > 1 && i < parts.length - 1) {
        const user = parts[0];
        const repo = parts[1];
        const branch = parts[i + 1];
        const rest = parts.slice(i + 2).join('/');
        urlObj.hostname = 'raw.githubusercontent.com';
        urlObj.pathname = `/${user}/${repo}/${branch}/${rest}`;
      }
    }

    const res = await fetch(urlObj.toString(), { cache: 'no-cache', mode: 'cors', signal: controller.signal });
    if (!res.ok) {
      throw new Error(`${t('urlFetchError')} HTTP ${res.status}`);
    }

    const buf = await res.arrayBuffer();
    if (seq !== firmwareLoadSeq) return; // superseded by a newer selection

    const fname = (urlObj.pathname.split('/').pop() || 'firmware.bin').split('?')[0];

    setFirmwareBuffer(buf, fname);

    // Clean URL so refresh does not re-trigger auto-load
    const clean = new URL(window.location.href);
    clean.searchParams.delete('firmwareURL');
    clean.searchParams.delete('fw');
    window.history.replaceState({}, '', clean.toString());
  } catch (err) {
    if (err && err.name === 'AbortError') return; // cancelled by a newer selection
    log(`${t('urlFetchError')} ${err?.message ?? String(err)}`, 'error');
    if (seq === firmwareLoadSeq) clearFirmware();
  } finally {
    if (firmwareLoadAbort === controller) firmwareLoadAbort = null;
  }
}

async function maybeLoadFirmwareFromQuery() {
  try {
    const params = new URLSearchParams(window.location.search);
    const param = params.get('firmwareURL') || params.get('fw');
    if (!param) return;
    await loadFirmwareFromURL(decodeURIComponent(param));
  } catch (e) {
    log(t('urlInvalid'), 'error');
  }
}

// Minimal entry point so the firmware catalog picker can reuse the URL loader.
window.UVStudioFlash = Object.freeze({
  loadFirmwareFromURL,
  hasFirmware: () => Boolean(firmwareData)
});

function updateFlashButton() {
  updateActionButtons();
}

// ========== CALIBRATION FILE INPUT ==========
if (calibFileInput) {
  calibFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = (ev) => {
      const buf = new Uint8Array(ev.target.result);
      if (buf.length !== CALIB_SIZE) {
        log(t('calibInvalidSize', buf.length), 'error');
        return;
      }
      calibData = buf;
      if (calibFileName) {
        calibFileName.textContent = file.name;
        calibFileName.classList.add('has-file');
      }
      if (calibFileLabel) calibFileLabel.classList.add('has-file');
      log(t('calibLoaded', file.name, calibData.length), 'success');
      updateRestoreButton();
    };
    fr.readAsArrayBuffer(file);
  });
}

function updateRestoreButton() {
  updateActionButtons();
}

// ========== SERIAL CONNECTION ==========
async function connect() {
  try {
    await toolsSerial.acquire({ source: 'tools' });
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }
    log(t('requestingPort'), 'info');
    port = await navigator.serial.requestPort();
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }
    log(t('openingPort'), 'info');
    await port.open({ baudRate: BAUDRATE });
    if (!toolsSerial.isOwner()) {
      try { await port.close(); } catch {}
      port = null;
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }

    log(t('gettingReader'), 'info');
    reader = port.readable.getReader();
    log(t('gettingWriter'), 'info');
    writer = port.writable.getWriter();

    log(t('startingRead'), 'info');
    startReading();

    log(t('waiting500ms'), 'info');
    await sleep(500);
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }

    log(t('connected'), 'success');
    toolsSerial.setState('connected', { reason: 'connection-established' });
  } catch (e) {
    if (toolsSerial.isOwner()) {
      await toolsSerial.release('connection-error');
    } else {
      await disconnectPort({ reason: 'connection-cancelled' });
    }
    if (e?.code !== 'UVSTUDIO_SERIAL_RELEASED') {
      log(t('connectionError', e?.message ?? String(e)), 'error');
    }
    throw e;
  }
}

async function disconnectPort(context = {}) {
  isReading = false;
  const activeReader = reader;
  const activeWriter = writer;
  const activePort = port;
  reader = null;
  writer = null;
  port = null;

  await window.UVStudioSerial.closeResources({
    reader: activeReader,
    writer: activeWriter,
    port: activePort
  });
  if (context.reason === 'operation-complete' || context.reason === 'user') {
    log(t('tools_disconnected'), 'info');
  }
}

const toolsSerial = window.UVStudioSerial.register('tools', {
  disconnect: disconnectPort
});

function updateActionButtons() {
  const busy = Boolean(activeOperationToken);
  if (flashBtn) flashBtn.disabled = !serialSupported || busy || !firmwareData;
  if (dumpBtn) dumpBtn.disabled = !serialSupported || busy;
  if (restoreBtn) restoreBtn.disabled = !serialSupported || busy || !calibData;
  if (logoUploadBtn) logoUploadBtn.disabled = !serialSupported || busy || !logoBitmap;
  if (logoDumpBtn) logoDumpBtn.disabled = !serialSupported || busy;
  if (rfLogExportBtn) rfLogExportBtn.disabled = !serialSupported || busy;
}

function beginToolsOperation(name, critical) {
  if (activeOperationToken) return null;
  const token = toolsSerial.beginOperation(name, { critical });
  if (!token) return null;
  activeOperationToken = token;
  updateActionButtons();
  return token;
}

function endToolsOperation(token) {
  if (!token || token !== activeOperationToken) return;
  toolsSerial.endOperation(token);
  activeOperationToken = null;
  updateActionButtons();
}

window.addEventListener('beforeunload', event => {
  const operation = toolsSerial.getSnapshot().operation;
  if (!operation?.critical) return;
  event.preventDefault();
  event.returnValue = '';
});

async function disconnect() {
  return toolsSerial.release('operation-complete');
}

function startReading() {
  if (!reader || isReading) return;
  isReading = true;
  readLoop().catch(e => {
    if (isReading) log(t('loopError', e?.message ?? String(e)), 'error');
  });
}

async function readLoop() {
  log(t('startReading'), 'info');
  try {
    while (isReading && reader) {
      const { value, done } = await reader.read();
      if (done) {
        log(t('streamClosed'), 'info');
        break;
      }
      if (value?.length) {
        readBuffer.push(...value);
        log(t('rxData', value.length, readBuffer.length), 'info');
      }
    }
  } catch (e) {
    if (isReading) log(t('readError', e?.message ?? String(e)), 'error');
  }
  log(t('readComplete'), 'info');
}

// ========== PROTOCOL HELPERS ==========
function createMessage(msgType, dataLen) {
  const msg = new Uint8Array(4 + dataLen);
  const view = new DataView(msg.buffer);
  view.setUint16(0, msgType, true);
  view.setUint16(2, dataLen, true);
  return msg;
}

async function sendMessage(msg) {
  const packet = makePacket(msg);
  await writer.write(packet);
}

function makePacket(msg) {
  let msgLen = msg.length;
  if (msgLen % 2 !== 0) msgLen++;
  const buf = new Uint8Array(8 + msgLen);
  const view = new DataView(buf.buffer);

  view.setUint16(0, 0xCDAB, true);
  view.setUint16(2, msgLen, true);
  view.setUint16(6 + msgLen, 0xBADC, true);

  for (let i = 0; i < msg.length; i++) buf[4 + i] = msg[i];

  const crc = calcCRC(buf, 4, msgLen);
  view.setUint16(4 + msgLen, crc, true);

  obfuscate(buf, 4, 2 + msgLen);
  return buf;
}

function fetchMessage(buf) {
  if (buf.length < 8) return null;

  let packBegin = -1;
  for (let i = 0; i < buf.length - 1; i++) {
    if (buf[i] === 0xab && buf[i + 1] === 0xcd) {
      packBegin = i;
      break;
    }
  }
  if (packBegin === -1) {
    if (buf.length > 0 && buf[buf.length - 1] === 0xab) buf.splice(0, buf.length - 1);
    else buf.length = 0;
    return null;
  }
  if (buf.length - packBegin < 8) return null;

  const msgLen = (buf[packBegin + 3] << 8) | buf[packBegin + 2];
  const packEnd = packBegin + 6 + msgLen;
  if (buf.length < packEnd + 2) return null;

  if (buf[packEnd] !== 0xdc || buf[packEnd + 1] !== 0xba) {
    buf.splice(0, packBegin + 2);
    return null;
  }

  const msgBuf = new Uint8Array(msgLen + 2);
  for (let i = 0; i < msgLen + 2; i++) msgBuf[i] = buf[packBegin + 4 + i];
  obfuscate(msgBuf, 0, msgLen + 2);

  const view = new DataView(msgBuf.buffer);
  const msgType = view.getUint16(0, true);
  const data = msgBuf.slice(4);

  buf.splice(0, packEnd + 2);
  return { msgType, data, rawData: msgBuf };
}

function obfuscate(buf, off, size) {
  for (let i = 0; i < size; i++) buf[off + i] ^= OBFUS_TBL[i % OBFUS_TBL.length];
}

function calcCRC(buf, off, size) {
  let CRC = 0;
  for (let i = 0; i < size; i++) {
    const b = buf[off + i] & 0xff;
    CRC ^= b << 8;
    for (let j = 0; j < 8; j++) {
      if (CRC & 0x8000) CRC = ((CRC << 1) ^ 0x1021) & 0xffff;
      else CRC = (CRC << 1) & 0xffff;
    }
  }
  return CRC;
}

function arrayToHex(arr) {
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join(' ');
}

// ========== FLASH FIRMWARE (from original flash.js) ==========
flashBtn.addEventListener('click', async () => {
  if (!firmwareData) return;
  // Snapshot the buffer so a download finishing mid-flash cannot swap it out.
  const fw = firmwareData;
  const operation = beginToolsOperation('flash-firmware', true);
  if (!operation) return;
  try {
    if (!port) await connect();
    await flashFirmware(fw);
  } catch (e) {
    log(t('flashError', e?.message ?? String(e)), 'error');
  } finally {
    if (port) await disconnect();
    endToolsOperation(operation);
  }
});

async function flashFirmware(fw) {
  hideChirpDriverOffer();
  if (progressContainer) progressContainer.style.display = 'block';
  updateProgress(0);

  readBuffer = [];
  log(t('bufferEmpty'), 'info');
  await sleep(1000);
  log(t('bufferContains', readBuffer.length), 'info');

  log(t('establishing'), 'info');
  const devInfo = await waitForDeviceInfo();
  log(t('uidLabel', arrayToHex(devInfo.uid)), 'info');
  log(t('blVersionLabel', devInfo.blVersion), 'info');

  // Check bootloader version compatibility
  const minVersion = '7.00.07';
  if (!isBootloaderCompatible(devInfo.blVersion, minVersion)) {
    log('==============================================', 'error');
    log('❌ INCOMPATIBLE BOOTLOADER VERSION', 'error');
    log(`   Detected: ${devInfo.blVersion}`, 'error');
    log(`   Required: ${minVersion} or higher`, 'error');
    log('', 'error');
    log('This radio does not seem compatible with this firmware.', 'error');
    log('Please open an issue on GitHub:', 'error');
    log('https://github.com/armel/uv-k1-k5v3-firmware-custom', 'error');
    log('Please, include your bootloader version in the issue:', 'error');
    log(`   Bootloader: ${devInfo.blVersion}`, 'error');
    log('==============================================', 'error');
    throw new Error('Bootloader version too old');
  }
  log(t('deviceDetected'), 'success');

  log(t('handshake'), 'info');
  await performHandshake(devInfo.blVersion);
  log(t('handshakeComplete'), 'success');

  await programFirmware(fw);

  updateProgress(100);
  log(t('programmingComplete'), 'success');

  // Global community counter: a firmware was successfully flashed.
  // Best-effort — never blocks or fails the flash.
  try { window.UVStudioFlashCounter?.increment(); } catch (e) {}

  // Offer the matching CHIRP driver for download. Best-effort, never blocks.
  maybeOfferChirpDriver(firmwareFileName);

  setTimeout(() => {
    if (progressContainer) progressContainer.style.display = 'none';
    updateProgress(0);
  }, 800);
}

async function waitForDeviceInfo() {
  let lastTimestamp = 0, acc = 0, timeout = 0;
  log(t('waiting'), 'info');

  while (timeout < 500) {
    await sleep(10);
    timeout++;

    const msg = fetchMessage(readBuffer);
    if (!msg) continue;

    log(t('messageReceived', msg.msgType.toString(16).padStart(4, '0')), 'info');

    if (msg.msgType === MSG_NOTIFY_DEV_INFO) {
      const now = Date.now();
      const dt = now - lastTimestamp;
      log(t('interval', dt, acc), 'info');
      lastTimestamp = now;

      if (lastTimestamp > 0 && dt >= 5 && dt <= 1000) {
        acc++;
        log(t('validMessage', acc), 'success');
        if (acc >= 5) {
          const uid = msg.data.slice(0, 16);
          let blVersionEnd = -1;
          for (let i = 16; i < 32; i++) {
            if (msg.data[i] === 0) {
              blVersionEnd = i;
              break;
            }
          }
          if (blVersionEnd === -1) blVersionEnd = 32;
          const blVersion = new TextDecoder().decode(msg.data.slice(16, blVersionEnd));
          return { uid, blVersion };
        }
      } else {
        if (dt < 5 || dt > 1000) log(t('invalidInterval', dt), 'error');
        acc = 0;
      }
    }
  }
  throw new Error(t('timeoutNoDevice'));
}

async function performHandshake(blVersion) {
  let acc = 0;

  while (acc < 3) {
    await sleep(50);
    const msg = fetchMessage(readBuffer);
    if (msg && msg.msgType === MSG_NOTIFY_DEV_INFO) {
      if (acc === 0) log(t('sendingBlVersion'), 'info');

      const blMsg = createMessage(MSG_NOTIFY_BL_VER, 4);
      const blBytes = new TextEncoder().encode(blVersion.substring(0, 4));
      for (let i = 0; i < Math.min(blBytes.length, 4); i++) blMsg[4 + i] = blBytes[i];
      await sendMessage(blMsg);
      acc++;
      await sleep(50);
    }
  }

  log(t('waitingStop'), 'info');
  await sleep(200);

  while (readBuffer.length > 0) {
    const msg = fetchMessage(readBuffer);
    if (!msg) break;
    if (msg.msgType === MSG_NOTIFY_DEV_INFO) log(t('devInfoIgnored'), 'info');
    else log(t('messageReceived', msg.msgType.toString(16)), 'info');
  }
  log(t('bufferCleaned', readBuffer.length), 'info');
}

async function programFirmware(fw) {
  const pageCount = Math.ceil(fw.length / 256);
  const timestamp = Date.now() & 0xffffffff;
  log(t('programming', pageCount), 'info');

  let pageIndex = 0, retryCount = 0;
  const MAX_RETRIES = 3;

  while (pageIndex < pageCount) {
    updateProgress((pageIndex / pageCount) * 100);

    const msg = createMessage(MSG_PROG_FW, 268);
    const view = new DataView(msg.buffer);
    view.setUint32(4, timestamp, true);
    view.setUint16(8, pageIndex, true);
    view.setUint16(10, pageCount, true);

    const offset = pageIndex * 256;
    const len = Math.min(256, fw.length - offset);
    for (let i = 0; i < len; i++) msg[16 + i] = fw[offset + i];

    await sendMessage(msg);

    let gotResponse = false;
    for (let i = 0; i < 300 && !gotResponse; i++) {
      await sleep(10);
      const resp = fetchMessage(readBuffer);
      if (!resp) continue;
      if (resp.msgType === MSG_NOTIFY_DEV_INFO) continue;

      if (resp.msgType === MSG_PROG_FW_RESP) {
        const dv = new DataView(resp.data.buffer);
        const respPageIndex = dv.getUint16(4, true);
        const err = dv.getUint16(6, true);

        if (respPageIndex !== pageIndex) {
          log(t('pageWrongResponse', pageIndex + 1, pageCount, respPageIndex), 'error');
          continue;
        }
        if (err !== 0) {
          log(t('pageError', pageIndex + 1, pageCount, err), 'error');
          retryCount++;
          if (retryCount > MAX_RETRIES) throw new Error(t('tooManyErrors', pageIndex));
          break;
        }

        gotResponse = true;
        retryCount = 0;
        if ((pageIndex + 1) % 10 === 0 || pageIndex === pageCount - 1)
          log(t('pageOk', pageIndex + 1, pageCount), 'success');
      }
    }

    if (gotResponse) {
      pageIndex++;
    } else {
      log(t('pageTimeout', pageIndex + 1, pageCount), 'error');
      retryCount++;
      if (retryCount > MAX_RETRIES) throw new Error(t('tooManyTimeouts', pageIndex));
    }
  }
}

// ========== DUMP CALIBRATION ==========
dumpBtn.addEventListener('click', async () => {
  const operation = beginToolsOperation('dump-calibration', false);
  if (!operation) return;
  progressContainer.style.display = 'block';
  updateProgress(0);
  dumpDownload.style.display = 'none';

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    log(t('dumpingData'), 'info');

    const dumpedData = new Uint8Array(CALIB_SIZE);
    let offset = CALIB_OFFSET;

    for (let i = 0; i < CALIB_SIZE; i += CHUNK_SIZE) {
      const pct = Math.round((i / CALIB_SIZE) * 100);
      updateProgress(pct);

      const msg = createMessage(MSG_READ_EEPROM, 8);
      const view = new DataView(msg.buffer);
      view.setUint16(4, offset, true);
      view.setUint16(6, CHUNK_SIZE, true);
      view.setUint32(8, devInfo.timestamp, true);
      await sendMessage(msg);

      let gotResponse = false;
      for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
        await sleep(10);
        const resp = fetchMessage(readBuffer);
        if (!resp) continue;

        if (resp.msgType === MSG_READ_EEPROM_RESP) {
          const dv = new DataView(resp.data.buffer);
          const respOffset = dv.getUint16(0, true);
          const respSize = resp.data[2];

          if (respOffset === offset && respSize === CHUNK_SIZE) {
            for (let j = 0; j < CHUNK_SIZE; j++) {
              dumpedData[i + j] = resp.data[4 + j];
            }
            gotResponse = true;
            offset += CHUNK_SIZE;
          }
        }
      }

      if (!gotResponse) {
        throw new Error(t('eepromError', offset.toString(16)));
      }
    }

    updateProgress(100);
    log(t('dumpComplete'), 'success');

    const blob = new Blob([dumpedData], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    dumpLink.href = url;
    dumpLink.download = 'calibration.dat';
    dumpDownload.style.display = 'block';
    log(t('dumpSaved'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    if (port) await disconnect();
    endToolsOperation(operation);
  }
});

// ========== RESTORE CALIBRATION ==========
restoreBtn.addEventListener('click', async () => {
  if (!calibData) return;
  const operation = beginToolsOperation('restore-calibration', true);
  if (!operation) return;
  progressContainer.style.display = 'block';
  updateProgress(0);

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    log(t('restoringData'), 'info');

    let offset = CALIB_OFFSET;

    for (let i = 0; i < CALIB_SIZE; i += CHUNK_SIZE) {
      const pct = Math.round((i / CALIB_SIZE) * 100);
      updateProgress(pct);

      const msg = createMessage(MSG_WRITE_EEPROM, 24);
      const view = new DataView(msg.buffer);
      view.setUint16(4, offset, true);
      view.setUint16(6, CHUNK_SIZE, true);
      msg[7] = 1;
      view.setUint32(8, devInfo.timestamp, true);
      
      for (let j = 0; j < CHUNK_SIZE; j++) {
        msg[12 + j] = calibData[i + j];
      }
      
      await sendMessage(msg);

      let gotResponse = false;
      for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
        await sleep(10);
        const resp = fetchMessage(readBuffer);
        if (!resp) continue;

        if (resp.msgType === MSG_WRITE_EEPROM_RESP) {
          const dv = new DataView(resp.data.buffer);
          const respOffset = dv.getUint16(0, true);

          if (respOffset === offset) {
            gotResponse = true;
            offset += CHUNK_SIZE;
          }
        }
      }

      if (!gotResponse) {
        throw new Error(t('eepromError', offset.toString(16)));
      }
    }

    updateProgress(100);
    log(t('restoreComplete'), 'success');

    log(t('rebooting'), 'info');
    const rebootMsg = createMessage(MSG_REBOOT, 0);
    await sendMessage(rebootMsg);
    await sleep(500);
    log(t('rebootComplete'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    if (port) await disconnect();
    endToolsOperation(operation);
  }
});

// ========== REQUEST DEVICE INFO (for dump/restore) ==========
async function requestDeviceInfo() {
  log(t('establishing'), 'info');
  
  const ts = Date.now() & 0xffffffff;
  const msg = createMessage(MSG_DEV_INFO_REQ, 4);
  new DataView(msg.buffer).setUint32(4, ts, true);
  await sendMessage(msg);
  
  for (let timeout = 0; timeout < 500; timeout++) {
    await sleep(10);
    const resp = fetchMessage(readBuffer);
    if (!resp) continue;
    
    log(t('messageReceived', resp.msgType.toString(16).padStart(4, '0')), 'info');
    
    if (resp.msgType === MSG_DEV_INFO_RESP) {
      // Log raw device info data
      logDeviceInfo(resp.data);
      log(t('deviceDetected'), 'success');
      return { timestamp: ts };
    }
  }
  throw new Error(t('timeoutNoDevice'));
}

// Helper to display device info response
function logDeviceInfo(data) {
  // Extract ASCII string from device info
  let deviceInfoStr = '';
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    if (c === 0x00 || c === 0xFF) break; // Stop at null or padding
    if (c >= 32 && c < 127) {
      deviceInfoStr += String.fromCharCode(c);
    }
  }
  
  if (deviceInfoStr) {
    log(`Device: ${deviceInfoStr}`, 'success');
    
    // Extract version from string (e.g., "F4HWN v4.3.3" -> "4.3.3")
    const versionMatch = deviceInfoStr.match(/v(\d+\.\d+\.\d+)/);
    if (versionMatch) {
      const version = versionMatch[1];
      const [major, minor, patch] = version.split('.').map(Number);
      
      // Set CALIB_OFFSET based on version
      if (major >= 5) {
        CALIB_OFFSET = 0xB000;
        log(`Firmware v${version} detected: CALIB_OFFSET = 0xB000`, 'info');
      } else {
        CALIB_OFFSET = 0x1E00;
        log(`Firmware v${version} detected: CALIB_OFFSET = 0x1E00`, 'info');
      }
    }
  } else {
    // Fallback to hex dump if no ASCII found
    let hexStr = 'Device Info (hex): ';
    for (let i = 0; i < Math.min(data.length, 40); i++) {
      hexStr += data[i].toString(16).padStart(2, '0').toUpperCase() + ' ';
    }
    log(hexStr, 'info');
  }
}

// ========== LOGO: IMAGE -> BITMAP CONVERSION ==========
// Render the source image into a 128x64 canvas using "fit" (preserve ratio,
// white letterboxing). Then apply threshold + optional invert and pack into
// the ST7565-native column-major LSB-top layout (1024 bytes).
function imageToLogoBitmap(image, threshold, invert) {
  // Step 1: render image fitted in a 128x64 white canvas
  const canvas = document.createElement('canvas');
  canvas.width = LOGO_WIDTH;
  canvas.height = LOGO_HEIGHT;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, LOGO_WIDTH, LOGO_HEIGHT);

  const srcRatio = image.naturalWidth / image.naturalHeight;
  const dstRatio = LOGO_WIDTH / LOGO_HEIGHT;
  let drawW, drawH, drawX, drawY;
  if (srcRatio > dstRatio) {
    // Source wider than 2:1 -> fit to width
    drawW = LOGO_WIDTH;
    drawH = Math.round(LOGO_WIDTH / srcRatio);
    drawX = 0;
    drawY = Math.round((LOGO_HEIGHT - drawH) / 2);
  } else {
    // Source taller than 2:1 -> fit to height
    drawH = LOGO_HEIGHT;
    drawW = Math.round(LOGO_HEIGHT * srcRatio);
    drawX = Math.round((LOGO_WIDTH - drawW) / 2);
    drawY = 0;
  }
  ctx.drawImage(image, drawX, drawY, drawW, drawH);

  // Step 2: read pixels and pack into ST7565 native layout
  const imgData = ctx.getImageData(0, 0, LOGO_WIDTH, LOGO_HEIGHT).data;
  const bitmap = new Uint8Array(LOGO_BITMAP_SIZE);

  for (let page = 0; page < 8; page++) {
    for (let x = 0; x < LOGO_WIDTH; x++) {
      let byte = 0;
      for (let bit = 0; bit < 8; bit++) {
        const y = page * 8 + bit;
        const idx = (y * LOGO_WIDTH + x) * 4;
        // Convert RGBA to luminance (Rec. 601)
        const lum = 0.299 * imgData[idx] + 0.587 * imgData[idx + 1] + 0.114 * imgData[idx + 2];
        // Pixel is "on" (LCD pixel lit, dark on screen) if luminance < threshold
        let on = lum < threshold;
        if (invert) on = !on;
        if (on) byte |= (1 << bit);
      }
      bitmap[page * LOGO_WIDTH + x] = byte;
    }
  }

  return bitmap;
}

// Render a 1024-byte ST7565-native bitmap onto a 128x64 canvas (each "on" bit
// becomes a black pixel, "off" stays white).
function bitmapToCanvas(bitmap, canvas) {
  const ctx = canvas.getContext('2d');
  const imgData = ctx.createImageData(LOGO_WIDTH, LOGO_HEIGHT);
  for (let page = 0; page < 8; page++) {
    for (let x = 0; x < LOGO_WIDTH; x++) {
      const byte = bitmap[page * LOGO_WIDTH + x];
      for (let bit = 0; bit < 8; bit++) {
        const y = page * 8 + bit;
        const on = (byte >> bit) & 1;
        const idx = (y * LOGO_WIDTH + x) * 4;
        const v = on ? 0 : 255;
        imgData.data[idx] = v;
        imgData.data[idx + 1] = v;
        imgData.data[idx + 2] = v;
        imgData.data[idx + 3] = 255;
      }
    }
  }
  ctx.putImageData(imgData, 0, 0);
}

// Refresh preview canvas from current source image + slider/checkbox state.
function refreshLogoPreview() {
  if (!logoSourceImage) return;
  const threshold = parseInt(logoThresholdInput.value, 10);
  const invert = logoInvertInput.checked;
  logoBitmap = imageToLogoBitmap(logoSourceImage, threshold, invert);
  if (logoPreviewCanvas) bitmapToCanvas(logoBitmap, logoPreviewCanvas);
  updateLogoUploadButton();
}

function updateLogoUploadButton() {
  updateActionButtons();
}

// ========== LOGO: FILE INPUT + LIVE PREVIEW ==========
if (logoFileInput) {
  logoFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        logoSourceImage = img;
        if (logoFileName) {
          logoFileName.textContent = file.name;
          logoFileName.classList.add('has-file');
        }
        if (logoFileLabel) logoFileLabel.classList.add('has-file');
        if (logoControls) logoControls.hidden = false;
        log(t('logoLoaded', file.name), 'success');
        refreshLogoPreview();
      };
      img.onerror = () => log(t('logoDecodeError'), 'error');
      img.src = ev.target.result;
    };
    fr.readAsDataURL(file);
  });
}

if (logoThresholdInput) {
  logoThresholdInput.addEventListener('input', () => {
    if (logoThresholdValue) logoThresholdValue.textContent = logoThresholdInput.value;
    refreshLogoPreview();
  });
}

if (logoInvertInput) {
  logoInvertInput.addEventListener('change', refreshLogoPreview);
}

// ========== LOGO: UPLOAD ==========
if (logoUploadBtn) {
  logoUploadBtn.addEventListener('click', async () => {
    if (!logoBitmap) return;
    const operation = beginToolsOperation('upload-logo', true);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);

    try {
      if (!port) await connect();
      readBuffer = [];
      await sleep(1000);

      const devInfo = await requestDeviceInfo();
      log(t('logoUploading'), 'info');

      // Build full payload: 8-byte magic + 1024-byte bitmap, padded to 16-byte chunks.
      const payload = new Uint8Array(LOGO_PADDED_SIZE);
      payload.fill(0xFF);
      payload.set(LOGO_MAGIC, 0);
      payload.set(logoBitmap, LOGO_HEADER_SIZE);

      let offset = LOGO_EEPROM_OFFSET;
      for (let i = 0; i < LOGO_PADDED_SIZE; i += CHUNK_SIZE) {
        const pct = Math.round((i / LOGO_PADDED_SIZE) * 100);
        updateProgress(pct);

        const msg = createMessage(MSG_WRITE_EEPROM, 24);
        const view = new DataView(msg.buffer);
        view.setUint16(4, offset, true);
        view.setUint16(6, CHUNK_SIZE, true);
        msg[7] = 1;
        view.setUint32(8, devInfo.timestamp, true);

        for (let j = 0; j < CHUNK_SIZE; j++) {
          msg[12 + j] = payload[i + j];
        }

        await sendMessage(msg);

        let gotResponse = false;
        for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
          await sleep(10);
          const resp = fetchMessage(readBuffer);
          if (!resp) continue;
          if (resp.msgType === MSG_WRITE_EEPROM_RESP) {
            const dv = new DataView(resp.data.buffer);
            const respOffset = dv.getUint16(0, true);
            if (respOffset === offset) {
              gotResponse = true;
              offset += CHUNK_SIZE;
            }
          }
        }

        if (!gotResponse) {
          throw new Error(t('eepromError', offset.toString(16)));
        }
      }

      updateProgress(100);
      log(t('logoUploadComplete'), 'success');

      log(t('rebooting'), 'info');
      const rebootMsg = createMessage(MSG_REBOOT, 0);
      await sendMessage(rebootMsg);
      await sleep(500);
      log(t('rebootComplete'), 'success');

      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      if (port) await disconnect();
      endToolsOperation(operation);
    }
  });
}

// ========== LOGO: DUMP ==========
if (logoDumpBtn) {
  logoDumpBtn.addEventListener('click', async () => {
    const operation = beginToolsOperation('dump-logo', false);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);
    if (logoDumpResult) logoDumpResult.hidden = true;

    try {
      if (!port) await connect();
      readBuffer = [];
      await sleep(1000);

      const devInfo = await requestDeviceInfo();
      log(t('logoDumping'), 'info');

      const dumped = new Uint8Array(LOGO_PADDED_SIZE);
      let offset = LOGO_EEPROM_OFFSET;

      for (let i = 0; i < LOGO_PADDED_SIZE; i += CHUNK_SIZE) {
        const pct = Math.round((i / LOGO_PADDED_SIZE) * 100);
        updateProgress(pct);

        const msg = createMessage(MSG_READ_EEPROM, 8);
        const view = new DataView(msg.buffer);
        view.setUint16(4, offset, true);
        view.setUint16(6, CHUNK_SIZE, true);
        view.setUint32(8, devInfo.timestamp, true);
        await sendMessage(msg);

        let gotResponse = false;
        for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
          await sleep(10);
          const resp = fetchMessage(readBuffer);
          if (!resp) continue;
          if (resp.msgType === MSG_READ_EEPROM_RESP) {
            const dv = new DataView(resp.data.buffer);
            const respOffset = dv.getUint16(0, true);
            const respSize = resp.data[2];
            if (respOffset === offset && respSize === CHUNK_SIZE) {
              for (let j = 0; j < CHUNK_SIZE; j++) {
                dumped[i + j] = resp.data[4 + j];
              }
              gotResponse = true;
              offset += CHUNK_SIZE;
            }
          }
        }

        if (!gotResponse) {
          throw new Error(t('eepromError', offset.toString(16)));
        }
      }

      updateProgress(100);

      // Verify magic header (informational only, do not abort if missing).
      let magicOk = true;
      for (let i = 0; i < LOGO_HEADER_SIZE; i++) {
        if (dumped[i] !== LOGO_MAGIC[i]) { magicOk = false; break; }
      }
      log(magicOk ? t('logoMagicOk') : t('logoMagicMissing'), magicOk ? 'success' : 'info');

      // Extract bitmap and render
      const bitmap = dumped.slice(LOGO_HEADER_SIZE, LOGO_HEADER_SIZE + LOGO_BITMAP_SIZE);
      if (logoDumpedCanvas) {
        bitmapToCanvas(bitmap, logoDumpedCanvas);
        logoDumpedCanvas.toBlob((blob) => {
          if (!blob) return;
          const url = URL.createObjectURL(blob);
          if (logoDumpLink) {
            logoDumpLink.href = url;
            logoDumpLink.download = 'logo.png';
          }
        }, 'image/png');
      }
      if (logoDumpResult) logoDumpResult.hidden = false;
      log(t('logoDumpComplete'), 'success');

      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      if (port) await disconnect();
      endToolsOperation(operation);
    }
  });
}

// ========== EXPORT RF LOG ==========
async function collectRfLogRows() {
  const rf = window.UVTOOLS_RF_LOG;
  if (!rf) throw new Error(t('rfLogProtocolUnavailable'));

  const rows = new Map();
  let firstMainAt = 0;
  let lastHistoryAt = 0;
  let gotHistory = false;
  let lastKeepaliveAt = 0;
  const startedAt = Date.now();
  const deadline = Date.now() + RF_LOG_EXPORT_TIMEOUT_MS;

  await writer.write(rf.featureKeepalive(true));
  lastKeepaliveAt = Date.now();

  while (Date.now() < deadline) {
    const now = Date.now();
    if (now - lastKeepaliveAt >= RF_LOG_KEEPALIVE_INTERVAL_MS) {
      await writer.write(rf.featureKeepalive(!firstMainAt));
      lastKeepaliveAt = Date.now();
    }

    let frame = rf.takeViewerFrame(readBuffer);
    while (frame) {
      if (frame.type === rf.TYPE_RF_LOG) {
        let packet;
        try {
          packet = rf.parseMainPacket(frame.payload);
        } catch (error) {
          if (error.code === 'RF_LOG_VERSION') throw new Error(t('rfLogVersionUnsupported'));
          throw error;
        }

        if (packet.disabled) throw new Error(t('rfLogDisabled'));
        if (packet.full) {
          if (!firstMainAt) firstMainAt = Date.now();
          if (!packet.hasTraffic) return [];
          rf.mergeRows(rows, packet.rows);
          const trafficCount = Array.from(rows.values())
            .filter(row => (row.flags & rf.FLAG_SESSION) === 0).length;
          updateProgress(Math.min(99, (trafficCount / rf.VISIBLE_TRAFFIC_COUNT) * 100));
          if (packet.rows.length < rf.ROW_COUNT) {
            return rf.limitVisibleRows(rows.values());
          }
        }
      } else if (frame.type === rf.TYPE_RF_LOG_HISTORY) {
        const page = rf.parseHistoryPacket(frame.payload);
        gotHistory = true;
        lastHistoryAt = Date.now();
        rf.mergeRows(rows, page);

        const trafficCount = Array.from(rows.values())
          .filter(row => (row.flags & rf.FLAG_SESSION) === 0).length;
        updateProgress(Math.min(99, (trafficCount / rf.VISIBLE_TRAFFIC_COUNT) * 100));
        log(t('rfLogProgress', trafficCount), 'info');

        if (page.length < rf.ROW_COUNT || trafficCount >= rf.VISIBLE_TRAFFIC_COUNT) {
          return rf.limitVisibleRows(rows.values());
        }
      }

      frame = rf.takeViewerFrame(readBuffer);
    }

    const quietSince = gotHistory ? lastHistoryAt : firstMainAt;
    if (quietSince && Date.now() - quietSince >= RF_LOG_HISTORY_IDLE_MS) {
      return rf.limitVisibleRows(rows.values());
    }
    if (!firstMainAt && Date.now() - startedAt >= RF_LOG_INITIAL_TIMEOUT_MS) {
      throw new Error(t('rfLogTimeout'));
    }
    await sleep(25);
  }

  throw new Error(t('rfLogTimeout'));
}

if (rfLogExportBtn) {
  rfLogExportBtn.addEventListener('click', async () => {
    const operation = beginToolsOperation('export-rf-log', false);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);
    if (rfLogDownload) rfLogDownload.style.display = 'none';
    let completed = false;

    try {
      if (!port) await connect();
      readBuffer = [];
      log(t('rfLogReading'), 'info');

      const rows = await collectRfLogRows();
      const trafficCount = rows.filter(row =>
        (row.flags & window.UVTOOLS_RF_LOG.FLAG_SESSION) === 0).length;
      if (trafficCount === 0) throw new Error(t('rfLogEmpty'));

      const csv = window.UVTOOLS_RF_LOG.rowsToCsv(rows);
      if (rfLogDownloadUrl) URL.revokeObjectURL(rfLogDownloadUrl);
      rfLogDownloadUrl = URL.createObjectURL(
        new Blob([csv], { type: 'text/csv;charset=utf-8' })
      );
      if (rfLogLink) {
        rfLogLink.href = rfLogDownloadUrl;
        rfLogLink.download = 'rf-log.csv';
      }
      if (rfLogDownload) rfLogDownload.style.display = 'block';

      updateProgress(100);
      log(t('rfLogComplete', trafficCount), 'success');
      completed = true;
      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      if (!completed) {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }
      if (port) await disconnect();
      endToolsOperation(operation);
    }
  });
}

// ========== UI HELPERS ==========
function log(message, type = '') {
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  if (logDiv) {
    logDiv.appendChild(entry);
    logDiv.scrollTop = logDiv.scrollHeight;
  } else {
    console.log(message);
  }
}

function updateProgress(percent) {
  const rounded = Math.round(percent);
  if (progressFill) progressFill.style.width = `${rounded}%`;
  if (progressLabel) progressLabel.textContent = `${rounded}%`;
  const bar = document.querySelector('.progress-bar');
  if (bar) bar.setAttribute('aria-valuenow', String(rounded));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ========== CAPABILITY CHECK ==========
if (!('serial' in navigator)) {
  log(t('webSerialNotSupported'), 'error');
  updateActionButtons();
}

updateActionButtons();

})();
