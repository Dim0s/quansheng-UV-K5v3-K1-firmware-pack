;(function(){
// js/flash.js
// UV-K5 Web Flasher core logic (Web Serial + protocol)
// Adds: 
// - Auto-load of firmware from URL param ?firmwareURL=... (or ?fw=...)
// - Uses the shared UV Studio i18n runtime (window.uvStudioI18n).
// - Refreshes dynamic tool labels after the shared language changes.
// - Shows progress bar during flashing, hides it after successful completion.
// - Percentage text is centered via #progressLabel overlay.
// - Dump and restore
// - RF Log CSV export

'use strict';

// ========== CONSTANTS ==========
const BAUDRATE = 38400;

// Message types
const MSG_NOTIFY_DEV_INFO = 0x0518;
const MSG_NOTIFY_BL_VER = 0x0530;
const MSG_PROG_FW = 0x0519;
const MSG_PROG_FW_RESP = 0x051A;
const MSG_DEV_INFO_REQ = 0x0514;
const MSG_DEV_INFO_RESP = 0x0515;
const MSG_READ_EEPROM = 0x051B;
const MSG_READ_EEPROM_RESP = 0x051C;
const MSG_WRITE_EEPROM = 0x051D;
const MSG_WRITE_EEPROM_RESP = 0x051E;
const MSG_REBOOT = 0x05DD;
// Full external-flash dump (F4HWN 0x0738 raw physical read; multiboot builds).
const MSG_READ_FLASH = 0x0738;
const MSG_READ_FLASH_RESP = 0x0739;
// Full external-flash restore (F4HWN 0x073A erase / 0x073C write; multiboot).
const MSG_ERASE_FLASH = 0x073A;
const MSG_ERASE_FLASH_RESP = 0x073B;
const MSG_WRITE_FLASH = 0x073C;
const MSG_WRITE_FLASH_RESP = 0x073D;
const MSG_CRC_FLASH = 0x073E;
const MSG_CRC_FLASH_RESP = 0x073F;

const OBFUS_TBL = new Uint8Array([
  0x16, 0x6c, 0x14, 0xe6, 0x2e, 0x91, 0x0d, 0x40,
  0x21, 0x35, 0xd5, 0x40, 0x13, 0x03, 0xe9, 0x80
]);

// Calibration memory layout
const CALIB_SIZE = 512; // bytes
const CHUNK_SIZE = 16;
let CALIB_OFFSET = 0x1E00; // Default for firmware < v5.0.0

// Full external SPI flash (PY25Q16, 2 MiB). Dumped by raw physical address in
// 128-byte chunks (the firmware 0x0739 reply payload is capped at 128 bytes).
const FLASH_TOTAL_SIZE = 0x200000;
const FLASH_DUMP_CHUNK = 128;
// Restore programs sector-by-sector: erase one 4 KiB sector, then write it in
// 128-byte chunks (the firmware 0x073C command buffer caps the payload).
const FLASH_SECTOR_SIZE = 0x1000;
const FLASH_WRITE_CHUNK = 128;
const FLASH_COMMAND_TIMEOUT_MS = 2000;
const FLASH_ERASE_TIMEOUT_MS = 3000;
const FLASH_CRC_PROBE_TIMEOUT_MS = 1000;
const FLASH_COMMAND_RETRIES = 3;
const NAVIGATION_PROBE_TIMEOUT_MS = 1000;
// Calibration is device-specific. Restore deliberately leaves its entire erase
// sector untouched; the boot logo begins in the following sector at 0x011000.
const FLASH_CALIBRATION_SECTOR = 0x010000;

// Factory recovery assets for UV-K1 and UV-K5 V3. Every image is checked before
// any sector is erased. The external images differ only in factory boot-message
// line 2 (UV-K1 / UV-K5); calibration remains device-specific and untouched.
const FACTORY_FLASH_SIZE = 0x200000;
const FACTORY_STATE_A = 0x100000;
const FACTORY_STATE_B = 0x101000;
const FACTORY_TARGETS = Object.freeze({
  k1: Object.freeze({
    label: 'UV-K1',
    flashUrl: 'assets/factory/K1_External_Flash_Factory_Reconstructed.bin',
    flashSha256: 'a2383aa050dc0963fee7b7c99692b8330d9455a6bbb2bb7498b2bba4174c9d55',
    firmwareUrl: 'assets/factory/quansheng.k1.stock.firmware.v7.03.01.bin',
    firmwareSize: 71268,
    firmwareSha256: '55ec0daffc5668bdb41dcc118475d7e6e23ad953d70f57a9bca64a6202734ba0'
  }),
  k5v3: Object.freeze({
    label: 'UV-K5 V3',
    flashUrl: 'assets/factory/K5V3_External_Flash_Factory_Reconstructed.bin',
    flashSha256: 'b85c8066a1b0885d1cf3e430533f45c9c8ea91c8b936a94aba99221fd1bff79b',
    firmwareUrl: 'assets/factory/quansheng.k5v3.stock.firmware.v7.00.11.bin',
    firmwareSize: 71712,
    firmwareSha256: 'f4e5264a6f9a5436a6c75f7b217c60ba002cec04928f247392b9968c5c9458cb'
  })
});

// Boot logo memory layout (mirrors firmware App/ui/welcome.c)
// Layout in flash sector starting at PY25Q16 0x011000, exposed via EEPROM
// compat at 0x00C000:
//   [0x00..0x07] 8-byte magic header "F4HWNLGO"
//   [0x08..0x407] 1024-byte bitmap, ST7565-native column-major LSB-top
const LOGO_EEPROM_OFFSET = 0xC000;
const LOGO_HEADER_SIZE = 8;
const LOGO_BITMAP_SIZE = 1024;
const LOGO_TOTAL_SIZE = LOGO_HEADER_SIZE + LOGO_BITMAP_SIZE; // 1032
// Padded to a CHUNK_SIZE multiple so we can stream by 16-byte chunks like calib.
const LOGO_PADDED_SIZE = Math.ceil(LOGO_TOTAL_SIZE / CHUNK_SIZE) * CHUNK_SIZE; // 1040
const LOGO_MAGIC = new Uint8Array([0x46, 0x34, 0x48, 0x57, 0x4E, 0x4C, 0x47, 0x4F]); // "F4HWNLGO"
const LOGO_WIDTH = 128;
const LOGO_HEIGHT = 64;

// RF Log export timings. History pages are emitted by the firmware at most
// once per display/update cycle, normally every 500 ms.
const RF_LOG_KEEPALIVE_INTERVAL_MS = 200;
const RF_LOG_INITIAL_TIMEOUT_MS = 5000;
const RF_LOG_HISTORY_IDLE_MS = 1500;
const RF_LOG_EXPORT_TIMEOUT_MS = 20000;

// ========== STATE ==========
let port = null;
let reader = null;
let writer = null;
let firmwareData = null;
// Asset pack (fonts, menu texts) carried by the selected firmware package, or
// null for a binary-only firmware. firmwareData then holds the image alone.
let firmwareAssets = null;
// Asset pack still to be written into the running slot of the radio: set when
// a flash (or a slot write) could not write it, and cleared once written. The
// "Install firmware assets" button exists only for it.
let pendingFirmwareAssets = null;
let firmwareFileName = 'firmware.bin';
// Out-of-order guard: only the most recent selection may commit firmwareData.
let firmwareLoadSeq = 0;
let firmwareLoadAbort = null;
// Version of the CHIRP driver currently offered for download, or null when none.
let chirpDriverVersion = null;
let calibData = null;
let flashRestoreData = null;       // Uint8Array of the .bin image to restore
let flashRestoreLoadSeq = 0;
let flashDumpDownloadUrl = null;
let activeOperationToken = null;
let activeOperationName = null;
let activeToolsView = 'flash';
let readBuffer = [];
let serialReadRevision = 0;
const serialReadWaiters = new Set();
let isReading = false;
let toolsSerialSession = 0;
let rfLogDownloadUrl = null;
const serialSupported = 'serial' in navigator;
let toolsLastPortInfo = null;
let toolsHardwareDisconnectPromise = null;
let toolsRefreshPending = false;

// Firmware Slots state
let slotImage = null;   // Uint8Array of the selected .bin
let slotAssets = null;  // asset pack of the selected firmware package, or null
let slotMeta = { name: '', fwVersion: '' };
// Out-of-order guard for the slot image picker (catalog or local file).
let slotImageLoadSeq = 0;
let slotImageLoadAbort = null;
let slotLatestVersions = new Map();
let slotUpdateDownloadPending = false;
let connectedFirmwareName = '';
let firmwareNavigationConnected = false;
let navigationCapabilities = null;

// Logo state
let logoSourceImage = null;       // HTMLImageElement of the user-picked file
let logoBitmap = null;            // Uint8Array(1024) ST7565-native, after threshold/invert

// ========== UI ELEMENTS ==========
const flashBtn = document.getElementById('flashBtn');
const flashAssetsBtn = document.getElementById('flashAssetsBtn');
const flashSteps = document.getElementById('flashSteps');
const dumpBtn = document.getElementById('dumpBtn');
const restoreBtn = document.getElementById('restoreBtn');
const firmwareFileInput = document.getElementById('firmwareFile');
const calibFileInput = document.getElementById('calibFile');
const labelFwFileEl = document.getElementById('labelFirmwareFile');
const labelCalibFileEl = document.getElementById('labelCalibFile');
const logDiv = document.getElementById('log');
const infoBoxEl = document.getElementById('infoBox');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressLabel = document.getElementById('progressLabel');
const logToggle = document.getElementById('logToggle');
const languageSelect = document.getElementById('languageSelect');
const dumpDownload = document.getElementById('dumpDownload');
const dumpLink = document.getElementById('dumpLink');
const flashDumpBtn = document.getElementById('flashDumpBtn');
const flashDumpDownload = document.getElementById('flashDumpDownload');
const flashDumpLink = document.getElementById('flashDumpLink');
const flashRestoreBtn = document.getElementById('flashRestoreBtn');
const flashFileInput = document.getElementById('flashFile');
const flashFileName = document.getElementById('flashFileName');
const flashFileButton = document.getElementById('flashFileButton');
const flashFileLabel = document.getElementById('flashFileLabel');
const labelFlashFileEl = document.getElementById('labelFlashFile');
const flashRestoreConfirmModal = document.getElementById('flashRestoreConfirmModal');
const flashRestoreConfirmClose = document.getElementById('flashRestoreConfirmClose');
const flashRestoreConfirmBody = document.getElementById('flashRestoreConfirmBody');
const flashRestoreCancelBtn = document.getElementById('flashRestoreCancelBtn');
const flashRestoreConfirmBtn = document.getElementById('flashRestoreConfirmBtn');
const factoryResetK1Btn = document.getElementById('factoryResetK1Btn');
const factoryResetK5V3Btn = document.getElementById('factoryResetK5V3Btn');
const factoryResetButtons = [factoryResetK1Btn, factoryResetK5V3Btn].filter(Boolean);
const factoryResetDescription = document.getElementById('factoryResetDescription');
const factoryResetModal = document.getElementById('factoryResetModal');
const factoryResetTitle = document.getElementById('factoryResetTitle');
const factoryResetBody = document.getElementById('factoryResetBody');
const factoryResetClose = document.getElementById('factoryResetClose');
const factoryResetCancelBtn = document.getElementById('factoryResetCancelBtn');
const factoryResetConfirmBtn = document.getElementById('factoryResetConfirmBtn');
const chirpDriverDownload = document.getElementById('chirpDriverDownload');
const chirpDriverLink = document.getElementById('chirpDriverLink');
const chirpDriverText = document.getElementById('chirpDriverText');
const appsNavigationItem = document.querySelector('[data-route="apps"]');
const externalFlashNavigationItem = document.querySelector('[data-route="external-flash"]');
const factoryResetNavigationItem = document.querySelector('[data-route="factory-reset"]');
const appsNavigationTag = appsNavigationItem?.querySelector('.tag');
const externalFlashNavigationTag = externalFlashNavigationItem?.querySelector('.tag');
const factoryResetNavigationTag = factoryResetNavigationItem?.querySelector('.tag');

// File input labels
const fileLabel = document.getElementById('fileLabel');
const fileName = document.getElementById('fileName');
const fileButton = document.getElementById('fileButton');
const calibFileLabel = document.getElementById('calibFileLabel');
const calibFileName = document.getElementById('calibFileName');
const calibFileButton = document.getElementById('calibFileButton');

// Logo UI
const logoFileInput = document.getElementById('logoFile');
const logoFileLabel = document.getElementById('logoFileLabel');
const logoFileName = document.getElementById('logoFileName');
const logoFileButton = document.getElementById('logoFileButton');
const logoControls = document.getElementById('logoControls');
const logoThresholdInput = document.getElementById('logoThreshold');
const logoThresholdValue = document.getElementById('logoThresholdValue');
const logoInvertInput = document.getElementById('logoInvert');
const logoPreviewCanvas = document.getElementById('logoPreviewCanvas');
const logoUploadBtn = document.getElementById('logoUploadBtn');
const logoDumpBtn = document.getElementById('logoDumpBtn');
const logoDumpDownload = document.getElementById('logoDumpDownload');
const logoDumpResult = document.getElementById('logoDumpResult');
const logoDumpedCanvas = document.getElementById('logoDumpedCanvas');
const logoDumpLink = document.getElementById('logoDumpLink');

// Firmware Slots (multiboot) UI
const slotFileInput = document.getElementById('slotFile');
const slotFileLabel = document.getElementById('slotFileLabel');
const slotFileName = document.getElementById('slotFileName');
const slotFileButton = document.getElementById('slotFileButton');
const slotTargetSelect = document.getElementById('slotTarget');
const slotNameInput = document.getElementById('slotName');
const slotWriteBtn = document.getElementById('slotWriteBtn');
const slotsRefreshBtn = document.getElementById('slotsRefreshBtn');
const slotsTableBody = document.getElementById('slotsTableBody');
const slotMetaEl = document.getElementById('slotMeta');
const rfLogExportBtn = document.getElementById('rfLogExportBtn');
const rfLogDownload = document.getElementById('rfLogDownload');
const rfLogLink = document.getElementById('rfLogLink');

// ========== VERSION COMPARISON ==========
function isBootloaderCompatible(version, minVersion) {
  // Parse version strings (e.g., "7.02.02")
  const parseVersion = (v) => {
    const parts = v.split('.').map(p => parseInt(p, 10) || 0);
    while (parts.length < 3) parts.push(0);
    return parts;
  };
  
  const current = parseVersion(version);
  const required = parseVersion(minVersion);
  
  // Compare major.minor.patch
  for (let i = 0; i < 3; i++) {
    if (current[i] > required[i]) return true;
    if (current[i] < required[i]) return false;
  }
  
  return true; // Equal versions are compatible
}

// ========== i18n HELPER ==========
function t(key, ...args) {
  return window.uvStudioI18n ? window.uvStudioI18n.t(key, ...args) : key;
}

function firmwareUsesServiceNavigation(deviceInfoName) {
  const match = String(deviceInfoName || '').match(/\bv(\d+)(?:\.(\d+))?/i);
  if (!match) return false;

  // Historical compact versions use v50 for v5.0 and v70 for v7.0.
  // Dotted versions expose the major component directly.
  if (match[2] !== undefined) return Number(match[1]) >= 7;
  const compactVersion = Number(match[1]);
  return match[1].length === 1 ? compactVersion >= 7 : compactVersion >= 70;
}

function updateNavigationTag(element, key, hidden) {
  if (!element) return;
  element.hidden = hidden;
  element.setAttribute('data-i18n', key);
  element.textContent = t(key);
}

function renderFirmwareNavigationTags() {
  if (!firmwareNavigationConnected) {
    updateNavigationTag(appsNavigationTag, 'studio_nav_labs_only', true);
    updateNavigationTag(externalFlashNavigationTag, 'studio_nav_labs_only', true);
    updateNavigationTag(factoryResetNavigationTag, 'studio_nav_labs_only', true);
    return;
  }

  const serviceNavigation = firmwareUsesServiceNavigation(connectedFirmwareName);
  if (serviceNavigation) {
    const fusionRequired = navigationCapabilities?.apps === false;
    const serviceRequired = navigationCapabilities?.externalFlash === false;
    updateNavigationTag(appsNavigationTag, 'studio_nav_fusion_only', !fusionRequired);
    updateNavigationTag(externalFlashNavigationTag, 'studio_nav_service_only', !serviceRequired);
    updateNavigationTag(factoryResetNavigationTag, 'studio_nav_service_only', !serviceRequired);
    return;
  }

  const labsAppsRequired = navigationCapabilities?.apps === false;
  const labsFlashRequired = navigationCapabilities?.externalFlash === false;
  updateNavigationTag(appsNavigationTag, 'studio_nav_labs_only', !labsAppsRequired);
  updateNavigationTag(externalFlashNavigationTag, 'studio_nav_labs_only', !labsFlashRequired);
  updateNavigationTag(factoryResetNavigationTag, 'studio_nav_labs_only', !labsFlashRequired);
}

function applyFirmwareNavigationPolicy(deviceInfoName, connected) {
  if (deviceInfoName !== undefined) {
    connectedFirmwareName = String(deviceInfoName || '');
    if (connected === undefined) firmwareNavigationConnected = true;
  }
  if (connected !== undefined) firmwareNavigationConnected = connected;
  renderFirmwareNavigationTags();
}

function updateNavigationCapability(element, supported) {
  if (!element) return;
  element.dataset.capabilityKnown = String(typeof supported === 'boolean');
  if (supported === false) {
    element.dataset.capabilityDisabled = 'true';
    element.setAttribute('data-i18n-title', 'studio_nav_unavailable_edition');
    element.title = t('studio_nav_unavailable_edition');
  } else {
    delete element.dataset.capabilityDisabled;
    element.removeAttribute('data-i18n-title');
    element.removeAttribute('title');
  }
}

function shouldKeepFirmwareNavigationProfile(context) {
  const nextOwner = context?.nextOwner;
  return (context?.reason === 'navigation' || context?.reason === 'handoff') &&
    (nextOwner === 'tools' || nextOwner === 'viewer');
}

function shouldClearFirmwareNavigationOnSerialState(detail) {
  if (detail?.state === 'reconnecting' && detail.owner === 'viewer') return true;
  return detail?.state === 'disconnected' && detail.previousOwner === 'viewer' &&
    !shouldKeepFirmwareNavigationProfile(detail);
}

function clearFirmwareNavigationProfile() {
  applyFirmwareNavigationPolicy('', false);
  applyNavigationCapabilities(null);
}

function applyNavigationCapabilities(capabilities) {
  let resolvedCapabilities = capabilities || null;
  if (resolvedCapabilities && !firmwareUsesServiceNavigation(connectedFirmwareName)) {
    const labsFirmware = resolvedCapabilities.apps === true &&
      resolvedCapabilities.externalFlash === true;
    resolvedCapabilities = {
      ...resolvedCapabilities,
      apps: labsFirmware,
      externalFlash: labsFirmware
    };
  }

  navigationCapabilities = resolvedCapabilities;
  updateNavigationCapability(appsNavigationItem, resolvedCapabilities?.apps);
  updateNavigationCapability(externalFlashNavigationItem, resolvedCapabilities?.externalFlash);
  updateNavigationCapability(factoryResetNavigationItem, resolvedCapabilities?.externalFlash);
  renderFirmwareNavigationTags();
  window.dispatchEvent(new CustomEvent('uvstudio:navigationcapabilitieschange'));
}

async function detectNavigationCapabilities(deviceInfo) {
  const session = toolsSerialSession;
  let apps = false;
  let externalFlash = false;

  try {
    await appInfo(APP_SLOT_FIRST, NAVIGATION_PROBE_TIMEOUT_MS);
    apps = true;
  } catch (error) {
    if (error?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' ||
        session !== toolsSerialSession || !port) throw error;
  }

  try {
    await readExternalFlashChunk(
      0, 1, deviceInfo.timestamp, NAVIGATION_PROBE_TIMEOUT_MS, 0
    );
    externalFlash = true;
  } catch (error) {
    if (error?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' ||
        session !== toolsSerialSession || !port) throw error;
  }

  if (session !== toolsSerialSession) {
    throw Object.assign(new Error(t('tools_disconnected')), {
      code: 'UVSTUDIO_SERIAL_SESSION_CHANGED'
    });
  }
  applyNavigationCapabilities({ apps, externalFlash });
}

// ========== UI UPDATE ==========
function refreshLocalizedToolsState() {
  applyFirmwareNavigationPolicy();
  if (labelFwFileEl) labelFwFileEl.textContent = t('labelFirmwareFile');
  if (labelCalibFileEl) labelCalibFileEl.textContent = t('labelCalibFile');

  // Update info box based on active tab
  updateInfoBox();
  
  if (flashBtn) flashBtn.textContent = t('flashBtn');
  if (flashAssetsBtn) flashAssetsBtn.textContent = t('flashAssetsBtn');
  if (dumpBtn) dumpBtn.textContent = t('dumpBtn');
  if (restoreBtn) restoreBtn.textContent = t('restoreBtn');
  if (fileButton) fileButton.textContent = t('fileChoose');
  if (calibFileButton) calibFileButton.textContent = t('fileChoose');

  // Description
  const dumpDesc = document.getElementById('dumpDescription');
  const downloadText = document.getElementById('downloadText');
  if (dumpDesc) dumpDesc.textContent = t('dumpDescription');
  if (downloadText) downloadText.textContent = t('downloadText');

  // Dump external flash labels
  const flashDumpDesc = document.getElementById('flashDumpDescription');
  const flashDumpDownloadText = document.getElementById('flashDumpDownloadText');
  if (flashDumpDesc) flashDumpDesc.textContent = t('flashDumpDescription');
  if (flashDumpBtn) flashDumpBtn.textContent = t('flashDumpBtn');
  if (flashDumpDownloadText) flashDumpDownloadText.textContent = t('flashDumpDownloadText');
  const flashRestoreDesc = document.getElementById('flashRestoreDescription');
  if (flashRestoreDesc) flashRestoreDesc.textContent = t('flashRestoreDescription');
  if (flashRestoreBtn) flashRestoreBtn.textContent = t('flashRestoreBtn');
  if (factoryResetDescription) factoryResetDescription.textContent = t('factoryResetDescription');
  if (factoryResetK1Btn) factoryResetK1Btn.textContent = t('factoryResetK1Btn');
  if (factoryResetK5V3Btn) factoryResetK5V3Btn.textContent = t('factoryResetK5V3Btn');
  if (labelFlashFileEl) labelFlashFileEl.textContent = t('labelFlashFile');
  if (flashFileButton) flashFileButton.textContent = t('fileChoose');
  if (flashFileName && !flashRestoreData) {
    flashFileName.textContent = t('fileNoFile');
    flashFileName.classList.remove('has-file');
    if (flashFileLabel) flashFileLabel.classList.remove('has-file');
  }
  if (factoryResetModal?.classList.contains('show')) renderFactoryResetModal();

  // RF Log labels
  const rfLogDescription = document.getElementById('rfLogDescription');
  const rfLogDownloadText = document.getElementById('rfLogDownloadText');
  if (rfLogDescription) rfLogDescription.textContent = t('rfLogDescription');
  if (rfLogDownloadText) rfLogDownloadText.textContent = t('rfLogDownloadText');
  if (rfLogExportBtn) rfLogExportBtn.textContent = t('rfLogExportBtn');

  // Logo labels
  const labelLogoFile = document.getElementById('labelLogoFile');
  const labelLogoThreshold = document.getElementById('labelLogoThreshold');
  const labelLogoInvert = document.getElementById('labelLogoInvert');
  const labelLogoPreview = document.getElementById('labelLogoPreview');
  const logoUploadDesc = document.getElementById('logoUploadDescription');
  const logoDumpDesc = document.getElementById('logoDumpDescription');
  const logoDumpedLabel = document.getElementById('logoDumpedLabel');
  const logoDumpDownloadText = document.getElementById('logoDumpDownloadText');
  if (labelLogoFile) labelLogoFile.textContent = t('labelLogoFile');
  if (labelLogoThreshold) labelLogoThreshold.textContent = t('labelLogoThreshold');
  if (labelLogoInvert) labelLogoInvert.textContent = t('labelLogoInvert');
  if (labelLogoPreview) labelLogoPreview.textContent = t('labelLogoPreview');
  if (logoUploadDesc) logoUploadDesc.textContent = t('logoUploadDescription');
  if (logoDumpDesc) logoDumpDesc.textContent = t('logoDumpDescription');
  if (logoDumpedLabel) logoDumpedLabel.textContent = t('logoDumpedLabel');
  if (logoDumpDownloadText) logoDumpDownloadText.textContent = t('logoDumpDownloadText');
  if (logoUploadBtn) logoUploadBtn.textContent = t('logoUploadBtn');
  if (logoDumpBtn) logoDumpBtn.textContent = t('logoDumpBtn');
  if (logoFileButton) logoFileButton.textContent = t('fileChoose');
  if (logoFileName && !logoSourceImage) {
    logoFileName.textContent = t('fileNoFile');
    logoFileName.classList.remove('has-file');
    if (logoFileLabel) logoFileLabel.classList.remove('has-file');
  }

  // Log toggle
  if (logToggle) {
    const visible = logDiv && logDiv.classList.contains('visible');
    logToggle.textContent = visible ? t('logHide') : t('logShow');
    logToggle.setAttribute('aria-expanded', visible ? 'true' : 'false');
  }

  // File names
  if (fileName && !firmwareData) {
    fileName.textContent = t('fileNoFile');
    fileName.classList.remove('has-file');
    if (fileLabel) fileLabel.classList.remove('has-file');
  }

  if (calibFileName && !calibData) {
    calibFileName.textContent = t('fileNoFile');
    calibFileName.classList.remove('has-file');
    if (calibFileLabel) calibFileLabel.classList.remove('has-file');
  }

  if (chirpDriverText && chirpDriverVersion) {
    chirpDriverText.textContent = t('flash_chirp_driver_download', chirpDriverVersion);
  }

  if (languageSelect && window.uvStudioI18n) {
    languageSelect.value = window.uvStudioI18n.lang;
  }
}

// Update info box based on active tab
function updateInfoBox() {
  if (!infoBoxEl) return;

  const tabName = activeToolsView;

  if (tabName === 'flash') {
    infoBoxEl.innerHTML = t('infoBox');
  } else if (tabName === 'rf-log') {
    infoBoxEl.innerHTML = t('infoBoxRfLog');
  } else if (tabName === 'logo-upload' || tabName === 'logo-dump') {
    infoBoxEl.innerHTML = t('infoBoxLogo');
  } else if (tabName === 'slots') {
    infoBoxEl.innerHTML = t('infoBoxSlots');
  } else if (tabName === 'apps') {
    infoBoxEl.innerHTML = t('infoBoxApps');
  } else {
    infoBoxEl.innerHTML = t('infoBoxDump');
  }
}

// Refresh dynamic tool labels after the shared language changes.
window.addEventListener('uvstudio:languagechange', () => {
  refreshLocalizedToolsState();
  slotLocalize();
});

window.addEventListener('uvstudio:toolviewchange', event => {
  const nextView = event.detail?.view || 'flash';
  activeToolsView = nextView;
  updateInfoBox();
  if (nextView === 'slots' && port && writer &&
      toolsSerial.isOwner() && !activeOperationToken) {
    void slotRefreshFlow();
  }
});

// Initial i18n sync
(async () => {
  if (window.uvStudioI18nReady) await window.uvStudioI18nReady;
  refreshLocalizedToolsState();
  await maybeLoadFirmwareFromQuery();
})();

// ========== LOG VISIBILITY ==========
if (logToggle) {
  logToggle.addEventListener('click', () => {
    if (!logDiv) return;
    logDiv.classList.toggle('visible');
    logToggle.textContent = logDiv.classList.contains('visible') ? t('logHide') : t('logShow');
    logToggle.setAttribute('aria-expanded', logDiv.classList.contains('visible') ? 'true' : 'false');
  });
}

// ========== FIRMWARE FILE INPUT ==========
if (firmwareFileInput) {
  firmwareFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const seq = beginFirmwareLoad('local');
    const fr = new FileReader();
    fr.onload = (ev) => { if (seq === firmwareLoadSeq) setFirmwareBuffer(ev.target.result, file.name); };
    fr.readAsArrayBuffer(file);
  });
}

// Start a new firmware selection: bump the generation so any earlier in-flight
// load is ignored on completion, cancel a pending download, and keep the two
// sources (catalog vs local file) mutually exclusive.
function beginFirmwareLoad(source) {
  const seq = ++firmwareLoadSeq;
  if (firmwareLoadAbort) { try { firmwareLoadAbort.abort(); } catch (e) {} firmwareLoadAbort = null; }
  // The previous firmware is no longer current: make it unavailable so Flash is
  // disabled until the new selection has finished loading.
  firmwareData = null;
  firmwareAssets = null;
  updateFlashButton();
  if (source === 'url' && firmwareFileInput) firmwareFileInput.value = '';
  window.dispatchEvent(new CustomEvent('uvstudio:firmwareselect', { detail: { source } }));
  return seq;
}

function clearFirmware() {
  firmwareData = null;
  firmwareAssets = null;
  if (fileName) { fileName.textContent = t('fileNoFile'); fileName.classList.remove('has-file'); }
  if (fileLabel) fileLabel.classList.remove('has-file');
  updateFlashButton();
}

function setFirmwareBuffer(buf, name = 'firmware.bin') {
  let parts;
  try {
    parts = window.UVStudioFirmwarePackage.splitFirmwarePackage(new Uint8Array(buf));
  } catch (e) {
    log(t('fwPackageInvalid', name, e?.message ?? String(e)), 'error');
    clearFirmware();
    return;
  }
  firmwareData = parts.image;
  firmwareAssets = parts.pack;
  resetFlashSteps();
  firmwareFileName = name;
  hideChirpDriverOffer();
  if (fileName) {
    fileName.textContent = name;
    fileName.classList.add('has-file');
  }
  if (fileLabel) fileLabel.classList.add('has-file');
  log(t('firmwareLoaded', name, firmwareData.length), 'success');
  if (firmwareAssets) log(t('fwAssetsDetected', firmwareAssets.length), 'info');
  updateFlashButton();
}

// ---------- CHIRP driver offer ----------
// All stable F4HWN editions share the matching CHIRP driver release asset named
// f4hwn.fusion.chirp.v<version>.py (one driver covers Fusion, FieldOps, Transfer,
// Labs, UV-K1 and UV-K5 V3). After a successful flash, resolve the driver
// for the flashed version and offer it.
const CHIRP_DRIVER_REPO = 'armel/uv-k1-k5v3-firmware-custom';

function hideChirpDriverOffer() {
  chirpDriverVersion = null;
  if (chirpDriverDownload) chirpDriverDownload.style.display = 'none';
}

function showChirpDriverOffer(version, url) {
  if (!chirpDriverDownload || !chirpDriverLink) return;
  chirpDriverVersion = version;
  chirpDriverLink.href = url;
  if (chirpDriverText) chirpDriverText.textContent = t('flash_chirp_driver_download', version);
  chirpDriverDownload.style.display = 'block';
  log(t('chirpDriverAvailable', version), 'success');
}

// Best-effort: resolve and offer the CHIRP driver for the flashed firmware.
// Never throws — a missing driver or network hiccup must not disturb the flash.
async function maybeOfferChirpDriver(fname) {
  try {
    const parse = window.UVStudioFlashCatalog?.parseFirmwareName;
    const info = parse ? parse(fname) : null;
    const hasSharedDriver = window.UVStudioFlashCatalog?.hasSharedChirpDriver;
    if (!hasSharedDriver || !hasSharedDriver(info)) return;

    const tag = `v${info.version}`;
    const apiUrl =
      `https://api.github.com/repos/${CHIRP_DRIVER_REPO}/releases/tags/${encodeURIComponent(tag)}`;
    const res = await fetch(apiUrl, { cache: 'no-cache', mode: 'cors' });
    if (!res.ok) return; // no release for this version → nothing to offer

    const release = await res.json();
    const asset = (release.assets || []).find(
      a => /chirp/i.test(a.name) && /\.py$/i.test(a.name)
    );
    if (!asset || !asset.browser_download_url) return;

    showChirpDriverOffer(info.version, asset.browser_download_url);
  } catch (e) {
    // Swallowed on purpose: the driver offer is a bonus, never a failure path.
  }
}

// ---------- Auto-load firmware from URL ----------

function normalizeFirmwareDownloadURL(url) {
  const urlObj = new URL(url);

  if (urlObj.protocol !== 'https:') {
    throw new Error(t('urlHttpNotHttps'));
  }

  // GitHub convenience: github.com/.../raw/... → raw.githubusercontent.com/...
  if (urlObj.hostname === 'github.com' && urlObj.pathname.includes('/raw/')) {
    const parts = urlObj.pathname.split('/').filter(Boolean);
    const i = parts.indexOf('raw');
    if (i > 1 && i < parts.length - 1) {
      const user = parts[0];
      const repo = parts[1];
      const branch = parts[i + 1];
      const rest = parts.slice(i + 2).join('/');
      urlObj.hostname = 'raw.githubusercontent.com';
      urlObj.pathname = `/${user}/${repo}/${branch}/${rest}`;
    }
  }

  return urlObj;
}

async function loadFirmwareFromURL(url) {
  const seq = beginFirmwareLoad('url');
  const controller = new AbortController();
  firmwareLoadAbort = controller;
  try {
    log(t('loadingFromUrl', url), 'info');

    const urlObj = normalizeFirmwareDownloadURL(url);

    const res = await fetch(urlObj.toString(), { cache: 'no-cache', mode: 'cors', signal: controller.signal });
    if (!res.ok) {
      throw new Error(`${t('urlFetchError')} HTTP ${res.status}`);
    }

    const buf = await res.arrayBuffer();
    if (seq !== firmwareLoadSeq) return; // superseded by a newer selection

    const fname = (urlObj.pathname.split('/').pop() || 'firmware.bin').split('?')[0];

    setFirmwareBuffer(buf, fname);

    // Clean URL so refresh does not re-trigger auto-load
    const clean = new URL(window.location.href);
    clean.searchParams.delete('firmwareURL');
    clean.searchParams.delete('fw');
    window.history.replaceState({}, '', clean.toString());
  } catch (err) {
    if (err && err.name === 'AbortError') return; // cancelled by a newer selection
    log(`${t('urlFetchError')} ${err?.message ?? String(err)}`, 'error');
    if (seq === firmwareLoadSeq) clearFirmware();
  } finally {
    if (firmwareLoadAbort === controller) firmwareLoadAbort = null;
  }
}

async function maybeLoadFirmwareFromQuery() {
  try {
    const params = new URLSearchParams(window.location.search);
    const param = params.get('firmwareURL') || params.get('fw');
    if (!param) return;
    await loadFirmwareFromURL(decodeURIComponent(param));
  } catch (e) {
    log(t('urlInvalid'), 'error');
  }
}

// Minimal entry point so the firmware catalog picker can reuse the URL loader.
window.UVStudioFlash = Object.freeze({
  loadFirmwareFromURL,
  loadSlotFirmwareFromURL,
  loadAppFromURL,
  installAppFromURL,
  updateAppFromURL,
  deleteAppSlot,
  clearAppFromCatalog: () => beginAppImageLoad('catalog'),
  hasFirmware: () => Boolean(firmwareData),
  // App submission panel: the radio connected here, its screen and firmware.
  radioConnected: () => Boolean(port && writer && toolsSerial.isOwner()),
  captureScreen: captureRadioScreen,
  radioFirmwareName: () => appCurrentFirmwareName
});

function updateFlashButton() {
  updateActionButtons();
}

// ========== CALIBRATION FILE INPUT ==========
if (calibFileInput) {
  calibFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = (ev) => {
      const buf = new Uint8Array(ev.target.result);
      if (buf.length !== CALIB_SIZE) {
        log(t('calibInvalidSize', buf.length), 'error');
        return;
      }
      calibData = buf;
      if (calibFileName) {
        calibFileName.textContent = file.name;
        calibFileName.classList.add('has-file');
      }
      if (calibFileLabel) calibFileLabel.classList.add('has-file');
      log(t('calibLoaded', file.name, calibData.length), 'success');
      updateRestoreButton();
    };
    fr.readAsArrayBuffer(file);
  });
}

// ========== EXTERNAL FLASH RESTORE FILE INPUT ==========
if (flashFileInput) {
  flashFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const loadSeq = ++flashRestoreLoadSeq;
    flashRestoreData = null;
    if (flashFileName) {
      flashFileName.textContent = t('fileNoFile');
      flashFileName.classList.remove('has-file');
    }
    if (flashFileLabel) flashFileLabel.classList.remove('has-file');
    updateActionButtons();
    const fr = new FileReader();
    fr.onload = (ev) => {
      if (loadSeq !== flashRestoreLoadSeq) return;
      const buf = new Uint8Array(ev.target.result);
      // The dump produces exactly 2 MiB; require the same so a partial or wrong
      // file can never be written over the whole chip.
      if (buf.length !== FLASH_TOTAL_SIZE) {
        log(t('flashInvalidSize', buf.length), 'error');
        flashFileInput.value = '';
        return;
      }
      flashRestoreData = buf;
      if (flashFileName) {
        flashFileName.textContent = file.name;
        flashFileName.classList.add('has-file');
      }
      if (flashFileLabel) flashFileLabel.classList.add('has-file');
      log(t('flashLoaded', file.name, flashRestoreData.length), 'success');
      updateActionButtons();
    };
    fr.readAsArrayBuffer(file);
  });
}

function updateRestoreButton() {
  updateActionButtons();
}

// ========== SERIAL CONNECTION ==========
// Write the assets of the selected firmware package into the running slot:
// completes a flash whose serial link did not survive the reboot, or a
// multiboot slot restored without its assets.
if (flashAssetsBtn) {
  flashAssetsBtn.addEventListener('click', async () => {
    const assets = pendingFirmwareAssets;
    if (!assets) return;
    const operation = beginToolsOperation('flash-assets', true);
    if (!operation) return;
    try {
      if (!port) await connect({ reuse: true, remember: true });
      readBuffer = [];
      await sleep(500);
      const dev = await requestDeviceInfo();
      if (progressContainer) progressContainer.style.display = 'block';
      updateProgress(0);
      setFlashStep('restart', 'done', 'flash_step_detected');
      setFlashStep('assets', 'active');
      await writeFirmwareAssets(ASSET_RUNNING_SLOT, assets, dev.timestamp, fraction => {
        setFlashStepProgress('assets', fraction);
        return updateProgress(fraction * 100);
      });
      updateProgress(100);
      setFlashStep('assets', 'done', 'flash_step_done');
      setFlashStepsComplete(true);
      pendingFirmwareAssets = null;
    } catch (e) {
      failActiveFlashStep();
      log(t('fwAssetsError', e?.message ?? String(e)), 'error');
    } finally {
      hideProgressSoon();
      if (port) await disconnect();
      endToolsOperation(operation);
    }
  });
}

async function connect(options = {}) {
  let reusedPort = null;
  try {
    if (port && writer && toolsSerial.isOwner()) return;
    stopToolsReconnect({ forgetPortInfo: true });
    await toolsSerial.acquire({ source: 'tools' });
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }
    log(t('requestingPort'), 'info');
    reusedPort = options.reuse === false ? null : toolsSerial.getReusablePort();
    port = reusedPort || await navigator.serial.requestPort();
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }
    log(t('openingPort'), 'info');
    await port.open({ baudRate: BAUDRATE, bufferSize: 65536 });
    if (!toolsSerial.isOwner()) {
      try { await port.close(); } catch {}
      port = null;
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }

    log(t('gettingReader'), 'info');
    reader = port.readable.getReader();
    log(t('gettingWriter'), 'info');
    writer = port.writable.getWriter();
    if (options.remember !== false) toolsSerial.rememberPort(port);
    toolsSerialSession++;
    toolsLastPortInfo = options.remember === false ? null : port.getInfo();

    log(t('startingRead'), 'info');
    startReading();

    log(t('waiting500ms'), 'info');
    await sleep(500);
    if (!toolsSerial.isOwner()) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
    }

    if (options.remember !== false) {
      applyFirmwareNavigationPolicy('', false);
      applyNavigationCapabilities(null);
      readBuffer = [];
      let deviceInfoDetected = false;
      try {
        const deviceInfo = await requestDeviceInfo({ timeoutMs: 1500 });
        deviceInfoDetected = true;
        await detectNavigationCapabilities(deviceInfo);
      } catch (error) {
        console.warn('Unable to detect the connected firmware capabilities:', error);
      }
      if (!toolsSerial.isOwner()) {
        throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_RELEASED' });
      }
      if (!deviceInfoDetected) applyFirmwareNavigationPolicy('', true);
    }

    log(t('connected'), 'success');
    toolsSerial.setState('connected', { reason: 'connection-established' });
  } catch (e) {
    if (reusedPort) toolsSerial.forgetPort(reusedPort);
    if (toolsSerial.isOwner()) {
      await toolsSerial.release('connection-error');
    } else {
      await disconnectPort({ reason: 'connection-cancelled' });
    }
    if (e?.code !== 'UVSTUDIO_SERIAL_RELEASED') {
      log(t('connectionError', e?.message ?? String(e)), 'error');
    }
    throw e;
  }
}

async function disconnectPort(context = {}) {
  const hardwareDisconnect = context.reason === 'hardware-disconnect';
  if (!hardwareDisconnect) stopToolsReconnect({ forgetPortInfo: true });
  isReading = false;
  const activeReader = reader;
  const activeWriter = writer;
  const activePort = port;
  if (hardwareDisconnect && activePort) toolsSerial.forgetPort(activePort);
  reader = null;
  writer = null;
  port = null;
  if (activeReader || activeWriter || activePort) toolsSerialSession++;
  notifySerialRead();

  await window.UVStudioSerial.closeResources({
    reader: activeReader,
    writer: activeWriter,
    port: activePort
  });
  if (!shouldKeepFirmwareNavigationProfile(context)) {
    clearFirmwareNavigationProfile();
  }
  if (context.reason === 'operation-complete' || context.reason === 'user') {
    log(t('tools_disconnected'), 'info');
  }
}

const toolsSerial = window.UVStudioSerial.register('tools', {
  disconnect: disconnectPort
});

const toolsReconnect = window.UVStudioSerial.createReconnectManager({
  canAttempt: () => toolsViewUsesRuntimeSerial() &&
    toolsSerial.isOwner() && !activeOperationToken,
  reconnect: reconnectToolsPort,
  onError: error => console.warn('Unable to enumerate serial ports during tools reconnect:', error),
  onStateChange: () => {
    updateActionButtons();
    runPendingToolsRefresh();
  }
});

window.addEventListener('uvstudio:serialrequired', event => {
  if (event.detail?.owner !== 'tools' || event.detail.promise) return;
  event.detail.promise = connect({ reuse: true, remember: true });
});

window.addEventListener('uvstudio:serialstatechange', event => {
  if (shouldClearFirmwareNavigationOnSerialState(event.detail)) {
    clearFirmwareNavigationProfile();
  }
});

window.addEventListener('uvstudio:firmwareprofiledetected', event => {
  const detail = event.detail;
  const snapshot = window.UVStudioSerial?.getSnapshot();
  if (!detail?.name || !detail.capabilities ||
      snapshot?.owner !== 'viewer' || snapshot.state !== 'connected') return;
  applyFirmwareNavigationPolicy(detail.name, true);
  applyNavigationCapabilities(detail.capabilities);
});

// Steps shown under the Flash button for a firmware that carries assets:
// image, radio restart, assets. Each step is pending, active, done or error,
// has its own gauge (the global one stays for binary-only firmwares) and a
// note whose i18n key is kept, so a language change redraws it.
const FLASH_STEPS = ['image', 'restart', 'assets'];

function flashStepElement(step) {
  return flashSteps?.querySelector(`[data-step="${step}"]`) || null;
}

function setFlashStep(step, state, noteKey = null) {
  const element = flashStepElement(step);
  if (!element) return;
  if (state) element.dataset.state = state;
  else delete element.dataset.state;
  delete element.dataset.wait;

  const key = noteKey || `flash_step_${step}_hint`;
  const note = element.querySelector('.flash-step-note');
  if (note) {
    note.setAttribute('data-i18n', key);
    note.textContent = t(key);
  }
  const mark = element.querySelector('.flash-step-mark');
  if (mark) mark.textContent = state === 'done' ? '\u2713' : state === 'error' ? '!' : String(FLASH_STEPS.indexOf(step) + 1);
  const fill = element.querySelector('.flash-step-fill');
  if (fill && state === 'error' && !fill.style.width) fill.style.width = '100%';
  if (fill && (state === 'done' || !state)) fill.style.width = '';
  const pct = element.querySelector('.flash-step-pct');
  if (pct && state !== 'active') pct.textContent = '';
}

// Waiting for the radio: active, with moving stripes instead of a percentage.
function setFlashStepWaiting(step) {
  setFlashStep(step, 'active', 'flash_step_waiting');
  const element = flashStepElement(step);
  if (element) element.dataset.wait = 'true';
}

// Returns true when the shown percentage changed (to let the browser paint).
function setFlashStepProgress(step, fraction) {
  const element = flashStepElement(step);
  if (!element) return false;
  const label = `${Math.round(Math.min(1, Math.max(0, fraction)) * 100)}%`;
  const pct = element.querySelector('.flash-step-pct');
  const fill = element.querySelector('.flash-step-fill');
  const changed = Boolean(pct && pct.textContent !== label);
  if (pct) pct.textContent = label;
  if (fill) fill.style.width = label;
  return changed;
}

function failActiveFlashStep() {
  FLASH_STEPS.forEach(step => {
    if (flashStepElement(step)?.dataset.state === 'active') setFlashStep(step, 'error', 'flash_step_failed');
  });
}

// Once the assets are written, the cable reminder becomes "you can unplug".
function setFlashStepsComplete(complete) {
  if (!flashSteps) return;
  flashSteps.dataset.complete = String(complete);
  const hint = flashSteps.querySelector('#flashStepsHint');
  if (!hint) return;
  const key = complete ? 'flash_unplug_done' : 'flash_unplug_warning';
  hint.setAttribute('data-i18n', key);
  hint.textContent = t(key);
}

function resetFlashSteps() {
  FLASH_STEPS.forEach(step => setFlashStep(step, null));
  setFlashStepsComplete(false);
}

function updateActionButtons() {
  const busy = Boolean(activeOperationToken) || toolsReconnect.isActive() ||
    toolsReconnect.isAttempting() || slotUpdateDownloadPending;
  const slotNameValid = Boolean(slotNormalizeName(slotNameInput?.value ?? slotMeta.name));
  if (flashBtn) flashBtn.disabled = !serialSupported || busy || !firmwareData;
  if (flashSteps) flashSteps.hidden = !firmwareAssets;
  if (flashAssetsBtn) {
    flashAssetsBtn.hidden = !pendingFirmwareAssets;
    flashAssetsBtn.disabled = !serialSupported || busy || !pendingFirmwareAssets;
  }
  if (dumpBtn) dumpBtn.disabled = !serialSupported || busy;
  if (restoreBtn) restoreBtn.disabled = !serialSupported || busy || !calibData;
  if (logoUploadBtn) logoUploadBtn.disabled = !serialSupported || busy || !logoBitmap;
  if (logoDumpBtn) logoDumpBtn.disabled = !serialSupported || busy;
  if (flashDumpBtn) flashDumpBtn.disabled = !serialSupported || busy;
  if (flashRestoreBtn) flashRestoreBtn.disabled = !serialSupported || busy || !flashRestoreData;
  // Keep this entry point clickable when Web Serial is unavailable so the user
  // receives an explanation instead of a button that silently ignores clicks.
  factoryResetButtons.forEach(button => { button.disabled = busy; });
  if (rfLogExportBtn) rfLogExportBtn.disabled = !serialSupported || busy;
  if (slotNameInput) slotNameInput.disabled = busy || !slotImage;
  if (slotWriteBtn) slotWriteBtn.disabled = !serialSupported || busy || !slotImage || !slotNameValid;
  if (slotsRefreshBtn) slotsRefreshBtn.disabled = !serialSupported || busy;
  if (slotsTableBody) slotsTableBody.querySelectorAll('button').forEach(b => { b.disabled = !serialSupported || busy; });
  slotRefreshUpdateIndicators();
}

function beginToolsOperation(name, critical) {
  if (activeOperationToken) return null;
  const token = toolsSerial.beginOperation(name, { critical });
  if (!token) return null;
  activeOperationToken = token;
  activeOperationName = name;
  updateActionButtons();
  return token;
}

function endToolsOperation(token) {
  if (!token || token !== activeOperationToken) return;
  toolsSerial.endOperation(token);
  activeOperationToken = null;
  activeOperationName = null;
  updateActionButtons();
  runPendingToolsRefresh();
}

window.addEventListener('beforeunload', event => {
  const operation = toolsSerial.getSnapshot().operation;
  if (!operation?.critical) return;
  event.preventDefault();
  event.returnValue = '';
});

async function disconnect() {
  return toolsSerial.release('operation-complete');
}

function startReading() {
  if (!reader || isReading) return;
  isReading = true;
  readLoop().catch(e => {
    if (isReading) log(t('loopError', e?.message ?? String(e)), 'error');
  });
}

async function readLoop() {
  log(t('startReading'), 'info');
  let unexpectedlyClosed = false;
  try {
    while (isReading && reader) {
      const { value, done } = await reader.read();
      if (done) {
        log(t('streamClosed'), 'info');
        unexpectedlyClosed = isReading;
        break;
      }
      if (value?.length) {
        readBuffer.push(...value);
        trackScreenBytes(value);
        const isBulkFlashTransfer = activeOperationName === 'dump-flash' ||
          activeOperationName === 'restore-flash' ||
          activeOperationName === 'factory-reset';
        if (activeToolsView !== 'slots' && !isBulkFlashTransfer) {
          log(t('rxData', value.length, readBuffer.length), 'info');
        }
        notifySerialRead();
      }
    }
  } catch (e) {
    if (isReading) {
      unexpectedlyClosed = true;
      log(t('readError', e?.message ?? String(e)), 'error');
    }
  }
  log(t('readComplete'), 'info');
  if (unexpectedlyClosed) void handleToolsHardwareDisconnect();
}

// ========== RADIO SCREEN CAPTURE ==========
// The radio's screen over the tools connection, for the app submission panel
// (app-submit.js): no detour through the Live Viewer. Its keepalive ping
// makes the radio stream K5Viewer frames on the same port, [0xFn] AA 55 02
// <length BE> then 9-byte chunks [index, 8 row-major bytes], then 0A. The
// first frame after a ping pause holds all 128 chunks. Once a capture asked
// for it, every frame of the session is applied here too: a radio still
// streaming from an earlier ping sends only what changes, and those diffs
// keep this copy right.
const K5VIEWER_PING = Uint8Array.of(0x55, 0xAA, 0x00, 0x00);
const K5VIEWER_FULL_FRAME = 128 * 9;
let screenTrack = null;

function trackScreenBytes(value) {
  const track = screenTrack;
  if (!track || track.session !== toolsSerialSession) return;
  const bytes = track.bytes;
  bytes.push(...value);
  let i = 0;
  while (i + 5 <= bytes.length) {
    const size = (bytes[i + 3] << 8) | bytes[i + 4];
    if (bytes[i] !== 0xAA || bytes[i + 1] !== 0x55 || bytes[i + 2] !== 0x02 ||
        size % 9 !== 0 || size > K5VIEWER_FULL_FRAME) {
      i++;
      continue;
    }
    if (bytes.length < i + 6 + size) break;
    let valid = bytes[i + 5 + size] === 0x0A;
    for (let at = i + 5; valid && at < i + 5 + size; at += 9) valid = bytes[at] < 128;
    if (!valid) {
      i++;
      continue;
    }
    for (let at = i + 5; at < i + 5 + size; at += 9) {
      track.rows.set(bytes.slice(at + 1, at + 9), bytes[at] * 8);
      track.known[bytes[at]] = 1;
    }
    if (size === K5VIEWER_FULL_FRAME) track.full = true;
    i += 6 + size;
  }
  bytes.splice(0, i);
}

// Row-major bits (pixel x, y = bit (y * 128 + x)) to the catalog LCD layout:
// 8 pages of 128 column bytes, bit 0 on top.
function screenPagesFromRows(rows) {
  const pages = new Uint8Array(1024);
  for (let y = 0; y < 64; y++) {
    for (let x = 0; x < 128; x++) {
      const bit = y * 128 + x;
      if ((rows[bit >> 3] >> (bit & 7)) & 1) pages[(y >> 3) * 128 + x] |= 1 << (y & 7);
    }
  }
  return pages;
}

// { frame } or { error: 'offline' | 'busy' | 'timeout' }.
async function captureRadioScreen(timeoutMs = 3000) {
  if (!port || !writer || !toolsSerial.isOwner()) return { error: 'offline' };
  const token = beginToolsOperation('capture-screen', false);
  if (!token) return { error: 'busy' };
  const session = toolsSerialSession;
  if (!screenTrack || screenTrack.session !== session) {
    screenTrack = { session, rows: new Uint8Array(1024), known: new Uint8Array(128), bytes: [], full: false };
  }
  const track = screenTrack;
  track.full = false;
  const start = performance.now();
  try {
    for (;;) {
      if (session !== toolsSerialSession) return { error: 'offline' };
      await writer.write(K5VIEWER_PING);
      await sleep(200);
      // A radio that was not streaming answers with a full frame at once. One
      // still streaming sends nothing for an unchanged screen: the copy is
      // then current, provided it was complete.
      const elapsed = performance.now() - start;
      if (track.full || (elapsed >= 600 && track.known.every(Boolean))) {
        return { frame: screenPagesFromRows(track.rows) };
      }
      if (elapsed >= timeoutMs) return { error: 'timeout' };
    }
  } catch (error) {
    if (error?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) return { error: 'offline' };
    throw error;
  } finally {
    endToolsOperation(token);
  }
}

// ========== RUNTIME TOOLS AUTO-RECONNECT ==========
function toolsViewUsesRuntimeSerial(view = activeToolsView) {
  return view !== 'flash';
}

function stopToolsReconnect(options = {}) {
  toolsReconnect.stop({ forgetPortInfo: options.forgetPortInfo });
  toolsRefreshPending = false;
  if (options.forgetPortInfo) toolsLastPortInfo = null;
}

async function handleToolsHardwareDisconnect() {
  if (toolsHardwareDisconnectPromise) return toolsHardwareDisconnectPromise;
  if (!port || !toolsSerial.isOwner()) return;

  toolsHardwareDisconnectPromise = (async () => {
    if (!toolsViewUsesRuntimeSerial() || !toolsLastPortInfo) {
      await toolsSerial.release('hardware-disconnect');
      log(t('tools_disconnected'), 'info');
      return;
    }

    toolsRefreshPending = false;
    await disconnectPort({ reason: 'hardware-disconnect' });
    if (!toolsViewUsesRuntimeSerial() || !toolsSerial.isOwner()) return;

    toolsSerial.setState('reconnecting', { reason: 'hardware-disconnect' });
    log(t('serial_disconnected_auto'), 'info');
    toolsReconnect.start(toolsLastPortInfo);
  })();
  try {
    await toolsHardwareDisconnectPromise;
  } finally {
    toolsHardwareDisconnectPromise = null;
  }
}

async function reconnectToolsPort(candidate) {
  try {
    port = candidate;
    await port.open({ baudRate: BAUDRATE, bufferSize: 65536 });
    if (!toolsReconnect.isActive() || !toolsViewUsesRuntimeSerial() || !toolsSerial.isOwner()) {
      await disconnectPort({ reason: 'hardware-disconnect' });
      return false;
    }

    reader = port.readable.getReader();
    writer = port.writable.getWriter();
    toolsSerialSession++;
    startReading();

    let deviceInfoDetected = false;
    try {
      readBuffer = [];
      const deviceInfo = await requestDeviceInfo({ timeoutMs: 1500 });
      deviceInfoDetected = true;
      await detectNavigationCapabilities(deviceInfo);
    } catch (error) {
      if (!port || !toolsSerial.isOwner()) throw error;
      console.warn('Unable to refresh firmware capabilities after reconnect:', error);
    }
    if (!deviceInfoDetected) applyFirmwareNavigationPolicy('', true);

    toolsSerial.rememberPort(port);
    toolsSerial.setState('connected', { reason: 'auto-reconnect' });
    log(t('serial_reconnected'), 'success');
    toolsRefreshPending = activeToolsView === 'slots' || activeToolsView === 'apps';
    return true;
  } catch (error) {
    console.warn('Runtime tools auto-reconnect failed:', error);
    await disconnectPort({ reason: 'hardware-disconnect' });
    return false;
  } finally {
    updateActionButtons();
  }
}

function runPendingToolsRefresh() {
  if (!toolsRefreshPending || activeOperationToken || toolsReconnect.isActive() ||
      !port || !writer || !toolsSerial.isOwner()) return;
  const view = activeToolsView;
  toolsRefreshPending = false;
  if (view === 'slots') {
    void slotRefreshFlow();
  } else if (view === 'apps' && navigationCapabilities?.apps === true) {
    void appRefreshFlow();
  }
}

if (serialSupported) {
  navigator.serial.addEventListener('disconnect', event => {
    if (port && event.target === port) void handleToolsHardwareDisconnect();
  });
}

// ========== PROTOCOL HELPERS ==========
function notifySerialRead() {
  serialReadRevision++;
  const waiters = Array.from(serialReadWaiters);
  serialReadWaiters.clear();
  for (const wake of waiters) wake();
}

function waitForSerialRead(afterRevision, timeoutMs) {
  if (serialReadRevision !== afterRevision) return Promise.resolve(true);
  return new Promise(resolve => {
    let timer = null;
    const wake = () => {
      clearTimeout(timer);
      resolve(true);
    };
    serialReadWaiters.add(wake);
    timer = setTimeout(() => {
      serialReadWaiters.delete(wake);
      resolve(false);
    }, timeoutMs);
  });
}

function createMessage(msgType, dataLen) {
  const msg = new Uint8Array(4 + dataLen);
  const view = new DataView(msg.buffer);
  view.setUint16(0, msgType, true);
  view.setUint16(2, dataLen, true);
  return msg;
}

async function sendMessage(msg) {
  const packet = makePacket(msg);
  await writer.write(packet);
}

function makePacket(msg) {
  let msgLen = msg.length;
  if (msgLen % 2 !== 0) msgLen++;
  const buf = new Uint8Array(8 + msgLen);
  const view = new DataView(buf.buffer);

  view.setUint16(0, 0xCDAB, true);
  view.setUint16(2, msgLen, true);
  view.setUint16(6 + msgLen, 0xBADC, true);

  for (let i = 0; i < msg.length; i++) buf[4 + i] = msg[i];

  const crc = calcCRC(buf, 4, msgLen);
  view.setUint16(4 + msgLen, crc, true);

  obfuscate(buf, 4, 2 + msgLen);
  return buf;
}

function fetchMessage(buf) {
  if (buf.length < 8) return null;

  let packBegin = -1;
  for (let i = 0; i < buf.length - 1; i++) {
    if (buf[i] === 0xab && buf[i + 1] === 0xcd) {
      packBegin = i;
      break;
    }
  }
  if (packBegin === -1) {
    if (buf.length > 0 && buf[buf.length - 1] === 0xab) buf.splice(0, buf.length - 1);
    else buf.length = 0;
    return null;
  }
  if (buf.length - packBegin < 8) return null;

  const msgLen = (buf[packBegin + 3] << 8) | buf[packBegin + 2];
  const packEnd = packBegin + 6 + msgLen;
  if (buf.length < packEnd + 2) return null;

  if (buf[packEnd] !== 0xdc || buf[packEnd + 1] !== 0xba) {
    buf.splice(0, packBegin + 2);
    return null;
  }

  const msgBuf = new Uint8Array(msgLen + 2);
  for (let i = 0; i < msgLen + 2; i++) msgBuf[i] = buf[packBegin + 4 + i];
  obfuscate(msgBuf, 0, msgLen + 2);

  const view = new DataView(msgBuf.buffer);
  const msgType = view.getUint16(0, true);
  const data = msgBuf.slice(4);

  buf.splice(0, packEnd + 2);
  return { msgType, data, rawData: msgBuf };
}

function obfuscate(buf, off, size) {
  for (let i = 0; i < size; i++) buf[off + i] ^= OBFUS_TBL[i % OBFUS_TBL.length];
}

function calcCRC(buf, off, size) {
  let CRC = 0;
  for (let i = 0; i < size; i++) {
    const b = buf[off + i] & 0xff;
    CRC ^= b << 8;
    for (let j = 0; j < 8; j++) {
      if (CRC & 0x8000) CRC = ((CRC << 1) ^ 0x1021) & 0xffff;
      else CRC = (CRC << 1) & 0xffff;
    }
  }
  return CRC;
}

function arrayToHex(arr) {
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join(' ');
}

// ========== FLASH FIRMWARE (from original flash.js) ==========
flashBtn.addEventListener('click', async () => {
  if (!firmwareData) return;
  // Snapshot the buffer so a download finishing mid-flash cannot swap it out.
  const fw = firmwareData;
  const assets = firmwareAssets;
  const operation = beginToolsOperation('flash-firmware', true);
  if (!operation) return;
  try {
    if (!port) await connect({ reuse: false, remember: false });
    pendingFirmwareAssets = null;
    resetFlashSteps();
    if (assets) setFlashStep('image', 'active');
    // With assets, the steps carry the progress instead of the global gauge.
    await flashFirmware(fw, assets ? { onProgress: fraction => setFlashStepProgress('image', fraction) } : {});
    if (assets) {
      setFlashStep('image', 'done', 'flash_step_done');
      await installAssetsAfterFlash(assets);
    }
  } catch (e) {
    failActiveFlashStep();
    log(t('flashError', e?.message ?? String(e)), 'error');
  } finally {
    if (port) await disconnect();
    endToolsOperation(operation);
  }
});

async function flashFirmware(fw, options = {}) {
  hideChirpDriverOffer();
  // options.onProgress(fraction) replaces the global gauge: a firmware with
  // assets shows its progress in the flash steps, and is not done yet here.
  const report = options.onProgress || null;
  if (!report) {
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);
  }

  readBuffer = [];
  log(t('bufferEmpty'), 'info');
  await sleep(1000);
  log(t('bufferContains', readBuffer.length), 'info');

  log(t('establishing'), 'info');
  const devInfo = await waitForDeviceInfo();
  log(t('uidLabel', arrayToHex(devInfo.uid)), 'info');
  log(t('blVersionLabel', devInfo.blVersion), 'info');

  // Check bootloader version compatibility
  const minVersion = '7.00.07';
  if (!isBootloaderCompatible(devInfo.blVersion, minVersion)) {
    log('==============================================', 'error');
    log('❌ INCOMPATIBLE BOOTLOADER VERSION', 'error');
    log(`   Detected: ${devInfo.blVersion}`, 'error');
    log(`   Required: ${minVersion} or higher`, 'error');
    log('', 'error');
    log('This radio does not seem compatible with this firmware.', 'error');
    log('Please open an issue on GitHub:', 'error');
    log('https://github.com/armel/uv-k1-k5v3-firmware-custom', 'error');
    log('Please, include your bootloader version in the issue:', 'error');
    log(`   Bootloader: ${devInfo.blVersion}`, 'error');
    log('==============================================', 'error');
    throw new Error('Bootloader version too old');
  }
  log(t('deviceDetected'), 'success');

  log(t('handshake'), 'info');
  await performHandshake(devInfo.blVersion);
  log(t('handshakeComplete'), 'success');

  await programFirmware(fw, report || (fraction => updateProgress(fraction * 100)));

  if (report) report(1);
  else updateProgress(100);
  log(t(report ? 'fwAssetsImageDone' : 'programmingComplete'), 'success');

  // Global community counter: a firmware was successfully flashed.
  // Best-effort — never blocks or fails the flash.
  if (options.count !== false) {
    try { window.UVStudioFlashCounter?.increment(); } catch (e) {}
  }

  // Offer the matching CHIRP driver for download. Best-effort, never blocks.
  if (options.offerChirpDriver !== false) maybeOfferChirpDriver(firmwareFileName);

  if (!report) hideProgressSoon();
}

function hideProgressSoon() {
  setTimeout(() => {
    if (progressContainer) progressContainer.style.display = 'none';
    updateProgress(0);
  }, 800);
}

async function waitForDeviceInfo() {
  let lastTimestamp = 0, acc = 0, timeout = 0;
  log(t('waiting'), 'info');

  while (timeout < 500) {
    await sleep(10);
    timeout++;

    const msg = fetchMessage(readBuffer);
    if (!msg) continue;

    log(t('messageReceived', msg.msgType.toString(16).padStart(4, '0')), 'info');

    if (msg.msgType === MSG_NOTIFY_DEV_INFO) {
      const now = Date.now();
      const dt = now - lastTimestamp;
      log(t('interval', dt, acc), 'info');
      lastTimestamp = now;

      if (lastTimestamp > 0 && dt >= 5 && dt <= 1000) {
        acc++;
        log(t('validMessage', acc), 'success');
        if (acc >= 5) {
          const uid = msg.data.slice(0, 16);
          let blVersionEnd = -1;
          for (let i = 16; i < 32; i++) {
            if (msg.data[i] === 0) {
              blVersionEnd = i;
              break;
            }
          }
          if (blVersionEnd === -1) blVersionEnd = 32;
          const blVersion = new TextDecoder().decode(msg.data.slice(16, blVersionEnd));
          return { uid, blVersion };
        }
      } else {
        if (dt < 5 || dt > 1000) log(t('invalidInterval', dt), 'error');
        acc = 0;
      }
    }
  }
  throw new Error(t('timeoutNoDevice'));
}

async function performHandshake(blVersion) {
  let acc = 0;

  while (acc < 3) {
    await sleep(50);
    const msg = fetchMessage(readBuffer);
    if (msg && msg.msgType === MSG_NOTIFY_DEV_INFO) {
      if (acc === 0) log(t('sendingBlVersion'), 'info');

      const blMsg = createMessage(MSG_NOTIFY_BL_VER, 4);
      const blBytes = new TextEncoder().encode(blVersion.substring(0, 4));
      for (let i = 0; i < Math.min(blBytes.length, 4); i++) blMsg[4 + i] = blBytes[i];
      await sendMessage(blMsg);
      acc++;
      await sleep(50);
    }
  }

  log(t('waitingStop'), 'info');
  await sleep(200);

  while (readBuffer.length > 0) {
    const msg = fetchMessage(readBuffer);
    if (!msg) break;
    if (msg.msgType === MSG_NOTIFY_DEV_INFO) log(t('devInfoIgnored'), 'info');
    else log(t('messageReceived', msg.msgType.toString(16)), 'info');
  }
  log(t('bufferCleaned', readBuffer.length), 'info');
}

async function programFirmware(fw, report) {
  const pageCount = Math.ceil(fw.length / 256);
  const timestamp = Date.now() & 0xffffffff;
  log(t('programming', pageCount), 'info');

  let pageIndex = 0, retryCount = 0;
  const MAX_RETRIES = 3;

  while (pageIndex < pageCount) {
    report(pageIndex / pageCount);

    const msg = createMessage(MSG_PROG_FW, 268);
    const view = new DataView(msg.buffer);
    view.setUint32(4, timestamp, true);
    view.setUint16(8, pageIndex, true);
    view.setUint16(10, pageCount, true);

    const offset = pageIndex * 256;
    const len = Math.min(256, fw.length - offset);
    for (let i = 0; i < len; i++) msg[16 + i] = fw[offset + i];

    await sendMessage(msg);

    let gotResponse = false;
    for (let i = 0; i < 300 && !gotResponse; i++) {
      await sleep(10);
      const resp = fetchMessage(readBuffer);
      if (!resp) continue;
      if (resp.msgType === MSG_NOTIFY_DEV_INFO) continue;

      if (resp.msgType === MSG_PROG_FW_RESP) {
        const dv = new DataView(resp.data.buffer);
        const respPageIndex = dv.getUint16(4, true);
        const err = dv.getUint16(6, true);

        if (respPageIndex !== pageIndex) {
          log(t('pageWrongResponse', pageIndex + 1, pageCount, respPageIndex), 'error');
          continue;
        }
        if (err !== 0) {
          log(t('pageError', pageIndex + 1, pageCount, err), 'error');
          retryCount++;
          if (retryCount > MAX_RETRIES) throw new Error(t('tooManyErrors', pageIndex));
          break;
        }

        gotResponse = true;
        retryCount = 0;
        if ((pageIndex + 1) % 10 === 0 || pageIndex === pageCount - 1)
          log(t('pageOk', pageIndex + 1, pageCount), 'success');
      }
    }

    if (gotResponse) {
      pageIndex++;
    } else {
      log(t('pageTimeout', pageIndex + 1, pageCount), 'error');
      retryCount++;
      if (retryCount > MAX_RETRIES) throw new Error(t('tooManyTimeouts', pageIndex));
    }
  }
}

// ========== DUMP CALIBRATION ==========
dumpBtn.addEventListener('click', async () => {
  const operation = beginToolsOperation('dump-calibration', false);
  if (!operation) return;
  progressContainer.style.display = 'block';
  updateProgress(0);
  dumpDownload.style.display = 'none';

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    log(t('dumpingData'), 'info');

    const dumpedData = new Uint8Array(CALIB_SIZE);
    let offset = CALIB_OFFSET;

    for (let i = 0; i < CALIB_SIZE; i += CHUNK_SIZE) {
      const pct = Math.round((i / CALIB_SIZE) * 100);
      updateProgress(pct);

      const msg = createMessage(MSG_READ_EEPROM, 8);
      const view = new DataView(msg.buffer);
      view.setUint16(4, offset, true);
      view.setUint16(6, CHUNK_SIZE, true);
      view.setUint32(8, devInfo.timestamp, true);
      await sendMessage(msg);

      let gotResponse = false;
      for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
        await sleep(10);
        const resp = fetchMessage(readBuffer);
        if (!resp) continue;

        if (resp.msgType === MSG_READ_EEPROM_RESP) {
          const dv = new DataView(resp.data.buffer);
          const respOffset = dv.getUint16(0, true);
          const respSize = resp.data[2];

          if (respOffset === offset && respSize === CHUNK_SIZE) {
            for (let j = 0; j < CHUNK_SIZE; j++) {
              dumpedData[i + j] = resp.data[4 + j];
            }
            gotResponse = true;
            offset += CHUNK_SIZE;
          }
        }
      }

      if (!gotResponse) {
        throw new Error(t('eepromError', offset.toString(16)));
      }
    }

    updateProgress(100);
    log(t('dumpComplete'), 'success');

    const blob = new Blob([dumpedData], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    dumpLink.href = url;
    dumpLink.download = 'calibration.dat';
    dumpDownload.style.display = 'flex';
    log(t('dumpSaved'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    endToolsOperation(operation);
  }
});

function flashAddress(address) {
  return address.toString(16).padStart(6, '0');
}

async function waitForExternalFlashResponse(responseType, address, timeoutMs, session) {
  let revision = serialReadRevision;
  const deadline = performance.now() + timeoutMs;

  for (;;) {
    if (session !== toolsSerialSession) {
      throw Object.assign(new Error(t('tools_disconnected')), {
        code: 'UVSTUDIO_SERIAL_SESSION_CHANGED'
      });
    }

    for (;;) {
      const buffered = readBuffer.length;
      const resp = fetchMessage(readBuffer);
      if (resp && resp.msgType === responseType && resp.data.length >= 4) {
        const dv = new DataView(resp.data.buffer, resp.data.byteOffset, resp.data.byteLength);
        if (dv.getUint32(0, true) === address) return resp;
      }
      if (resp === null && readBuffer.length === buffered) break;
    }

    const remaining = deadline - performance.now();
    if (remaining <= 0) return null;
    const received = await waitForSerialRead(revision, remaining);
    revision = serialReadRevision;
    if (!received) return null;
  }
}

async function exchangeExternalFlashMessage(
  msg, responseType, address, timeoutMs, retries = FLASH_COMMAND_RETRIES
) {
  const session = toolsSerialSession;
  for (let attempt = 0; attempt <= retries; attempt++) {
    if (session !== toolsSerialSession) {
      throw Object.assign(new Error(t('tools_disconnected')), {
        code: 'UVSTUDIO_SERIAL_SESSION_CHANGED'
      });
    }

    readBuffer = [];
    await sendMessage(msg);
    const resp = await waitForExternalFlashResponse(responseType, address, timeoutMs, session);
    if (resp) return resp;
  }
  return null;
}

async function readExternalFlashChunk(
  address, length, timestamp, timeoutMs = FLASH_COMMAND_TIMEOUT_MS,
  retries = FLASH_COMMAND_RETRIES
) {
  const msg = createMessage(MSG_READ_FLASH, 10);
  const view = new DataView(msg.buffer);
  view.setUint32(4, address, true);
  view.setUint16(8, length, true);
  view.setUint32(10, timestamp, true);

  const resp = await exchangeExternalFlashMessage(
    msg, MSG_READ_FLASH_RESP, address, timeoutMs, retries
  );
  if (!resp || resp.data.length < 7) {
    throw new Error(t('flashReadError', flashAddress(address)));
  }
  const dv = new DataView(resp.data.buffer, resp.data.byteOffset, resp.data.byteLength);
  const respSize = dv.getUint16(4, true);
  if (resp.data[6] !== 0 || respSize !== length || resp.data.length < 7 + length) {
    throw new Error(t('flashReadError', flashAddress(address)));
  }
  return resp.data.slice(7, 7 + length);
}

async function eraseExternalFlashSector(address, timestamp) {
  const msg = createMessage(MSG_ERASE_FLASH, 8);
  const view = new DataView(msg.buffer);
  view.setUint32(4, address, true);
  view.setUint32(8, timestamp, true);

  const resp = await exchangeExternalFlashMessage(
    msg, MSG_ERASE_FLASH_RESP, address, FLASH_ERASE_TIMEOUT_MS
  );
  if (!resp || resp.data.length < 5 || resp.data[4] !== 0) {
    throw new Error(t('flashRestoreError', flashAddress(address)));
  }
}

async function writeExternalFlashChunk(address, data, timestamp) {
  const msg = createMessage(MSG_WRITE_FLASH, 10 + data.length);
  const view = new DataView(msg.buffer);
  view.setUint32(4, address, true);
  view.setUint16(8, data.length, true);
  view.setUint32(10, timestamp, true);
  msg.set(data, 14);

  const resp = await exchangeExternalFlashMessage(
    msg, MSG_WRITE_FLASH_RESP, address, FLASH_COMMAND_TIMEOUT_MS
  );
  if (!resp || resp.data.length < 7) {
    throw new Error(t('flashRestoreError', flashAddress(address)));
  }
  const dv = new DataView(resp.data.buffer, resp.data.byteOffset, resp.data.byteLength);
  if (resp.data[6] !== 0 || dv.getUint16(4, true) !== data.length) {
    throw new Error(t('flashRestoreError', flashAddress(address)));
  }
}

async function readExternalFlashCrc32(
  address, length, timestamp, timeoutMs = FLASH_COMMAND_TIMEOUT_MS,
  retries = FLASH_COMMAND_RETRIES
) {
  const msg = createMessage(MSG_CRC_FLASH, 12);
  const view = new DataView(msg.buffer);
  view.setUint32(4, address, true);
  view.setUint32(8, length, true);
  view.setUint32(12, timestamp, true);

  const resp = await exchangeExternalFlashMessage(
    msg, MSG_CRC_FLASH_RESP, address, timeoutMs, retries
  );
  if (!resp || resp.data.length < 13) {
    throw new Error(t('flashReadError', flashAddress(address)));
  }
  const dv = new DataView(resp.data.buffer, resp.data.byteOffset, resp.data.byteLength);
  if (resp.data[12] !== 0 || dv.getUint32(4, true) !== length) {
    throw new Error(t('flashReadError', flashAddress(address)));
  }
  return dv.getUint32(8, true);
}

async function detectExternalFlashCrcSupport(timestamp) {
  try {
    await readExternalFlashCrc32(0, 1, timestamp, FLASH_CRC_PROBE_TIMEOUT_MS, 0);
    return true;
  } catch (_) {
    return false;
  }
}

async function externalFlashSectorMatches(data, sector, sectorEnd, timestamp) {
  const expectedCrc = crc32Bytes(data.subarray(sector, sectorEnd));
  const actualCrc = await readExternalFlashCrc32(
    sector, sectorEnd - sector, timestamp
  );
  return actualCrc === expectedCrc;
}

async function verifyExternalFlashSector(data, sector, sectorEnd, timestamp, crcSupported) {
  if (crcSupported &&
      await externalFlashSectorMatches(data, sector, sectorEnd, timestamp)) return;

  // Fall back to a byte comparison for older Labs firmware, or to locate the
  // exact failing address when a sector CRC does not match.
  for (let address = sector; address < sectorEnd; address += FLASH_DUMP_CHUNK) {
    const expected = data.subarray(address, Math.min(address + FLASH_DUMP_CHUNK, sectorEnd));
    const actual = await readExternalFlashChunk(address, expected.length, timestamp);
    for (let i = 0; i < expected.length; i++) {
      if (actual[i] !== expected[i]) {
        throw new Error(t('flashVerifyError', flashAddress(address + i)));
      }
    }
  }
}

// Safety gate for External Flash and Factory reset: a firmware without
// external-flash access never answers 0x0738. The navigation already explains
// the incompatibility inline; this guard only prevents an unsupported command.
async function hasExternalFlashSupport(timestamp) {
  try {
    await readExternalFlashChunk(0, 1, timestamp);
    return true;
  } catch (e) {
    if (e?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e;
    log(t('flashUnsupported'), 'error');
    return false;
  }
}

async function sha256Hex(data) {
  if (!window.crypto?.subtle) throw new Error(t('factoryResetCryptoError'));
  const digest = await window.crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

let factoryAssetsFallbackPromise = null;

function loadFactoryAssetsFallback() {
  if (window.UVStudioFactoryAssets) return Promise.resolve(window.UVStudioFactoryAssets);
  if (factoryAssetsFallbackPromise) return factoryAssetsFallbackPromise;

  factoryAssetsFallbackPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'assets/factory/factory-assets.js';
    script.onload = () => {
      if (window.UVStudioFactoryAssets) resolve(window.UVStudioFactoryAssets);
      else reject(new Error(t('factoryResetAssetInvalid')));
    };
    script.onerror = () => reject(new Error(t('factoryResetAssetInvalid')));
    document.head.appendChild(script);
  });
  return factoryAssetsFallbackPromise;
}

function decodeFactoryAsset(encoded) {
  const binary = window.atob(encoded);
  const data = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) data[i] = binary.charCodeAt(i);
  return data;
}

async function fetchVerifiedBinary(url, expectedSize, expectedHash) {
  let data;
  if (window.location.protocol === 'file:') {
    const assets = await loadFactoryAssetsFallback();
    const encoded = assets[url];
    if (!encoded) throw new Error(t('factoryResetAssetInvalid'));
    data = decodeFactoryAsset(encoded);
  } else {
    const response = await fetch(url, { cache: 'no-cache' });
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}`.trim());
    data = new Uint8Array(await response.arrayBuffer());
  }
  if (data.length !== expectedSize || await sha256Hex(data) !== expectedHash) {
    throw new Error(t('factoryResetAssetInvalid'));
  }
  return data;
}

async function restoreFactoryExternalFlash(data, timestamp, crcSupported) {
  const regularSectors = [];
  for (let address = 0; address < FLASH_TOTAL_SIZE; address += FLASH_SECTOR_SIZE) {
    if (address === FLASH_CALIBRATION_SECTOR ||
        address === FACTORY_STATE_A || address === FACTORY_STATE_B) continue;
    regularSectors.push(address);
  }
  // These first two sectors also contain the Labs multiboot marker. Write them
  // last so the running firmware remains bootable for as long as possible.
  const sectors = regularSectors.concat([FACTORY_STATE_A, FACTORY_STATE_B]);

  log(t('flashCalibrationPreserved'), 'info');

  for (let sectorIndex = 0; sectorIndex < sectors.length; sectorIndex++) {
    const sector = sectors[sectorIndex];
    updateProgress(Math.round((sectorIndex / sectors.length) * 100));
    const sectorEnd = sector + FLASH_SECTOR_SIZE;
    if (crcSupported &&
        await externalFlashSectorMatches(data, sector, sectorEnd, timestamp)) continue;

    await eraseExternalFlashSector(sector, timestamp);
    for (let address = sector; address < sectorEnd; address += FLASH_WRITE_CHUNK) {
      const chunk = data.subarray(address, address + FLASH_WRITE_CHUNK);
      if (chunk.every(value => value === 0xff)) continue;
      await writeExternalFlashChunk(address, chunk, timestamp);
    }

    await verifyExternalFlashSector(data, sector, sectorEnd, timestamp, crcSupported);
  }
  updateProgress(100);
}

let flashRestoreConfirmResolve = null;
let flashRestoreConfirmFocusOrigin = null;

function closeFlashRestoreConfirmModal(confirmed) {
  if (!flashRestoreConfirmModal?.classList.contains('show')) return;
  const resolve = flashRestoreConfirmResolve;
  const focusTarget = flashRestoreConfirmFocusOrigin;
  flashRestoreConfirmResolve = null;
  flashRestoreConfirmFocusOrigin = null;
  flashRestoreConfirmModal.classList.remove('show');
  flashRestoreConfirmModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (focusTarget && document.contains(focusTarget)) {
    focusTarget.focus({ preventScroll: true });
  }
  if (resolve) resolve(Boolean(confirmed));
}

function confirmExternalFlashRestore() {
  if (!flashRestoreConfirmModal || flashRestoreConfirmResolve) return Promise.resolve(false);
  flashRestoreConfirmFocusOrigin = document.activeElement;
  if (flashRestoreConfirmBody) flashRestoreConfirmBody.textContent = t('flashRestoreConfirm');
  flashRestoreConfirmModal.classList.add('show');
  flashRestoreConfirmModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => flashRestoreCancelBtn?.focus());
  return new Promise(resolve => { flashRestoreConfirmResolve = resolve; });
}

if (flashRestoreConfirmClose) {
  flashRestoreConfirmClose.addEventListener('click', () => closeFlashRestoreConfirmModal(false));
}
if (flashRestoreCancelBtn) {
  flashRestoreCancelBtn.addEventListener('click', () => closeFlashRestoreConfirmModal(false));
}
if (flashRestoreConfirmBtn) {
  flashRestoreConfirmBtn.addEventListener('click', () => closeFlashRestoreConfirmModal(true));
}
if (flashRestoreConfirmModal) {
  flashRestoreConfirmModal.addEventListener('click', event => {
    if (event.target === flashRestoreConfirmModal) closeFlashRestoreConfirmModal(false);
  });
  flashRestoreConfirmModal.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeFlashRestoreConfirmModal(false);
  });
}

let factoryResetModalResolve = null;
let factoryResetModalFocusOrigin = null;
let factoryResetModalStep = 'confirm';
let factoryResetTarget = null;

function renderFactoryResetModal() {
  const dfuStep = factoryResetModalStep === 'dfu';
  const unsupportedStep = factoryResetModalStep === 'unsupported';
  const model = factoryResetTarget?.label ?? '';
  if (factoryResetTitle) factoryResetTitle.textContent = t(dfuStep ? 'factoryResetDfuTitle' : 'factoryResetTitle', model);
  if (factoryResetBody) {
    factoryResetBody.textContent = unsupportedStep
      ? t('factoryResetUnsupported')
      : t(dfuStep ? 'factoryResetDfuBody' : 'factoryResetConfirm', model);
  }
  if (factoryResetConfirmBtn) {
    factoryResetConfirmBtn.textContent = t(dfuStep ? 'factoryResetDfuContinue' : unsupportedStep ? 'appClose' : 'factoryResetStart');
    factoryResetConfirmBtn.classList.toggle('danger', !unsupportedStep);
  }
  if (factoryResetCancelBtn) factoryResetCancelBtn.hidden = dfuStep || unsupportedStep;
  if (factoryResetClose) factoryResetClose.hidden = dfuStep;
}

function closeFactoryResetModal(confirmed) {
  if (!factoryResetModal?.classList.contains('show')) return;
  if (factoryResetModalStep === 'dfu' && !confirmed) return;
  const resolve = factoryResetModalResolve;
  const focusTarget = factoryResetModalFocusOrigin;
  factoryResetModalResolve = null;
  factoryResetModalFocusOrigin = null;
  factoryResetModal.classList.remove('show');
  factoryResetModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (focusTarget && document.contains(focusTarget)) focusTarget.focus({ preventScroll: true });
  if (resolve) resolve(Boolean(confirmed));
}

function showFactoryResetModal(step, target = factoryResetTarget) {
  if (!factoryResetModal || factoryResetModalResolve) return Promise.resolve(false);
  factoryResetModalStep = step;
  factoryResetTarget = target;
  factoryResetModalFocusOrigin = document.activeElement;
  renderFactoryResetModal();
  factoryResetModal.classList.add('show');
  factoryResetModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => (step === 'dfu' ? factoryResetConfirmBtn : factoryResetCancelBtn)?.focus());
  return new Promise(resolve => { factoryResetModalResolve = resolve; });
}

factoryResetClose?.addEventListener('click', () => closeFactoryResetModal(false));
factoryResetCancelBtn?.addEventListener('click', () => closeFactoryResetModal(false));
factoryResetConfirmBtn?.addEventListener('click', () => closeFactoryResetModal(true));
factoryResetModal?.addEventListener('click', event => {
  if (event.target === factoryResetModal) closeFactoryResetModal(false);
});
factoryResetModal?.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeFactoryResetModal(false);
});

// ========== GUIDED FACTORY SOFTWARE RESTORE ==========
async function runFactoryReset(targetKey) {
  if (factoryResetModalResolve || activeOperationToken) return;
  const target = FACTORY_TARGETS[targetKey];
  if (!target) return;
  factoryResetTarget = target;
  if (!serialSupported) {
    await showFactoryResetModal('unsupported', target);
    return;
  }
  const operation = beginToolsOperation('factory-reset', true);
  if (!operation) return;

  try {
    // Check the Labs-only external-flash service before asking to confirm a
    // destructive restore that could not run anyway.
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);
    const devInfo = await requestDeviceInfo();
    if (!(await hasExternalFlashSupport(devInfo.timestamp))) return;
    if (!(await showFactoryResetModal('confirm', target))) return;

    progressContainer.style.display = 'block';
    updateProgress(0);
    log(t('factoryResetDownloading', target.label), 'info');
    const [factoryFlash, stockFirmware] = await Promise.all([
      fetchVerifiedBinary(target.flashUrl, FACTORY_FLASH_SIZE, target.flashSha256),
      fetchVerifiedBinary(target.firmwareUrl, target.firmwareSize, target.firmwareSha256)
    ]);
    log(t('factoryResetAssetsReady'), 'success');

    const crcSupported = await detectExternalFlashCrcSupport(devInfo.timestamp);
    log(t('factoryResetRestoringExternal', target.label), 'info');
    await restoreFactoryExternalFlash(factoryFlash, devInfo.timestamp, crcSupported);
    log(t('factoryResetExternalComplete', target.label), 'success');

    if (port) await disconnect();
    if (!(await showFactoryResetModal('dfu'))) return;

    updateProgress(0);
    log(t('factoryResetWaitingDfu', target.label), 'info');
    await connect({ reuse: false, remember: false });
    await flashFirmware(stockFirmware, { count: false, offerChirpDriver: false });
    log(t('factoryResetComplete', target.label), 'success');
  } catch (e) {
    log(t('factoryResetError', e?.message ?? String(e)), 'error');
  } finally {
    if (port) await disconnect();
    endToolsOperation(operation);
  }
}

factoryResetButtons.forEach(button => {
  button.addEventListener('click', () => void runFactoryReset(button.dataset.factoryResetTarget));
});

// ========== DUMP FULL EXTERNAL FLASH (2 MiB) ==========
if (flashDumpBtn) flashDumpBtn.addEventListener('click', async () => {
  const operation = beginToolsOperation('dump-flash', false);
  if (!operation) return;
  if (flashDumpDownload) flashDumpDownload.style.display = 'none';

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    if (!(await hasExternalFlashSupport(devInfo.timestamp))) return;
    progressContainer.style.display = 'block';
    updateProgress(0);
    log(t('dumpingFlash'), 'info');

    const dumpedData = new Uint8Array(FLASH_TOTAL_SIZE);

    for (let addr = 0; addr < FLASH_TOTAL_SIZE; addr += FLASH_DUMP_CHUNK) {
      const len = Math.min(FLASH_DUMP_CHUNK, FLASH_TOTAL_SIZE - addr);
      updateProgress(Math.round((addr / FLASH_TOTAL_SIZE) * 100));

      dumpedData.set(await readExternalFlashChunk(addr, len, devInfo.timestamp), addr);
    }

    updateProgress(100);
    log(t('flashDumpComplete'), 'success');

    const blob = new Blob([dumpedData], { type: 'application/octet-stream' });
    if (flashDumpDownloadUrl) URL.revokeObjectURL(flashDumpDownloadUrl);
    flashDumpDownloadUrl = URL.createObjectURL(blob);
    flashDumpLink.href = flashDumpDownloadUrl;
    flashDumpLink.download = 'external-flash.bin';
    if (flashDumpDownload) flashDumpDownload.style.display = 'flex';
    log(t('flashDumpSaved'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    endToolsOperation(operation);
  }
});

// ========== RESTORE EXTERNAL FLASH ==========
if (flashRestoreBtn) flashRestoreBtn.addEventListener('click', async () => {
  if (!flashRestoreData) return;

  const operation = beginToolsOperation('restore-flash', true);
  if (!operation) return;

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    if (!(await hasExternalFlashSupport(devInfo.timestamp))) return;
    // Destructive: rewriting the external flash replaces the logo, settings,
    // firmware slots and multiboot state. Device-specific calibration is skipped.
    // Asked only once the firmware is known to support the restore.
    if (!(await confirmExternalFlashRestore())) return;

    progressContainer.style.display = 'block';
    updateProgress(0);
    const crcSupported = await detectExternalFlashCrcSupport(devInfo.timestamp);
    log(t('restoringFlash'), 'info');

    const data = flashRestoreData;
    const total = data.length;

    for (let sector = 0; sector < total; sector += FLASH_SECTOR_SIZE) {
      updateProgress(Math.round((sector / total) * 100));

      if (sector === FLASH_CALIBRATION_SECTOR) {
        log(t('flashCalibrationPreserved'), 'info');
        continue;
      }

      const sectorEnd = Math.min(sector + FLASH_SECTOR_SIZE, total);
      if (crcSupported &&
          await externalFlashSectorMatches(data, sector, sectorEnd, devInfo.timestamp)) continue;

      await eraseExternalFlashSector(sector, devInfo.timestamp);
      // 0x073C write: program the now-erased sector in chunks.
      for (let addr = sector; addr < sectorEnd; addr += FLASH_WRITE_CHUNK) {
        const chunk = data.subarray(addr, Math.min(addr + FLASH_WRITE_CHUNK, sectorEnd));
        // Erase already produces 0xFF. Avoid needless page-program cycles for
        // empty areas while still verifying the complete sector below.
        if (chunk.every(value => value === 0xff)) continue;
        await writeExternalFlashChunk(addr, chunk, devInfo.timestamp);
      }

      // A command acknowledgement only proves that the transaction completed.
      // Verify each complete sector before moving on.
      await verifyExternalFlashSector(
        data, sector, sectorEnd, devInfo.timestamp, crcSupported
      );
    }

    updateProgress(100);
    log(t('flashRestoreComplete'), 'success');

    log(t('rebooting'), 'info');
    const rebootMsg = createMessage(MSG_REBOOT, 0);
    await sendMessage(rebootMsg);
    await sleep(500);
    log(t('rebootComplete'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    endToolsOperation(operation);
  }
});

// ========== RESTORE CALIBRATION ==========
restoreBtn.addEventListener('click', async () => {
  if (!calibData) return;
  const operation = beginToolsOperation('restore-calibration', true);
  if (!operation) return;
  progressContainer.style.display = 'block';
  updateProgress(0);

  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(1000);

    const devInfo = await requestDeviceInfo();
    log(t('restoringData'), 'info');

    let offset = CALIB_OFFSET;

    for (let i = 0; i < CALIB_SIZE; i += CHUNK_SIZE) {
      const pct = Math.round((i / CALIB_SIZE) * 100);
      updateProgress(pct);

      const msg = createMessage(MSG_WRITE_EEPROM, 24);
      const view = new DataView(msg.buffer);
      view.setUint16(4, offset, true);
      view.setUint16(6, CHUNK_SIZE, true);
      msg[7] = 1;
      view.setUint32(8, devInfo.timestamp, true);
      
      for (let j = 0; j < CHUNK_SIZE; j++) {
        msg[12 + j] = calibData[i + j];
      }
      
      await sendMessage(msg);

      let gotResponse = false;
      for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
        await sleep(10);
        const resp = fetchMessage(readBuffer);
        if (!resp) continue;

        if (resp.msgType === MSG_WRITE_EEPROM_RESP) {
          const dv = new DataView(resp.data.buffer);
          const respOffset = dv.getUint16(0, true);

          if (respOffset === offset) {
            gotResponse = true;
            offset += CHUNK_SIZE;
          }
        }
      }

      if (!gotResponse) {
        throw new Error(t('eepromError', offset.toString(16)));
      }
    }

    updateProgress(100);
    log(t('restoreComplete'), 'success');

    log(t('rebooting'), 'info');
    const rebootMsg = createMessage(MSG_REBOOT, 0);
    await sendMessage(rebootMsg);
    await sleep(500);
    log(t('rebootComplete'), 'success');

    setTimeout(() => {
      if (progressContainer) progressContainer.style.display = 'none';
      updateProgress(0);
    }, 800);
  } catch (e) {
    log(t('error', e?.message ?? String(e)), 'error');
  } finally {
    endToolsOperation(operation);
  }
});

// ========== REQUEST DEVICE INFO (for dump/restore) ==========
async function requestDeviceInfo(options = {}) {
  if (!options.quiet) log(t('establishing'), 'info');
  
  const ts = Date.now() & 0xffffffff;
  const msg = createMessage(MSG_DEV_INFO_REQ, 4);
  new DataView(msg.buffer).setUint32(4, ts, true);
  await sendMessage(msg);
  
  const attempts = Math.max(1, Math.ceil((options.timeoutMs || 5000) / 10));
  for (let timeout = 0; timeout < attempts; timeout++) {
    await sleep(10);
    const resp = fetchMessage(readBuffer);
    if (!resp) continue;
    
    if (!options.quiet) log(t('messageReceived', resp.msgType.toString(16).padStart(4, '0')), 'info');
    
    if (resp.msgType === MSG_DEV_INFO_RESP) {
      // Log raw device info data (and keep the firmware string to name it later)
      const name = logDeviceInfo(resp.data);
      applyFirmwareNavigationPolicy(name);
      log(t('deviceDetected'), 'success');
      return { timestamp: ts, name };
    }
  }
  throw new Error(t('timeoutNoDevice'));
}

// Helper to display device info response
function logDeviceInfo(data) {
  // Extract ASCII string from device info
  let deviceInfoStr = '';
  for (let i = 0; i < data.length; i++) {
    const c = data[i];
    if (c === 0x00 || c === 0xFF) break; // Stop at null or padding
    if (c >= 32 && c < 127) {
      deviceInfoStr += String.fromCharCode(c);
    }
  }
  
  if (deviceInfoStr) {
    log(`Device: ${deviceInfoStr}`, 'success');
    
    // The canonical version is everything numeric after "v": v50 and
    // dotted forms such as v5.0.0 are both valid.
    const versionMatch = deviceInfoStr.match(/v(\d+(?:\.\d+)*)/i);
    if (versionMatch) {
      const version = versionMatch[1];
      const [major, minor, patch] = version.split('.').map(Number);
      
      // Set CALIB_OFFSET based on version
      if (major >= 5) {
        CALIB_OFFSET = 0xB000;
        log(`Firmware v${version} detected: CALIB_OFFSET = 0xB000`, 'info');
      } else {
        CALIB_OFFSET = 0x1E00;
        log(`Firmware v${version} detected: CALIB_OFFSET = 0x1E00`, 'info');
      }
    }
  } else {
    // Fallback to hex dump if no ASCII found
    let hexStr = 'Device Info (hex): ';
    for (let i = 0; i < Math.min(data.length, 40); i++) {
      hexStr += data[i].toString(16).padStart(2, '0').toUpperCase() + ' ';
    }
    log(hexStr, 'info');
  }
  return deviceInfoStr;   // parsed firmware string ('' if none), used to name the radio
}

// ========== LOGO: IMAGE -> BITMAP CONVERSION ==========
// Render the source image into a 128x64 canvas using "fit" (preserve ratio,
// white letterboxing). Then apply threshold + optional invert and pack into
// the ST7565-native column-major LSB-top layout (1024 bytes).
function imageToLogoBitmap(image, threshold, invert) {
  // Step 1: render image fitted in a 128x64 white canvas
  const canvas = document.createElement('canvas');
  canvas.width = LOGO_WIDTH;
  canvas.height = LOGO_HEIGHT;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, LOGO_WIDTH, LOGO_HEIGHT);

  const srcRatio = image.naturalWidth / image.naturalHeight;
  const dstRatio = LOGO_WIDTH / LOGO_HEIGHT;
  let drawW, drawH, drawX, drawY;
  if (srcRatio > dstRatio) {
    // Source wider than 2:1 -> fit to width
    drawW = LOGO_WIDTH;
    drawH = Math.round(LOGO_WIDTH / srcRatio);
    drawX = 0;
    drawY = Math.round((LOGO_HEIGHT - drawH) / 2);
  } else {
    // Source taller than 2:1 -> fit to height
    drawH = LOGO_HEIGHT;
    drawW = Math.round(LOGO_HEIGHT * srcRatio);
    drawX = Math.round((LOGO_WIDTH - drawW) / 2);
    drawY = 0;
  }
  ctx.drawImage(image, drawX, drawY, drawW, drawH);

  // Step 2: read pixels and pack into ST7565 native layout
  const imgData = ctx.getImageData(0, 0, LOGO_WIDTH, LOGO_HEIGHT).data;
  const bitmap = new Uint8Array(LOGO_BITMAP_SIZE);

  for (let page = 0; page < 8; page++) {
    for (let x = 0; x < LOGO_WIDTH; x++) {
      let byte = 0;
      for (let bit = 0; bit < 8; bit++) {
        const y = page * 8 + bit;
        const idx = (y * LOGO_WIDTH + x) * 4;
        // Convert RGBA to luminance (Rec. 601)
        const lum = 0.299 * imgData[idx] + 0.587 * imgData[idx + 1] + 0.114 * imgData[idx + 2];
        // Pixel is "on" (LCD pixel lit, dark on screen) if luminance < threshold
        let on = lum < threshold;
        if (invert) on = !on;
        if (on) byte |= (1 << bit);
      }
      bitmap[page * LOGO_WIDTH + x] = byte;
    }
  }

  return bitmap;
}

// Render a 1024-byte ST7565-native bitmap onto a 128x64 canvas (each "on" bit
// becomes a black pixel, "off" stays white).
function bitmapToCanvas(bitmap, canvas) {
  const ctx = canvas.getContext('2d');
  const imgData = ctx.createImageData(LOGO_WIDTH, LOGO_HEIGHT);
  for (let page = 0; page < 8; page++) {
    for (let x = 0; x < LOGO_WIDTH; x++) {
      const byte = bitmap[page * LOGO_WIDTH + x];
      for (let bit = 0; bit < 8; bit++) {
        const y = page * 8 + bit;
        const on = (byte >> bit) & 1;
        const idx = (y * LOGO_WIDTH + x) * 4;
        const v = on ? 0 : 255;
        imgData.data[idx] = v;
        imgData.data[idx + 1] = v;
        imgData.data[idx + 2] = v;
        imgData.data[idx + 3] = 255;
      }
    }
  }
  ctx.putImageData(imgData, 0, 0);
}

// Refresh preview canvas from current source image + slider/checkbox state.
function refreshLogoPreview() {
  if (!logoSourceImage) return;
  const threshold = parseInt(logoThresholdInput.value, 10);
  const invert = logoInvertInput.checked;
  logoBitmap = imageToLogoBitmap(logoSourceImage, threshold, invert);
  if (logoPreviewCanvas) bitmapToCanvas(logoBitmap, logoPreviewCanvas);
  updateLogoUploadButton();
}

function updateLogoUploadButton() {
  updateActionButtons();
}

// ========== LOGO: FILE INPUT + LIVE PREVIEW ==========
if (logoFileInput) {
  logoFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        logoSourceImage = img;
        if (logoFileName) {
          logoFileName.textContent = file.name;
          logoFileName.classList.add('has-file');
        }
        if (logoFileLabel) logoFileLabel.classList.add('has-file');
        if (logoControls) logoControls.hidden = false;
        log(t('logoLoaded', file.name), 'success');
        refreshLogoPreview();
      };
      img.onerror = () => log(t('logoDecodeError'), 'error');
      img.src = ev.target.result;
    };
    fr.readAsDataURL(file);
  });
}

if (logoThresholdInput) {
  logoThresholdInput.addEventListener('input', () => {
    if (logoThresholdValue) logoThresholdValue.textContent = logoThresholdInput.value;
    refreshLogoPreview();
  });
}

if (logoInvertInput) {
  logoInvertInput.addEventListener('change', refreshLogoPreview);
}

// ========== LOGO: UPLOAD ==========
if (logoUploadBtn) {
  logoUploadBtn.addEventListener('click', async () => {
    if (!logoBitmap) return;
    const operation = beginToolsOperation('upload-logo', true);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);

    try {
      if (!port) await connect();
      readBuffer = [];
      await sleep(1000);

      const devInfo = await requestDeviceInfo();
      log(t('logoUploading'), 'info');

      // Build full payload: 8-byte magic + 1024-byte bitmap, padded to 16-byte chunks.
      const payload = new Uint8Array(LOGO_PADDED_SIZE);
      payload.fill(0xFF);
      payload.set(LOGO_MAGIC, 0);
      payload.set(logoBitmap, LOGO_HEADER_SIZE);

      let offset = LOGO_EEPROM_OFFSET;
      for (let i = 0; i < LOGO_PADDED_SIZE; i += CHUNK_SIZE) {
        const pct = Math.round((i / LOGO_PADDED_SIZE) * 100);
        updateProgress(pct);

        const msg = createMessage(MSG_WRITE_EEPROM, 24);
        const view = new DataView(msg.buffer);
        view.setUint16(4, offset, true);
        view.setUint16(6, CHUNK_SIZE, true);
        msg[7] = 1;
        view.setUint32(8, devInfo.timestamp, true);

        for (let j = 0; j < CHUNK_SIZE; j++) {
          msg[12 + j] = payload[i + j];
        }

        await sendMessage(msg);

        let gotResponse = false;
        for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
          await sleep(10);
          const resp = fetchMessage(readBuffer);
          if (!resp) continue;
          if (resp.msgType === MSG_WRITE_EEPROM_RESP) {
            const dv = new DataView(resp.data.buffer);
            const respOffset = dv.getUint16(0, true);
            if (respOffset === offset) {
              gotResponse = true;
              offset += CHUNK_SIZE;
            }
          }
        }

        if (!gotResponse) {
          throw new Error(t('eepromError', offset.toString(16)));
        }
      }

      updateProgress(100);
      log(t('logoUploadComplete'), 'success');

      log(t('rebooting'), 'info');
      const rebootMsg = createMessage(MSG_REBOOT, 0);
      await sendMessage(rebootMsg);
      await sleep(500);
      log(t('rebootComplete'), 'success');

      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      endToolsOperation(operation);
    }
  });
}

// ========== LOGO: DUMP ==========
if (logoDumpBtn) {
  logoDumpBtn.addEventListener('click', async () => {
    const operation = beginToolsOperation('dump-logo', false);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);
    if (logoDumpDownload) logoDumpDownload.style.display = 'none';
    if (logoDumpResult) logoDumpResult.hidden = true;

    try {
      if (!port) await connect();
      readBuffer = [];
      await sleep(1000);

      const devInfo = await requestDeviceInfo();
      log(t('logoDumping'), 'info');

      const dumped = new Uint8Array(LOGO_PADDED_SIZE);
      let offset = LOGO_EEPROM_OFFSET;

      for (let i = 0; i < LOGO_PADDED_SIZE; i += CHUNK_SIZE) {
        const pct = Math.round((i / LOGO_PADDED_SIZE) * 100);
        updateProgress(pct);

        const msg = createMessage(MSG_READ_EEPROM, 8);
        const view = new DataView(msg.buffer);
        view.setUint16(4, offset, true);
        view.setUint16(6, CHUNK_SIZE, true);
        view.setUint32(8, devInfo.timestamp, true);
        await sendMessage(msg);

        let gotResponse = false;
        for (let attempt = 0; attempt < 300 && !gotResponse; attempt++) {
          await sleep(10);
          const resp = fetchMessage(readBuffer);
          if (!resp) continue;
          if (resp.msgType === MSG_READ_EEPROM_RESP) {
            const dv = new DataView(resp.data.buffer);
            const respOffset = dv.getUint16(0, true);
            const respSize = resp.data[2];
            if (respOffset === offset && respSize === CHUNK_SIZE) {
              for (let j = 0; j < CHUNK_SIZE; j++) {
                dumped[i + j] = resp.data[4 + j];
              }
              gotResponse = true;
              offset += CHUNK_SIZE;
            }
          }
        }

        if (!gotResponse) {
          throw new Error(t('eepromError', offset.toString(16)));
        }
      }

      updateProgress(100);

      // Verify magic header (informational only, do not abort if missing).
      let magicOk = true;
      for (let i = 0; i < LOGO_HEADER_SIZE; i++) {
        if (dumped[i] !== LOGO_MAGIC[i]) { magicOk = false; break; }
      }
      log(magicOk ? t('logoMagicOk') : t('logoMagicMissing'), magicOk ? 'success' : 'info');

      // Extract bitmap and render
      const bitmap = dumped.slice(LOGO_HEADER_SIZE, LOGO_HEADER_SIZE + LOGO_BITMAP_SIZE);
      if (logoDumpedCanvas) {
        bitmapToCanvas(bitmap, logoDumpedCanvas);
        logoDumpedCanvas.toBlob((blob) => {
          if (!blob) return;
          const url = URL.createObjectURL(blob);
          if (logoDumpLink) {
            logoDumpLink.href = url;
            logoDumpLink.download = 'logo.png';
          }
          if (logoDumpDownload) logoDumpDownload.style.display = 'flex';
        }, 'image/png');
      }
      if (logoDumpResult) logoDumpResult.hidden = false;
      log(t('logoDumpComplete'), 'success');

      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      endToolsOperation(operation);
    }
  });
}

// ========== EXPORT RF LOG ==========
async function collectRfLogRows() {
  const rf = window.UVTOOLS_RF_LOG;
  if (!rf) throw new Error(t('rfLogProtocolUnavailable'));

  const rows = new Map();
  let firstMainAt = 0;
  let lastHistoryAt = 0;
  let gotHistory = false;
  let lastKeepaliveAt = 0;
  const startedAt = Date.now();
  const deadline = Date.now() + RF_LOG_EXPORT_TIMEOUT_MS;

  await writer.write(rf.featureKeepalive(true));
  lastKeepaliveAt = Date.now();

  while (Date.now() < deadline) {
    const now = Date.now();
    if (now - lastKeepaliveAt >= RF_LOG_KEEPALIVE_INTERVAL_MS) {
      await writer.write(rf.featureKeepalive(!firstMainAt));
      lastKeepaliveAt = Date.now();
    }

    let frame = rf.takeViewerFrame(readBuffer);
    while (frame) {
      if (frame.type === rf.TYPE_RF_LOG) {
        let packet;
        try {
          packet = rf.parseMainPacket(frame.payload);
        } catch (error) {
          if (error.code === 'RF_LOG_VERSION') throw new Error(t('rfLogVersionUnsupported'));
          throw error;
        }

        if (packet.disabled) throw new Error(t('rfLogDisabled'));
        if (packet.full) {
          if (!firstMainAt) firstMainAt = Date.now();
          if (!packet.hasTraffic) return [];
          rf.mergeRows(rows, packet.rows);
          const trafficCount = Array.from(rows.values())
            .filter(row => (row.flags & rf.FLAG_SESSION) === 0).length;
          updateProgress(Math.min(99, (trafficCount / rf.VISIBLE_TRAFFIC_COUNT) * 100));
          if (packet.rows.length < rf.ROW_COUNT) {
            return rf.limitVisibleRows(rows.values());
          }
        }
      } else if (frame.type === rf.TYPE_RF_LOG_HISTORY) {
        const page = rf.parseHistoryPacket(frame.payload);
        gotHistory = true;
        lastHistoryAt = Date.now();
        rf.mergeRows(rows, page);

        const trafficCount = Array.from(rows.values())
          .filter(row => (row.flags & rf.FLAG_SESSION) === 0).length;
        updateProgress(Math.min(99, (trafficCount / rf.VISIBLE_TRAFFIC_COUNT) * 100));
        log(t('rfLogProgress', trafficCount), 'info');

        if (page.length < rf.ROW_COUNT || trafficCount >= rf.VISIBLE_TRAFFIC_COUNT) {
          return rf.limitVisibleRows(rows.values());
        }
      }

      frame = rf.takeViewerFrame(readBuffer);
    }

    const quietSince = gotHistory ? lastHistoryAt : firstMainAt;
    if (quietSince && Date.now() - quietSince >= RF_LOG_HISTORY_IDLE_MS) {
      return rf.limitVisibleRows(rows.values());
    }
    if (!firstMainAt && Date.now() - startedAt >= RF_LOG_INITIAL_TIMEOUT_MS) {
      throw new Error(t('rfLogTimeout'));
    }
    await sleep(25);
  }

  throw new Error(t('rfLogTimeout'));
}

if (rfLogExportBtn) {
  rfLogExportBtn.addEventListener('click', async () => {
    const operation = beginToolsOperation('export-rf-log', false);
    if (!operation) return;
    if (progressContainer) progressContainer.style.display = 'block';
    updateProgress(0);
    if (rfLogDownload) rfLogDownload.style.display = 'none';
    let completed = false;

    try {
      if (!port) await connect();
      readBuffer = [];
      log(t('rfLogReading'), 'info');

      const rows = await collectRfLogRows();
      const trafficCount = rows.filter(row =>
        (row.flags & window.UVTOOLS_RF_LOG.FLAG_SESSION) === 0).length;
      if (trafficCount === 0) throw new Error(t('rfLogEmpty'));

      const csv = window.UVTOOLS_RF_LOG.rowsToCsv(rows);
      if (rfLogDownloadUrl) URL.revokeObjectURL(rfLogDownloadUrl);
      rfLogDownloadUrl = URL.createObjectURL(
        new Blob([csv], { type: 'text/csv;charset=utf-8' })
      );
      if (rfLogLink) {
        rfLogLink.href = rfLogDownloadUrl;
        rfLogLink.download = 'rf-log.csv';
      }
      if (rfLogDownload) rfLogDownload.style.display = 'block';

      updateProgress(100);
      log(t('rfLogComplete', trafficCount), 'success');
      completed = true;
      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }, 800);
    } catch (e) {
      log(t('error', e?.message ?? String(e)), 'error');
    } finally {
      if (!completed) {
        if (progressContainer) progressContainer.style.display = 'none';
        updateProgress(0);
      }
      endToolsOperation(operation);
    }
  });
}

// ========== UI HELPERS ==========
function log(message, type = '') {
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  if (logDiv) {
    logDiv.appendChild(entry);
    logDiv.scrollTop = logDiv.scrollHeight;
  } else {
    console.log(message);
  }
}

function updateProgress(percent) {
  const rounded = Math.round(percent);
  const label = `${rounded}%`;
  const changed = progressFill
    ? progressFill.style.width !== label
    : Boolean(progressLabel && progressLabel.textContent !== label);
  if (progressFill) progressFill.style.width = label;
  if (progressLabel) progressLabel.textContent = label;
  const bar = document.querySelector('.progress-bar');
  if (bar) bar.setAttribute('aria-valuenow', String(rounded));
  return changed;
}

function waitForProgressPaint() {
  if (document.visibilityState !== 'visible') return Promise.resolve();
  return new Promise(resolve => requestAnimationFrame(() => resolve()));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ========== FIRMWARE SLOTS (multiboot) ==========
const SLOT_COUNT = 4;             // user slots shown in UV Studio (1..4)
const SLOT_FIRST = 1;             // firmware index of the first user slot; slot 0 is the
                                  // firmware-managed base backup (hidden here, write-protected)
const SLOT_END = SLOT_FIRST + SLOT_COUNT;  // exclusive upper bound (5)
const SLOT_IMG_OFFSET = 0x1000;   // image starts after the header sector
const SLOT_IMG_MAX = 0x1D800;     // 118 KiB application region
// Wire command = 8 (frame) + 4 (msg hdr) + 12 (prefix) + chunk. The firmware VCP
// RX ring is only 256 B (VCP_RX_BUF_SIZE) with no overflow guard, so keep the whole
// command well under that: 128 -> 152 B command, ~104 B of headroom.
const SLOT_WRITE_CHUNK = 128;
const SLOT_HDR_SIZE = 64;
const SLOT_MAGIC = 0x31424D46;    // "FMB1"
const SLOT_HDR_VERSION = 1;
const SLOT_FLAG_COMMITTED = 1;
const slotStatuses = [null, null, null, null, null]; // last known MB_ERR_* per firmware slot (index 0 = base backup, unused here)

const MSG_SLOT_INFO = 0x0720, MSG_SLOT_INFO_RESP = 0x0721;
const MSG_SLOT_ERASE = 0x0722, MSG_SLOT_ERASE_RESP = 0x0723;
const MSG_SLOT_WRITE = 0x0724, MSG_SLOT_WRITE_RESP = 0x0725;
const MSG_SLOT_VALIDATE = 0x0726, MSG_SLOT_VALIDATE_RESP = 0x0727;
const MSG_PROFILE_ERASE = 0x0728, MSG_PROFILE_ERASE_RESP = 0x0729;

// Firmware MB_ERR_* codes (0..8) -> i18n status keys.
const SLOT_STATUS_KEY = ['slotStateValid', 'slotStateEmpty', 'slotStateNewHdr',
  'slotStateIncomplete', 'slotStateBadSize', 'slotStateCrc', 'slotStateSpi',
  'slotStateBadSlot', 'slotStateAuth', 'slotStateError', 'slotStateError',
  'slotStateMismatch'];
function slotStatusText(code) { return t(SLOT_STATUS_KEY[code] || 'slotStateError'); }

// CRC-32 (zlib/PNG, poly 0xEDB88320) — must match the firmware mb_crc32_update.
function crc32Bytes(bytes) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) {
    crc ^= bytes[i];
    for (let k = 0; k < 8; k++) crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

// Derive the edition from the canonical f4hwn.<preset>.bin filename. Model and
// version suffixes remain supported, without maintaining a preset allowlist.
function slotEditionFromFilename(filename) {
  if (!filename) return '';
  const match = filename.match(
    /^f4hwn[._-](?:(?:k1|k5v3)[._-])?([a-z][a-z0-9-]*)(?:[._-].*)?\.bin$/i
  );
  if (!match) return '';
  // FieldOps is the only current edition with an internal capital letter.
  return match[1]
    .split('-')
    .filter(Boolean)
    .map(token => token.toLowerCase() === 'fieldops'
      ? 'FieldOps'
      : token.charAt(0).toUpperCase() + token.slice(1).toLowerCase())
    .join(' ')
    .slice(0, 15);
}

function slotVersionFromFilename(filename) {
  if (!filename) return '';
  const match = filename.match(/[._-]v(\d+(?:\.\d+)*)\.bin$/i);
  return match ? `v${match[1]}`.slice(0, 15) : '';
}

// Pull canonical metadata from the filename, with an embedded-version fallback
// for older filenames which do not carry a final .v<version> component.
function slotExtractMeta(bytes, filename) {
  let text = '';
  for (let i = 0; i < bytes.length; i++) {
    const c = bytes[i];
    text += (c >= 32 && c < 127) ? String.fromCharCode(c) : '\n';
  }
  let fwVersion = slotVersionFromFilename(filename);
  // Match an author token (without '+') followed by a canonical numeric
  // version, but store only the normalized v... component.
  const vm = text.match(/[A-Za-z0-9]+ (v\d+(?:\.\d+)*)/i);
  if (!fwVersion && vm) fwVersion = vm[1];
  const name = slotEditionFromFilename(filename);
  return { name, fwVersion: fwVersion.slice(0, 15) };
}

// The radio's multiboot font/header are ASCII-only and reserve one byte for
// NUL. Transliterate common accented names and keep at most 15 visible bytes.
function slotNormalizeName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 15);
}

function slotBuildHeader(imageSize, crc, meta) {
  const h = new Uint8Array(SLOT_HDR_SIZE);
  const dv = new DataView(h.buffer);
  dv.setUint32(0, SLOT_MAGIC, true);
  dv.setUint16(4, SLOT_HDR_VERSION, true);
  dv.setUint16(6, SLOT_FLAG_COMMITTED, true);
  dv.setUint32(8, imageSize, true);
  dv.setUint32(12, crc, true);
  const putStr = (off, len, s) => { for (let i = 0; i < len; i++) h[off + i] = i < s.length ? (s.charCodeAt(i) & 0x7f) : 0; };
  putStr(16, 16, meta.name || '');
  putStr(32, 16, meta.fwVersion || '');
  return h;
}

function slotParseHeader(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const readStr = (off, len) => { let s = ''; for (let i = 0; i < len; i++) { const c = b[off + i]; if (!c) break; s += String.fromCharCode(c); } return s; };
  return {
    magic: dv.getUint32(0, true),
    imageSize: dv.getUint32(8, true),
    imageCrc32: dv.getUint32(12, true),
    name: readStr(16, 16),
    fwVersion: readStr(32, 16)
  };
}

// Send one slot command and wait for its matching response; returns data bytes.
async function slotCommand(msgType, dataBytes, respType, timeoutMs) {
  const session = toolsSerialSession;
  readBuffer = [];
  const msg = createMessage(msgType, dataBytes.length);
  msg.set(dataBytes, 4);
  await sendMessage(msg);

  let revision = serialReadRevision;
  const deadline = performance.now() + timeoutMs;
  for (;;) {
    if (session !== toolsSerialSession) {
      throw Object.assign(new Error(t('tools_disconnected')), { code: 'UVSTUDIO_SERIAL_SESSION_CHANGED' });
    }
    for (;;) {
      const buffered = readBuffer.length;
      const resp = fetchMessage(readBuffer);
      if (resp && resp.msgType === respType) return resp.data;
      if (resp === null && readBuffer.length === buffered) break;
    }

    const remaining = deadline - performance.now();
    if (remaining <= 0) break;
    const received = await waitForSerialRead(revision, remaining);
    revision = serialReadRevision;
    if (!received) break;
  }
  throw new Error(t('slotsTimeout'));
}

async function slotInfo(slot) {
  const data = await slotCommand(MSG_SLOT_INFO, Uint8Array.of(slot), MSG_SLOT_INFO_RESP, 3000);
  return { slot, status: data[1], hdr: slotParseHeader(data.subarray(2, 2 + SLOT_HDR_SIZE)) };
}

async function slotErase(slot, ts) {
  const d = new Uint8Array(6);
  d[0] = slot;
  new DataView(d.buffer).setUint32(2, ts, true);
  const data = await slotCommand(MSG_SLOT_ERASE, d, MSG_SLOT_ERASE_RESP, 30000);
  return data[1];
}

async function slotProfileErase(slot, ts) {
  const d = new Uint8Array(6);
  d[0] = slot;
  new DataView(d.buffer).setUint32(2, ts, true);
  const data = await slotCommand(MSG_PROFILE_ERASE, d, MSG_PROFILE_ERASE_RESP, 30000);
  return data[1];
}

async function slotWriteChunk(slot, offset, ts, chunk) {
  const d = new Uint8Array(12 + chunk.length);
  const dv = new DataView(d.buffer);
  d[0] = slot;
  dv.setUint32(2, offset, true);
  dv.setUint16(6, chunk.length, true);
  dv.setUint32(8, ts, true);
  d.set(chunk, 12);
  const data = await slotCommand(MSG_SLOT_WRITE, d, MSG_SLOT_WRITE_RESP, 1500);
  return data[1];
}

// Programming the same bytes onto already-erased (or matching) NOR flash is
// idempotent, so a lost/garbled reply can be recovered by re-sending the chunk.
async function slotWriteChunkRetry(slot, offset, ts, chunk) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await slotWriteChunk(slot, offset, ts, chunk);
    } catch (e) {
      if (attempt >= 4) throw e;
      log(t('slotRetry', offset), 'info');
      await sleep(60);
    }
  }
}

async function slotValidate(slot) {
  const data = await slotCommand(MSG_SLOT_VALIDATE, Uint8Array.of(slot), MSG_SLOT_VALIDATE_RESP, 20000);
  const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  return { crc: dv.getUint32(0, true) >>> 0, status: data[5] };
}

// ---------- Firmware assets (fonts, menu texts) ----------
// v7 firmwares keep their read-only data in a 16 KiB asset zone per firmware
// slot (0x075x commands, same wire layout as the 0x072x slot family). The
// release package carries the pack after the image (firmware-package.js).
const MSG_ASSET_INFO = 0x0750, MSG_ASSET_INFO_RESP = 0x0751;
const MSG_ASSET_ERASE = 0x0752, MSG_ASSET_ERASE_RESP = 0x0753;
const MSG_ASSET_WRITE = 0x0754, MSG_ASSET_WRITE_RESP = 0x0755;
const MSG_ASSET_VALIDATE = 0x0756, MSG_ASSET_VALIDATE_RESP = 0x0757;
const ASSET_RUNNING_SLOT = 0xFF;          // the firmware resolves it to its own slot
const ASSET_BOOT_TIMEOUT_MS = 30000;      // first boot also backs up the new firmware

async function assetInfo(slot, timeoutMs = 3000) {
  const data = await slotCommand(MSG_ASSET_INFO, Uint8Array.of(slot), MSG_ASSET_INFO_RESP, timeoutMs);
  const fwPackage = window.UVStudioFirmwarePackage;
  return {
    slot: data[0],
    status: data[1],
    runningSlot: data[2],
    loaded: data[3] === 1,
    runningBuildId: fwPackage.toHex(data.subarray(36, 36 + fwPackage.BUILD_ID_SIZE))
  };
}

async function assetErase(slot, ts) {
  const d = new Uint8Array(6);
  d[0] = slot;
  new DataView(d.buffer).setUint32(2, ts, true);
  const data = await slotCommand(MSG_ASSET_ERASE, d, MSG_ASSET_ERASE_RESP, 30000);
  return data[1];
}

async function assetWriteChunk(slot, offset, ts, chunk) {
  const d = new Uint8Array(12 + chunk.length);
  const dv = new DataView(d.buffer);
  d[0] = slot;
  dv.setUint32(2, offset, true);
  dv.setUint16(6, chunk.length, true);
  dv.setUint32(8, ts, true);
  d.set(chunk, 12);
  const data = await slotCommand(MSG_ASSET_WRITE, d, MSG_ASSET_WRITE_RESP, 1500);
  return data[1];
}

// Same idempotent retry as slot chunks: NOR programming of identical bytes.
async function assetWriteChunkRetry(slot, offset, ts, chunk) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await assetWriteChunk(slot, offset, ts, chunk);
    } catch (e) {
      if (attempt >= 4) throw e;
      log(t('slotRetry', offset), 'info');
      await sleep(60);
    }
  }
}

async function assetValidate(slot) {
  const data = await slotCommand(MSG_ASSET_VALIDATE, Uint8Array.of(slot), MSG_ASSET_VALIDATE_RESP, 5000);
  return data[1];
}

// Write an asset pack into the zone of `slot` (ASSET_RUNNING_SLOT = the running
// firmware). The payload goes first and the header last, so an interrupted
// upload never validates. The running firmware only accepts its own build.
async function writeFirmwareAssets(slot, pack, ts, onProgress = null) {
  const fwPackage = window.UVStudioFirmwarePackage;
  const info = await assetInfo(slot);
  if (info.slot === info.runningSlot &&
      info.runningBuildId !== fwPackage.parseAssetPack(pack).buildId) {
    throw new Error(t('fwAssetsWrongFirmware'));
  }

  log(t('fwAssetsWriting'), 'info');
  let st = await assetErase(info.slot, ts);
  if (st !== 0) throw new Error('erase: ' + slotStatusText(st));
  const header = fwPackage.PACK_HEADER_SIZE;
  for (let off = header; off < pack.length; off += SLOT_WRITE_CHUNK) {
    const chunk = pack.subarray(off, Math.min(off + SLOT_WRITE_CHUNK, pack.length));
    st = await assetWriteChunkRetry(info.slot, off, ts, chunk);
    if (st !== 0) throw new Error('write @' + off + ': ' + slotStatusText(st));
    if (onProgress && onProgress((off + chunk.length) / pack.length)) await waitForProgressPaint();
  }
  st = await assetWriteChunkRetry(info.slot, 0, ts, pack.subarray(0, header));
  if (st !== 0) throw new Error('header: ' + slotStatusText(st));
  st = await assetValidate(info.slot);
  if (st !== 0) throw new Error('verify: ' + slotStatusText(st));
  log(t('fwAssetsWriteOk'), 'success');
}

// After a bootloader flash, wait for the radio to run the new firmware and
// write its assets on its serial port, without any click: the same port when
// it survives the reboot (programming cable), else the port that appears once
// the radio restarts (USB-C: the firmware enumerates its own CDC device, which
// the page reaches through the ports already granted to it). The firmware
// keeps the screen blank until then. On timeout the "Install firmware assets"
// button finishes the job.
const FW_VCP_INFO = Object.freeze({ usbVendorId: 0x36B7, usbProductId: 0xFFFF }); // App/usb/usbd_cdc_if.c
const ASSET_RADIO_TIMEOUT_MS = 120000;

async function openRadioPortForAssets(flashPortInfo) {
  const matches = window.UVStudioSerial.portMatchesInfo;
  let ports;
  try {
    ports = await navigator.serial.getPorts();
  } catch (e) {
    return false;
  }
  const candidates = ports.filter(candidate => !candidate.readable &&
    (matches(candidate, FW_VCP_INFO) || matches(candidate, flashPortInfo)));
  for (const candidate of candidates) {
    try {
      if (!toolsSerial.isOwner()) await toolsSerial.acquire({ source: 'tools' });
      if (!toolsSerial.isOwner()) return false;
      await candidate.open({ baudRate: BAUDRATE, bufferSize: 65536 });
      port = candidate;
      reader = port.readable.getReader();
      writer = port.writable.getWriter();
      toolsSerialSession++;
      startReading();
      toolsSerial.setState('connected', { reason: 'firmware-assets' });
      return true;
    } catch (e) {
      if (port === candidate) await disconnectPort({ reason: 'connection-error' });
      else try { await candidate.close(); } catch (closeError) {}
    }
  }
  return false;
}

async function installAssetsAfterFlash(pack) {
  const flashPortInfo = port?.getInfo?.() || null;
  setFlashStepWaiting('restart');
  log(t('fwAssetsWaitRadio'), 'info');
  const deadline = performance.now() + ASSET_RADIO_TIMEOUT_MS;
  while (performance.now() < deadline) {
    if (!port || !writer) await openRadioPortForAssets(flashPortInfo);
    let dev = null;
    if (port && writer) {
      try {
        readBuffer = [];
        dev = await requestDeviceInfo({ timeoutMs: 1000, quiet: true });
      } catch (e) {
        dev = null;
      }
    }
    if (dev) {
      setFlashStep('restart', 'done', 'flash_step_detected');
      setFlashStep('assets', 'active');
      try {
        await writeFirmwareAssets(ASSET_RUNNING_SLOT, pack, dev.timestamp,
          fraction => setFlashStepProgress('assets', fraction));
        setFlashStep('assets', 'done', 'flash_step_done');
        setFlashStepsComplete(true);
        log(t('programmingComplete'), 'success');
      } catch (e) {
        setFlashStep('assets', 'error', 'flash_step_failed');
        log(t('fwAssetsError', e?.message ?? String(e)), 'error');
        pendingFirmwareAssets = pack;
        log(t('fwAssetsReconnect'), 'info');
      }
      return;
    }
    await sleep(500);
  }
  setFlashStep('restart', 'error', 'flash_step_failed');
  pendingFirmwareAssets = pack;
  log(t('fwAssetsReconnect'), 'info');
}

// Assets of a firmware written into a multiboot slot. A running firmware
// without the 0x075x commands, or the slot being the running one (its build
// differs from the new image), leaves them for "Install firmware assets"
// once the slot has been restored.
async function slotWriteAssets(slot, pack, ts) {
  let info;
  try {
    info = await assetInfo(slot, 1500);
  } catch (e) {
    log(t('fwAssetsSlotUnsupported', slot), 'error');
    pendingFirmwareAssets = pack;
    return;
  }
  if (info.runningSlot === slot) {
    log(t('fwAssetsSlotRunning', slot), 'info');
    pendingFirmwareAssets = pack;
    return;
  }
  await writeFirmwareAssets(slot, pack, ts);
}

function slotRenderRow(slot, info) {
  slotStatuses[slot] = info ? info.status : null;
  if (!slotsTableBody) return;
  const row = slotsTableBody.querySelector(`tr[data-slot="${slot}"]`);
  if (!row) return;
  const valid = info && info.status === 0;
  const committed = info && (info.status === 0 || info.status === 5); // header present (CRC may be bad)
  const hdr = info && info.hdr;
  row.querySelector('.slot-name').textContent = committed ? (hdr.name || '—') : '—';
  row.querySelector('.slot-version').textContent = committed ? (tableActionVersionLabel(hdr.fwVersion) || '—') : '—';
  row.querySelector('.slot-size').textContent = committed ? `${Math.round(hdr.imageSize / 1024)} KB` : '—';
  if (valid) {
    row.dataset.slotEdition = hdr.name || '';
    row.dataset.slotVersion = hdr.fwVersion || '';
  } else {
    delete row.dataset.slotEdition;
    delete row.dataset.slotVersion;
  }
  const stateCell = row.querySelector('.slot-state');
  stateCell.textContent = info ? slotStatusText(info.status) : '—';
  stateCell.className = 'slot-state ' + (valid ? 'ok' : (info && info.status === 1 ? 'empty' : 'bad'));
  row.querySelectorAll('.slot-act-erase, .slot-act-reset').forEach(button => {
    button.hidden = !committed;
  });
  slotRenderUpdateIndicator(row);
}

function slotCatalogKey(name) {
  return String(name || '').replace(/[^a-z0-9]/gi, '').toLowerCase();
}

const tableActionIcons = {
  update: '<svg class="table-action-update-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v6h-6"/></svg>',
  reset: '<svg class="table-action-reset-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m7 21-4.3-4.3a2.4 2.4 0 0 1 0-3.4L13 3a2.4 2.4 0 0 1 3.4 0L21 7.6a2.4 2.4 0 0 1 0 3.4L11 21"/><path d="m5 11 9 9"/><path d="M7 21h15"/></svg>',
  delete: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 11v5M14 11v5"/></svg>'
};

function tableActionVersionLabel(version) {
  const value = String(version || '').trim();
  if (!value) return '';
  return value.replace(/^v(?=\d)/i, '');
}

function setTableActionIcon(button, icon, label, visibleDetail = '') {
  if (!button) return;
  button.innerHTML = tableActionIcons[icon] || '';
  button.classList.toggle('has-detail', Boolean(visibleDetail));
  if (visibleDetail) {
    const detail = document.createElement('span');
    detail.className = 'table-action-detail';
    detail.textContent = visibleDetail;
    button.appendChild(detail);
  }
  button.title = label;
  button.setAttribute('aria-label', label);
}

function slotRenderUpdateIndicator(row) {
  const button = row.querySelector('.slot-update-button');
  if (!button) return;
  const latest = slotLatestVersions.get(slotCatalogKey(row.dataset.slotEdition));
  const comparison = latest ? appCompareVersions(row.dataset.slotVersion, latest.version) : null;
  const outdated = comparison !== null && comparison < 0;
  button.hidden = !outdated;
  button.disabled = !outdated || !serialSupported || slotUpdateDownloadPending || Boolean(activeOperationToken);
  if (outdated) {
    const targetVersion = tableActionVersionLabel(latest.version);
    const detail = t('appUpdateAction', targetVersion);
    setTableActionIcon(button, 'update', detail, targetVersion);
  } else {
    setTableActionIcon(button, 'update', t('appUpdateShort'));
  }
}

function slotRefreshUpdateIndicators() {
  if (!slotsTableBody) return;
  slotsTableBody.querySelectorAll('tr[data-slot]').forEach(slotRenderUpdateIndicator);
}

function slotBuildTable() {
  if (!slotsTableBody) return;
  slotsTableBody.innerHTML = '';
  for (let s = SLOT_FIRST; s < SLOT_END; s++) {
    const tr = document.createElement('tr');
    tr.dataset.slot = String(s);
    tr.innerHTML =
      `<td class="slot-idx">${s}</td>` +
      `<td class="slot-name">—</td>` +
      `<td class="slot-version">—</td>` +
      `<td class="slot-size">—</td>` +
      `<td><span class="slot-state">—</span></td>` +
      `<td class="slot-actions"><div class="slot-actions-group"></div></td>`;
    const eraseBtn = document.createElement('button');
    eraseBtn.type = 'button';
    eraseBtn.className = 'btn table-icon-action is-danger slot-act-erase';
    setTableActionIcon(eraseBtn, 'delete', t('slotEraseFw'));
    eraseBtn.hidden = true;
    eraseBtn.addEventListener('click', () => { void slotEraseFlow(s); });
    const resetBtn = document.createElement('button');
    resetBtn.type = 'button';
    resetBtn.className = 'btn table-icon-action is-neutral slot-act-reset';
    setTableActionIcon(resetBtn, 'reset', t('slotResetConfig'));
    resetBtn.hidden = true;
    resetBtn.addEventListener('click', () => { void slotResetConfigFlow(s); });
    const updateBtn = document.createElement('button');
    updateBtn.type = 'button';
    updateBtn.className = 'btn table-icon-action is-primary slot-update-button';
    setTableActionIcon(updateBtn, 'update', t('appUpdateShort'));
    updateBtn.hidden = true;
    updateBtn.disabled = true;
    updateBtn.addEventListener('click', () => { void slotUpdateFlow(s); });
    const actions = tr.querySelector('.slot-actions-group');
    actions.appendChild(updateBtn);
    actions.appendChild(eraseBtn);
    actions.appendChild(resetBtn);
    slotsTableBody.appendChild(tr);
  }
}

// Re-localize the static slot labels after a language change.
function slotLocalize() {
  if (slotsTableBody) {
    slotsTableBody.querySelectorAll('.slot-act-erase').forEach(b => setTableActionIcon(b, 'delete', t('slotEraseFw')));
    slotsTableBody.querySelectorAll('.slot-act-reset').forEach(b => setTableActionIcon(b, 'reset', t('slotResetConfig')));
  }
  if (slotImage && slotMetaEl) {
    slotMetaEl.textContent = t('slotDetected', slotMeta.name || '?', slotMeta.fwVersion || '?', Math.round(slotImage.length / 1024));
  }
  slotRefreshUpdateIndicators();
}

async function finishSlotOperation(op) {
  endToolsOperation(op);
}

// Smart default target: first empty slot (no FMB1 header), else the first user slot.
function slotPickDefaultTarget() {
  if (!slotTargetSelect) return;
  let target = SLOT_FIRST;
  for (let s = SLOT_FIRST; s < SLOT_END; s++) {
    if (slotStatuses[s] === 1) { target = s; break; }
  }
  slotTargetSelect.value = String(target);
}

async function slotRefreshFlow() {
  const op = beginToolsOperation('slots-refresh', false);
  if (!op) return;
  try {
    if (!port) await connect();
    log(t('slotsScanning'), 'info');
    for (let s = SLOT_FIRST; s < SLOT_END; s++) {
      try { slotRenderRow(s, await slotInfo(s)); }
      catch (e) {
        if (e?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e;
        slotRenderRow(s, { slot: s, status: 6, hdr: null });
      }
    }
    slotPickDefaultTarget();
    log(t('slotsScanDone'), 'success');
  } catch (e) {
    log(t('slotsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishSlotOperation(op);
  }
}

async function slotEraseFlow(slot) {
  const op = beginToolsOperation('slots-erase', true);
  if (!op) return;
  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(500);
    const dev = await requestDeviceInfo();
    log(t('slotErasing', slot), 'info');
    const st = await slotErase(slot, dev.timestamp);
    if (st !== 0) throw new Error(slotStatusText(st));
    log(t('slotErased', slot), 'success');
    slotRenderRow(slot, await slotInfo(slot));
  } catch (e) {
    log(t('slotsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishSlotOperation(op);
  }
}

// Reset a slot's config profile (channels/settings). The firmware slot image is
// untouched; the next boot on that slot re-seeds factory defaults.
async function slotResetConfigFlow(slot) {
  const op = beginToolsOperation('slots-reset-config', true);
  if (!op) return;
  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(500);
    const dev = await requestDeviceInfo();
    log(t('slotConfigResetting', slot), 'info');
    const st = await slotProfileErase(slot, dev.timestamp);
    if (st !== 0) throw new Error(slotStatusText(st));
    log(t('slotConfigReset', slot), 'success');
  } catch (e) {
    log(t('slotsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishSlotOperation(op);
  }
}

async function slotWriteFlow() {
  if (!slotImage) return;
  const slot = slotTargetSelect ? parseInt(slotTargetSelect.value, 10) : SLOT_FIRST;
  if (!(slot >= SLOT_FIRST && slot < SLOT_END)) return;
  if (slotImage.length > SLOT_IMG_MAX) { log(t('slotTooBig'), 'error'); return; }
  const displayName = slotNormalizeName(slotNameInput?.value ?? slotMeta.name);
  if (!displayName) return;
  if (slotNameInput) slotNameInput.value = displayName;

  const op = beginToolsOperation('slots-write', true);
  if (!op) return;
  if (progressContainer) progressContainer.style.display = 'block';
  updateProgress(0);
  try {
    if (!port) await connect();
    readBuffer = [];
    await sleep(500);
    const dev = await requestDeviceInfo();
    const ts = dev.timestamp;
    const image = slotImage;
    const assets = slotAssets;
    const crc = crc32Bytes(image);

    log(t('slotErasing', slot), 'info');
    let st = await slotErase(slot, ts);
    if (st !== 0) throw new Error('erase: ' + slotStatusText(st));

    log(t('slotWriting', slot), 'info');
    for (let off = 0; off < image.length; off += SLOT_WRITE_CHUNK) {
      const chunk = image.subarray(off, Math.min(off + SLOT_WRITE_CHUNK, image.length));
      st = await slotWriteChunkRetry(slot, SLOT_IMG_OFFSET + off, ts, chunk);
      if (st !== 0) throw new Error('write @' + off + ': ' + slotStatusText(st));
      const progressChanged = updateProgress(((off + chunk.length) / image.length) * 95);
      if (progressChanged) await waitForProgressPaint();
    }

    const hdr = slotBuildHeader(image.length, crc, { ...slotMeta, name: displayName });
    st = await slotWriteChunkRetry(slot, 0, ts, hdr);
    if (st !== 0) throw new Error('header: ' + slotStatusText(st));

    updateProgress(97);
    await waitForProgressPaint();
    log(t('slotVerifying', slot), 'info');
    const v = await slotValidate(slot);
    if (v.status !== 0 || v.crc !== crc) throw new Error('verify: ' + slotStatusText(v.status));
    log(t('slotWriteOk', slot), 'success');
    if (assets) await slotWriteAssets(slot, assets, ts);
    updateProgress(100);
    slotRenderRow(slot, await slotInfo(slot));
    slotPickDefaultTarget();
    setTimeout(() => { if (progressContainer) progressContainer.style.display = 'none'; }, 1200);
  } catch (e) {
    log(t('slotsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishSlotOperation(op);
  }
}

function clearSlotImage() {
  slotImage = null;
  slotAssets = null;
  slotMeta = { name: '', fwVersion: '' };
  if (slotNameInput) slotNameInput.value = '';
  if (slotFileName) {
    slotFileName.setAttribute('data-i18n', 'fileNoFile');
    slotFileName.textContent = t('fileNoFile');
    slotFileName.classList.remove('has-file');
  }
  if (slotFileLabel) slotFileLabel.classList.remove('has-file');
  if (slotMetaEl) slotMetaEl.textContent = '';
  updateActionButtons();
}

// Start a new slot-image selection and keep the catalog and local picker
// mutually exclusive. Any older in-flight download or FileReader completion is
// ignored, so a quick second choice always wins.
function beginSlotImageLoad(source) {
  const seq = ++slotImageLoadSeq;
  if (slotImageLoadAbort) {
    try { slotImageLoadAbort.abort(); } catch (e) {}
    slotImageLoadAbort = null;
  }
  clearSlotImage();
  if (source === 'url' && slotFileInput) slotFileInput.value = '';
  window.dispatchEvent(new CustomEvent('uvstudio:slotfirmwareselect', { detail: { source } }));
  return seq;
}

function setSlotImageBuffer(buf, name = 'firmware.bin') {
  let parts;
  try {
    parts = window.UVStudioFirmwarePackage.splitFirmwarePackage(new Uint8Array(buf));
  } catch (e) {
    log(t('fwPackageInvalid', name, e?.message ?? String(e)), 'error');
    clearSlotImage();
    return false;
  }
  slotImage = parts.image;
  slotAssets = parts.pack;
  slotMeta = slotExtractMeta(slotImage, name);
  if (slotNameInput) slotNameInput.value = slotMeta.name;
  if (slotFileName) {
    slotFileName.removeAttribute('data-i18n');
    slotFileName.textContent = name;
    slotFileName.classList.add('has-file');
  }
  if (slotFileLabel) slotFileLabel.classList.add('has-file');
  if (slotMetaEl) {
    slotMetaEl.textContent = t(
      'slotDetected',
      slotMeta.name || '?',
      slotMeta.fwVersion || '?',
      Math.round(slotImage.length / 1024)
    );
  }
  log(t('slotFileLoaded', name), 'success');
  if (slotAssets) log(t('fwAssetsDetected', slotAssets.length), 'info');
  updateActionButtons();
  return true;
}

async function loadSlotFirmwareFromURL(url) {
  const seq = beginSlotImageLoad('url');
  const controller = new AbortController();
  slotImageLoadAbort = controller;
  try {
    log(t('loadingFromUrl', url), 'info');
    const urlObj = normalizeFirmwareDownloadURL(url);
    const res = await fetch(urlObj.toString(), {
      cache: 'no-cache',
      mode: 'cors',
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`${t('urlFetchError')} HTTP ${res.status}`);

    const buf = await res.arrayBuffer();
    if (seq !== slotImageLoadSeq) return false;
    const fname = (urlObj.pathname.split('/').pop() || 'firmware.bin').split('?')[0];
    return setSlotImageBuffer(buf, fname);
  } catch (err) {
    if (err && err.name === 'AbortError') return false;
    log(`${t('urlFetchError')} ${err?.message ?? String(err)}`, 'error');
    if (seq === slotImageLoadSeq) clearSlotImage();
    return false;
  } finally {
    if (slotImageLoadAbort === controller) slotImageLoadAbort = null;
  }
}

async function slotUpdateFlow(slot) {
  const row = slotsTableBody?.querySelector(`tr[data-slot="${slot}"]`);
  const latest = row && slotLatestVersions.get(slotCatalogKey(row.dataset.slotEdition));
  if (!latest?.url || slotUpdateDownloadPending || activeOperationToken) return;

  const displayName = row.dataset.slotEdition;
  slotUpdateDownloadPending = true;
  updateActionButtons();
  try {
    const loaded = await loadSlotFirmwareFromURL(latest.url);
    if (!loaded) return;
    if (slotTargetSelect) slotTargetSelect.value = String(slot);
    if (slotNameInput) slotNameInput.value = displayName;
    await slotWriteFlow();
  } finally {
    slotUpdateDownloadPending = false;
    updateActionButtons();
  }
}

if (slotFileInput) {
  slotFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const seq = beginSlotImageLoad('local');
    const fr = new FileReader();
    fr.onload = (ev) => {
      if (seq === slotImageLoadSeq) setSlotImageBuffer(ev.target.result, file.name);
    };
    fr.readAsArrayBuffer(file);
  });
}
if (slotNameInput) slotNameInput.addEventListener('input', updateActionButtons);
if (slotWriteBtn) slotWriteBtn.addEventListener('click', () => { void slotWriteFlow(); });
if (slotsRefreshBtn) slotsRefreshBtn.addEventListener('click', () => { void slotRefreshFlow(); });
slotBuildTable();

window.addEventListener('uvstudio:slotcatalogversions', event => {
  const entries = Array.isArray(event.detail?.entries) ? event.detail.entries : [];
  slotLatestVersions = new Map(entries
    .filter(entry => entry && entry.name && entry.version && entry.url)
    .map(entry => [slotCatalogKey(slotEditionFromFilename(entry.name)), entry]));
  slotRefreshUpdateIndicators();
});

// ========== OVERLAY APPS ==========
// Parallels the firmware-slots feature, targeting the external-flash "Apps"
// region via the 0x073x command family. A .app file already carries its 64-byte
// header (built by pack_app.py), so we just split header/code and write both.
const APP_SLOT_COUNT = 64;        // v7.0.0+ Fusion capacity (0..63)
const APP_V6_SLOT_COUNT = 48;     // firmware capacity after v6.1.0 and before v7
const APP_LEGACY_SLOT_COUNT = 16; // firmware capacity through v6.1.0
const APP_SLOT_FIRST = 0;         // first physical slot index
const appSlotLabel = (s) => String(s + 1);   // physical slot -> user-facing number
const APP_REGION_BASE = 0x102000; // physical external-flash address of slot 0
const APP_SLOT_STRIDE = 0x2000;   // complete slot: metadata/assets + code sectors
const APP_IMG_OFFSET = 0x1000;    // code starts after the header sector
const APP_HDR_SIZE = 64;
const APP_ASSET_OFFSET = 0x100;   // read-only assets live in the header sector (API level 2)
const APP_ASSET_MAX = 0xF00;      // up to the end of the header sector
const APP_MAGIC = 0x31504146;     // "FAP1"
const APP_FLAG_COMMITTED = 1;
const APP_WRITE_CHUNK = 128;      // keep the whole command under the 256 B VCP ring

const MSG_APP_INFO = 0x0730, MSG_APP_INFO_RESP = 0x0731;
const MSG_APP_ERASE = 0x0732, MSG_APP_ERASE_RESP = 0x0733;
const MSG_APP_WRITE = 0x0734, MSG_APP_WRITE_RESP = 0x0735;
const MSG_APP_VALIDATE = 0x0736, MSG_APP_VALIDATE_RESP = 0x0737;

// APP_ERR_* (0..9) -> i18n status keys.
const APP_STATUS_KEY = ['appStateValid', 'appStateBadSlot', 'appStateEmpty', 'appStateAbi',
  'appStateIncomplete', 'appStateBadSize', 'appStateCrc', 'appStateVma', 'appStateAuth',
  'appStateCap'];
// APP_ERR_ABI and APP_ERR_CAP: the image is intact, only the running firmware
// cannot launch it (it says why on the radio). Not an install failure.
const APP_STATUS_INCOMPATIBLE = new Set([3, 9]);
function appStatusText(code) { return t(APP_STATUS_KEY[code] || 'slotStateError'); }

function appVersionParts(value) {
  const match = String(value || '').trim().match(/^v?(\d+(?:\.\d+)*)(?:[-_]?([a-z][0-9a-z.-]*))?$/i);
  if (!match) return null;
  return {
    numbers: match[1].split('.').map(Number),
    suffix: (match[2] || '').toLowerCase()
  };
}

// Compare app versions without making non-version labels look obsolete.
// Returns a negative value when `current` is older than `available`.
function appCompareVersions(current, available) {
  const a = appVersionParts(current);
  const b = appVersionParts(available);
  if (!a || !b) return null;
  const length = Math.max(a.numbers.length, b.numbers.length);
  for (let i = 0; i < length; i++) {
    const delta = (a.numbers[i] || 0) - (b.numbers[i] || 0);
    if (delta) return delta;
  }
  if (a.suffix === b.suffix) return 0;
  if (!a.suffix) return 1;
  if (!b.suffix) return -1;
  return a.suffix.localeCompare(b.suffix, undefined, { numeric: true });
}

function appCatalogKey(name) { return String(name || '').trim().toLowerCase(); }

function appFirmwareVersionFromName(name) {
  const version = String(name || '').match(/\bv?(\d+(?:\.\d+){1,2})\b/i)?.[1];
  if (!version) return '';
  return version.split('.').concat('0', '0').slice(0, 3).join('.');
}

function appSlotCountForFirmware(name) {
  const version = appFirmwareVersionFromName(name);
  if (!version) return APP_LEGACY_SLOT_COUNT;
  if (appCompareVersions(version, '7.0.0') >= 0) return APP_SLOT_COUNT;
  if (appCompareVersions(version, '6.1.0') > 0) return APP_V6_SLOT_COUNT;
  return APP_LEGACY_SLOT_COUNT;
}

const appFileInput   = document.getElementById('appFile');
const appFileLabel   = document.getElementById('appFileLabel');
const appFileName    = document.getElementById('appFileName');
const appTargetSelect = document.getElementById('appTarget');
const appInstallBtn  = document.getElementById('appInstallBtn');
const appsTableBody  = document.getElementById('appsTableBody');
const appMetaEl      = document.getElementById('appMeta');
const appsTableWrap  = document.getElementById('appsTableWrap');
const appRefreshBtn = document.getElementById('appRefreshBtn');
const appDeleteAllBtn = document.getElementById('appDeleteAllBtn');
const appDeleteAllModal = document.getElementById('appDeleteAllModal');
const appDeleteAllTitle = document.getElementById('appDeleteAllTitle');
const appDeleteAllBody = document.getElementById('appDeleteAllBody');
const appDeleteAllClose = document.getElementById('appDeleteAllClose');
const appDeleteAllCancelBtn = document.getElementById('appDeleteAllCancelBtn');
const appDeleteAllConfirmBtn = document.getElementById('appDeleteAllConfirmBtn');
const appRenumberBtn = document.getElementById('appRenumberBtn');
const appOrderActions = document.getElementById('appOrderActions');
const appOrderApplyBtn = document.getElementById('appOrderApplyBtn');
const appOrderCancelBtn = document.getElementById('appOrderCancelBtn');
// Shown when the Catalog tab is requested while a new order is pending.
const appOrderNotice = document.getElementById('appOrderNotice');
const appEmptyInstalled = document.getElementById('appEmptyInstalled');
const appEmptyInstalledText = document.getElementById('appEmptyInstalledText');
const appInstalledCount = document.getElementById('appInstalledCount');
const appInstalledTabCount = document.getElementById('appInstalledTabCount');
const appCapacityText = document.getElementById('appCapacityText');
const appCapacityBar = document.getElementById('appCapacityBar');
const appManagerFirmware = document.getElementById('appManagerFirmware');
const appManagerCompatibility = document.getElementById('appManagerCompatibility');
const appInstalledTab = document.getElementById('appInstalledTab');
const appCatalogTab = document.getElementById('appCatalogTab');
const appCommunityTab = document.getElementById('appCommunityTab');
const appManagerPanels = {
  installed: [appInstalledTab, document.getElementById('appInstalledPanel')],
  catalog: [appCatalogTab, document.getElementById('appCatalogPanel')],
  community: [appCommunityTab, document.getElementById('appCommunityPanel')]
};

let appImage = null;   // full .app bytes (header + code)
let appMeta  = { name: '', version: '', codeSize: 0, assetSize: 0 };
let appImageLoadSeq = 0;
let appImageLoadAbort = null;
let appLatestVersions = new Map();
let appCompatibleVersions = new Map();
// Community apps by header name (app-catalog.js): their rows get a badge, and
// a newer published version the update button, checked against its sha256.
let appCommunityApps = new Map();
let appCurrentFirmwareVersion = '';
let appCurrentFirmwareName = '';
let appActiveSlotCount = APP_SLOT_COUNT;
let appCompatibilityKnown = false;
let appUpdateDownloadPending = false;
const appSlotStatuses = new Map();
let appOrderBaseline = [];
let appOrderDraft = [];
let appOrderDragSlot = null;
let appOrderDropIndex = null;

function appManagerSelectPanel(name) {
  Object.entries(appManagerPanels).forEach(([key, [tab, panel]]) => {
    const active = key === name;
    if (tab) {
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
    }
    if (panel) {
      panel.classList.toggle('active', active);
      panel.hidden = !active;
    }
  });
}

function appUpdateManagerSummary() {
  let installed = 0;
  for (const status of appSlotStatuses.values()) if (status === 0) installed++;
  if (appInstalledCount) appInstalledCount.textContent = t('appManagerInstalledCount', installed);
  if (appInstalledTabCount) appInstalledTabCount.textContent = String(installed);
  if (appCapacityText) appCapacityText.textContent = t('appManagerCapacity', installed, appActiveSlotCount);
  if (appCapacityBar) {
    appCapacityBar.setAttribute('aria-valuemax', String(appActiveSlotCount));
    appCapacityBar.setAttribute('aria-valuenow', String(installed));
    const fill = appCapacityBar.querySelector('span');
    if (fill) fill.style.width = `${installed / appActiveSlotCount * 100}%`;
  }
  const ready = appSlotStatuses.size === appActiveSlotCount;
  const free = ready ? [...appSlotStatuses.values()].filter(status => status === 2).length : 0;
  if (appEmptyInstalled) {
    appEmptyInstalled.hidden = installed !== 0;
  }
  if (appEmptyInstalledText) {
    appEmptyInstalledText.textContent = ready ? t('appManagerNoInstalled') : t('appManagerConnectHint');
  }
  const apps = [];
  appsTableBody?.querySelectorAll('tr[data-app-name]').forEach(row => {
    const slot = Number.parseInt(row.dataset.slot || '', 10);
    if (!Number.isInteger(slot) || appSlotStatuses.get(slot) !== 0) return;
    apps.push({
      slot,
      name: row.dataset.appName || '',
      version: row.dataset.appVersion || ''
    });
  });
  window.dispatchEvent(new CustomEvent('uvstudio:appinventory', {
    detail: { ready, installed, free, apps }
  }));
}

function appSelectFirstEmptySlot() {
  if (!appTargetSelect) return;
  const free = [...appTargetSelect.options].find(option => appSlotStatuses.get(Number(option.value)) === 2);
  if (free) appTargetSelect.value = free.value;
}

function appOrderIsDirty() {
  return appOrderBaseline.length === appOrderDraft.length &&
    appOrderBaseline.some((slot, index) => slot !== appOrderDraft[index]);
}

function appOrderMoves(baseline = appOrderBaseline, draft = appOrderDraft) {
  return baseline
    .map((target, index) => ({ target, source: draft[index] }))
    .filter(move => move.source !== move.target);
}

function appOrderSupported() {
  return appSlotStatuses.size === appActiveSlotCount &&
    appCompareVersions(appCurrentFirmwareVersion, '6.1.0') > 0;
}

function appCanReorder() {
  return appOrderSupported() && appOrderDraft.length > 1;
}

function appRenumberMoves(installed = appOrderBaseline) {
  if (!installed.length) return [];
  const last = installed[installed.length - 1];
  const installedSet = new Set(installed);
  const slots = Array.from({ length: last + 1 }, (_, slot) => slot);
  const sources = installed.concat(slots.filter(slot => !installedSet.has(slot)));
  return slots
    .map((target, index) => ({ target, source: sources[index] }))
    .filter(move => move.source !== move.target);
}

function appCanRenumber() {
  return appOrderSupported() && !appOrderIsDirty() && appRenumberMoves().length > 0;
}

function appRenderOrder() {
  if (!appsTableBody) return;
  const rows = new Map([...appsTableBody.querySelectorAll('tr[data-slot]')]
    .map(row => [Number(row.dataset.slot), row]));
  const sourceByTarget = new Map(appOrderBaseline
    .map((target, index) => [target, appOrderDraft[index]]));

  for (let target = APP_SLOT_FIRST; target < appActiveSlotCount; target++) {
    const source = sourceByTarget.has(target) ? sourceByTarget.get(target) : target;
    const row = rows.get(source);
    if (!row) continue;
    row.dataset.targetSlot = String(target);
    row.querySelector('.slot-idx').textContent = appSlotLabel(target);
    row.classList.toggle('app-slot-order-pending', source !== target);
    appsTableBody.appendChild(row);
  }
}

function appResetOrder() {
  appOrderBaseline = [...appSlotStatuses.entries()]
    .filter(([, status]) => status === 0)
    .map(([slot]) => slot)
    .sort((a, b) => a - b);
  appOrderDraft = [...appOrderBaseline];
  appRenderOrder();
  updateAppButtons();
}

function appClearOrderDropMarker() {
  if (!appsTableBody) return;
  appsTableBody.querySelectorAll('.app-order-drop-before, .app-order-drop-after').forEach(row => {
    row.classList.remove('app-order-drop-before', 'app-order-drop-after');
  });
}

function appOrderDragStart(slot, event) {
  const busy = appUpdateDownloadPending || Boolean(activeOperationToken);
  if (!appCanReorder() || busy || appOrderDraft.indexOf(slot) < 0 ||
      event.target.closest('button, a, input, select')) {
    event.preventDefault();
    return;
  }
  appOrderDragSlot = slot;
  appOrderDropIndex = appOrderDraft.indexOf(slot);
  event.currentTarget.classList.add('app-order-dragging');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', String(slot));
}

function appOrderDragOver(targetSlot, event) {
  if (appOrderDragSlot === null) return;
  const targetIndex = appOrderDraft.indexOf(targetSlot);
  const sourceIndex = appOrderDraft.indexOf(appOrderDragSlot);
  if (targetIndex < 0 || sourceIndex < 0) return;

  event.preventDefault();
  event.dataTransfer.dropEffect = 'move';
  const row = event.currentTarget;
  const bounds = row.getBoundingClientRect();
  const after = event.clientY >= bounds.top + bounds.height / 2;
  let insertIndex = targetIndex + (after ? 1 : 0);
  if (sourceIndex < insertIndex) insertIndex--;
  appOrderDropIndex = Math.max(0, Math.min(appOrderDraft.length - 1, insertIndex));

  appClearOrderDropMarker();
  if (targetSlot !== appOrderDragSlot)
    row.classList.add(after ? 'app-order-drop-after' : 'app-order-drop-before');

  if (appsTableWrap) {
    const viewport = appsTableWrap.getBoundingClientRect();
    const edge = 48;
    if (event.clientY < viewport.top + edge) appsTableWrap.scrollTop -= 14;
    else if (event.clientY > viewport.bottom - edge) appsTableWrap.scrollTop += 14;
  }
}

function appOrderDrop(event) {
  if (appOrderDragSlot === null || appOrderDropIndex === null) return;
  event.preventDefault();
  const sourceIndex = appOrderDraft.indexOf(appOrderDragSlot);
  if (sourceIndex >= 0 && sourceIndex !== appOrderDropIndex) {
    const [slot] = appOrderDraft.splice(sourceIndex, 1);
    appOrderDraft.splice(appOrderDropIndex, 0, slot);
    appRenderOrder();
    updateAppButtons();
  }
  appOrderDragEnd();
}

function appOrderDragEnd() {
  if (appsTableBody) {
    appsTableBody.querySelectorAll('.app-order-dragging').forEach(row => {
      row.classList.remove('app-order-dragging');
    });
  }
  appClearOrderDropMarker();
  appOrderDragSlot = null;
  appOrderDropIndex = null;
}

function appCancelOrder() {
  appOrderDraft = [...appOrderBaseline];
  appRenderOrder();
  updateAppButtons();
}

// Shared capability gate for every app action (scan, install, delete). A firmware
// without overlay-app support never answers 0x0730, so rather than let a later
// erase/write hang on a 30 s timeout we probe one slot up front. Returns the
// slot-0 info when supported, or null so the caller aborts. The navigation owns
// the user-facing compatibility state; `fw` is retained for diagnostic logging.
async function appsProbe(fw) {
  try {
    try { return await appInfo(APP_SLOT_FIRST); }
    catch (e1) {
      if (e1?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e1;
      await sleep(150);
      return await appInfo(APP_SLOT_FIRST);   // one retry avoids a false negative
    }
  } catch (e) {
    if (e?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e;
    const name = (fw && fw.name) || t('appUnknownFirmware');
    log(t('appUnsupportedLog', name), 'error');   // firmware still named in the log for diagnostics
    return null;
  }
}

function appParseHeader(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const readStr = (off, len) => { let s = ''; for (let i = 0; i < len; i++) { const c = b[off + i]; if (!c) break; s += String.fromCharCode(c); } return s; };
  // app_header_t: magic@0 hdr@4 abi@6 codeSize@8 crc@12 entry@16 flags@18
  //               name@20 version@36 linkVma@52 caps@56 assetSize@60 assetCrc@62.
  return {
    magic: dv.getUint32(0, true),
    abiVersion: dv.getUint16(6, true),
    codeSize: dv.getUint32(8, true),
    codeCrc32: dv.getUint32(12, true),
    name: readStr(20, 16),
    version: readStr(36, 16),
    linkVma: dv.getUint32(52, true) >>> 0,
    assetSize: dv.getUint16(60, true)
  };
}

async function appInfo(slot, timeoutMs = 3000) {
  const data = await slotCommand(MSG_APP_INFO, Uint8Array.of(slot), MSG_APP_INFO_RESP, timeoutMs);
  return { slot, status: data[1], hdr: appParseHeader(data.subarray(2, 2 + APP_HDR_SIZE)) };
}
async function appErase(slot, ts) {
  const d = new Uint8Array(6); d[0] = slot; new DataView(d.buffer).setUint32(2, ts, true);
  return (await slotCommand(MSG_APP_ERASE, d, MSG_APP_ERASE_RESP, 30000))[1];
}
async function appWriteChunk(slot, offset, ts, chunk) {
  const d = new Uint8Array(12 + chunk.length); const dv = new DataView(d.buffer);
  d[0] = slot; dv.setUint32(2, offset, true); dv.setUint16(6, chunk.length, true); dv.setUint32(8, ts, true);
  d.set(chunk, 12);
  return (await slotCommand(MSG_APP_WRITE, d, MSG_APP_WRITE_RESP, 1500))[1];
}
async function appWriteChunkRetry(slot, offset, ts, chunk) {
  for (let attempt = 0; ; attempt++) {
    try { return await appWriteChunk(slot, offset, ts, chunk); }
    catch (e) { if (attempt >= 4) throw e; await sleep(60); }
  }
}
async function appValidate(slot) {
  return (await slotCommand(MSG_APP_VALIDATE, Uint8Array.of(slot), MSG_APP_VALIDATE_RESP, 20000))[1];
}
// Slot info only tells that an app is there. Ask the firmware whether it can
// launch it (ABI, API level, capabilities): the same check as on the radio.
// info.compat holds that APP_ERR_* verdict, 0 when launchable or unknown.
async function appCheckCompat(info) {
  if (!info || info.status !== 0) return info;
  try { info.compat = await appValidate(info.slot); }
  catch (e) {
    if (e?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e;
    info.compat = 0;
  }
  return info;
}

function appSlotAddress(slot) {
  return APP_REGION_BASE + slot * APP_SLOT_STRIDE;
}

async function appReadSlotImage(slot, timestamp) {
  const image = new Uint8Array(APP_SLOT_STRIDE);
  const base = appSlotAddress(slot);
  for (let offset = 0; offset < image.length; offset += FLASH_DUMP_CHUNK) {
    const length = Math.min(FLASH_DUMP_CHUNK, image.length - offset);
    image.set(await readExternalFlashChunk(base + offset, length, timestamp), offset);
  }
  return image;
}

async function appVerifySlotSector(expected, address, timestamp, crcSupported) {
  if (crcSupported) {
    const actualCrc = await readExternalFlashCrc32(address, expected.length, timestamp);
    if (actualCrc === crc32Bytes(expected)) return;
  }

  for (let offset = 0; offset < expected.length; offset += FLASH_DUMP_CHUNK) {
    const chunk = expected.subarray(offset, Math.min(offset + FLASH_DUMP_CHUNK, expected.length));
    const actual = await readExternalFlashChunk(address + offset, chunk.length, timestamp);
    for (let index = 0; index < chunk.length; index++) {
      if (actual[index] !== chunk[index]) {
        throw new Error(t('flashVerifyError', flashAddress(address + offset + index)));
      }
    }
  }
}

async function appWriteSlotImage(slot, image, timestamp, crcSupported) {
  const base = appSlotAddress(slot);
  for (let sectorOffset = 0; sectorOffset < APP_SLOT_STRIDE; sectorOffset += FLASH_SECTOR_SIZE) {
    const sector = image.subarray(sectorOffset, sectorOffset + FLASH_SECTOR_SIZE);
    const address = base + sectorOffset;
    if (crcSupported &&
        await readExternalFlashCrc32(address, sector.length, timestamp) === crc32Bytes(sector)) continue;

    await eraseExternalFlashSector(address, timestamp);
    for (let offset = 0; offset < sector.length; offset += FLASH_WRITE_CHUNK) {
      const chunk = sector.subarray(offset, Math.min(offset + FLASH_WRITE_CHUNK, sector.length));
      if (chunk.every(value => value === 0xff)) continue;
      await writeExternalFlashChunk(address + offset, chunk, timestamp);
    }
    await appVerifySlotSector(sector, address, timestamp, crcSupported);
  }
}

function appRenderRow(slot, info) {
  if (!appsTableBody) return;
  const row = appsTableBody.querySelector(`tr[data-slot="${slot}"]`);
  if (!row) return;
  const valid = info && info.status === 0;
  const hdr = info && info.hdr;
  row.classList.remove('app-slot-pending');
  row.classList.toggle('app-slot-installed', Boolean(valid));
  row.classList.toggle('app-slot-empty', Boolean(info && info.status === 2));
  row.querySelector('.slot-name').textContent = valid ? (hdr.name || '—') : '—';
  row.querySelector('.slot-version-value').textContent = valid ? (hdr.version || '—') : '—';
  if (valid) {
    row.dataset.appName = hdr.name || '';
    row.dataset.appVersion = hdr.version || '';
    row.dataset.appCodeSize = String(hdr.codeSize || 0);
    row.dataset.appAssetSize = String(hdr.assetSize || 0);
  } else {
    delete row.dataset.appName;
    delete row.dataset.appVersion;
    delete row.dataset.appCodeSize;
    delete row.dataset.appAssetSize;
  }
  if (valid && info.compat) row.dataset.appCompat = String(info.compat);
  else delete row.dataset.appCompat;
  if (info) {
    row.dataset.appStatus = String(info.status);
    appSlotStatuses.set(slot, info.status);
  } else {
    delete row.dataset.appStatus;
    appSlotStatuses.delete(slot);
  }
  appRenderRowSize(row);
  appRenderRowState(row);
  appRenderCommunityBadge(row);
  const del = row.querySelector('.app-act-delete');
  if (del) {
    del.hidden = !valid;
    del.disabled = !valid;
  }
  appRenderUpdateIndicator(row);
}

function appFormatBytes(size) {
  const bytes = Number.isFinite(size) && size > 0 ? size : 0;
  return bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} KB`;
}

function appRenderRowSize(row) {
  const code = row.querySelector('.slot-code-size');
  const assets = row.querySelector('.slot-asset-size');
  if (!code || !assets) return;
  if (!row.dataset.appName) {
    code.textContent = '—';
    assets.textContent = '';
    return;
  }
  code.textContent = t('appSizeCode', appFormatBytes(Number(row.dataset.appCodeSize)));
  assets.textContent = t('appSizeAssets', appFormatBytes(Number(row.dataset.appAssetSize)));
}

function appHasFirmwareMismatch(row) {
  if (!appCompatibilityKnown || !row.dataset.appName) return false;
  const key = appCatalogKey(row.dataset.appName);
  const latest = appLatestVersions.get(key);
  if (!latest) return false; // Local/unpublished app: compatibility is unknown.
  const compatible = appCompatibleVersions.get(key);
  if (!compatible) return true;
  return appCompareVersions(row.dataset.appVersion, compatible.version) > 0;
}

function appRenderRowState(row) {
  const stateCell = row.querySelector('.slot-state');
  if (!stateCell) return;
  if (row.dataset.appStatus === undefined) {
    stateCell.textContent = '—';
    stateCell.className = 'slot-state';
    return;
  }
  const status = Number(row.dataset.appStatus);
  // The firmware's own verdict comes first; the catalog only knows published apps.
  const compat = status === 0 ? Number(row.dataset.appCompat || 0) : 0;
  const mismatch = status === 0 && !compat && appHasFirmwareMismatch(row);
  stateCell.textContent = compat
    ? appStatusText(compat)
    : (mismatch ? t('appStateFirmwareMismatch', appCurrentFirmwareVersion) : appStatusText(status));
  stateCell.className = 'slot-state ' + (compat || mismatch ? 'bad' : (status === 0 ? 'ok' : (status === 2 ? 'empty' : 'bad')));
}

function appRenderCommunityBadge(row) {
  const cell = row.querySelector('.slot-name');
  if (!cell) return;
  let badge = cell.querySelector('.app-community-badge');
  if (!row.dataset.appName || !appCommunityApps.has(appCatalogKey(row.dataset.appName))) {
    if (badge) badge.remove();
    return;
  }
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'app-community-badge';
    cell.appendChild(badge);
  }
  badge.textContent = t('appManagerCommunity');
  badge.title = t('appCommunityBadgeHint');
}

// The version an installed app can be updated to: the official catalog of the
// radio's firmware, else the community's (whose ids never clash with it).
function appLatestAvailable(row) {
  const key = appCatalogKey(row.dataset.appName);
  if (appCompatibilityKnown && appCompatibleVersions.has(key)) return appCompatibleVersions.get(key);
  return appCommunityApps.get(key) || null;
}

function appRenderUpdateIndicator(row) {
  const button = row.querySelector('.app-update-button');
  if (!button) return;
  const latest = row.dataset.appName ? appLatestAvailable(row) : null;
  const comparison = latest ? appCompareVersions(row.dataset.appVersion, latest.version) : null;
  const outdated = comparison !== null && comparison < 0;
  row.classList.toggle('app-outdated', Boolean(outdated));
  button.hidden = !outdated;
  if (outdated) {
    const targetVersion = tableActionVersionLabel(latest.version);
    const detail = t('appUpdateAction', targetVersion);
    setTableActionIcon(button, 'update', detail, targetVersion);
    button.disabled = !serialSupported || appUpdateDownloadPending ||
      Boolean(activeOperationToken) || appOrderIsDirty();
  } else {
    setTableActionIcon(button, 'update', t('appUpdateShort'));
    button.disabled = true;
  }
}

function appRefreshUpdateIndicators() {
  if (!appsTableBody) return;
  appsTableBody.querySelectorAll('tr[data-slot]').forEach(row => {
    appRenderRowSize(row);
    appRenderRowState(row);
    appRenderCommunityBadge(row);
    appRenderUpdateIndicator(row);
  });
}

function appBuildTable() {
  if (!appsTableBody) return;
  appsTableBody.innerHTML = '';
  for (let s = APP_SLOT_FIRST; s < appActiveSlotCount; s++) {
    const tr = document.createElement('tr');
    tr.className = 'app-slot-pending';
    tr.dataset.slot = String(s);
    tr.innerHTML =
      `<td class="slot-idx">${appSlotLabel(s)}</td>` +
      `<td class="slot-name">—</td>` +
      `<td class="slot-version"><span class="slot-version-value">—</span></td>` +
      `<td class="slot-size"><span class="slot-code-size">—</span><span class="slot-asset-size"></span></td>` +
      `<td><span class="slot-state">—</span></td>` +
      `<td class="slot-actions"><div class="slot-actions-group"></div></td>`;
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn table-icon-action is-danger app-act-delete';
    setTableActionIcon(del, 'delete', t('appDelete'));
    del.hidden = true;
    del.disabled = true;
    del.addEventListener('click', () => { void appDeleteFlow(s); });
    const update = document.createElement('button');
    update.type = 'button';
    update.className = 'btn table-icon-action is-primary app-update-button';
    setTableActionIcon(update, 'update', t('appUpdateShort'));
    update.hidden = true;
    update.disabled = true;
    update.addEventListener('click', () => { void appUpdateFlow(s); });
    tr.addEventListener('dragstart', event => appOrderDragStart(s, event));
    tr.addEventListener('dragover', event => appOrderDragOver(s, event));
    tr.addEventListener('drop', appOrderDrop);
    tr.addEventListener('dragend', appOrderDragEnd);
    const actions = tr.querySelector('.slot-actions-group');
    actions.appendChild(update);
    actions.appendChild(del);
    appsTableBody.appendChild(tr);
  }
  if (appTargetSelect) {
    appTargetSelect.innerHTML = '';
    for (let s = APP_SLOT_FIRST; s < appActiveSlotCount; s++) {
      const o = document.createElement('option'); o.value = String(s); o.textContent = appSlotLabel(s);
      appTargetSelect.appendChild(o);
    }
  }
}

function appSetSlotCount(count) {
  if (count === appActiveSlotCount && appsTableBody?.children.length === count) return;
  appActiveSlotCount = count;
  appSlotStatuses.clear();
  appBuildTable();
  appResetOrder();
  appUpdateManagerSummary();
}

async function finishAppOperation(op) {
  endToolsOperation(op);
  updateAppButtons();
}

async function appRefreshFlow() {
  const op = beginToolsOperation('apps-refresh', false);
  if (!op) return;
  appSlotStatuses.clear();
  appResetOrder();
  if (appsTableBody) appsTableBody.querySelectorAll('tr[data-slot]').forEach(row => {
    row.classList.add('app-slot-pending');
    row.classList.remove('app-slot-installed', 'app-slot-empty');
  });
  appUpdateManagerSummary();
  try {
    if (!port) await connect();

    // Capability gate. A firmware without overlay-app support (Fusion, Transfer,
    // stock…) never answers 0x0730, so scanning every advertised slot would hang
    // timeouts and then show cryptic errors - the exact confusion we want to
    // avoid. Instead: confirm the radio answers device-info (so we can name it),
    // then probe a single slot. A timeout there means "no overlay apps" -> a
    // clear modal, and we stop before the scan.
    let fw;
    try {
      readBuffer = []; await sleep(300);
      fw = await requestDeviceInfo();
      if (appManagerFirmware) appManagerFirmware.textContent = fw.name || t('appUnknownFirmware');
      if (appManagerCompatibility) appManagerCompatibility.textContent = t('appManagerCheckingCompatibility');
      const firmwareVersion = appFirmwareVersionFromName(fw.name);
      appCurrentFirmwareName = fw.name || '';
      appSetSlotCount(appSlotCountForFirmware(fw.name));
      if (firmwareVersion !== appCurrentFirmwareVersion) {
        appCurrentFirmwareVersion = firmwareVersion;
        appCompatibilityKnown = false;
        appCompatibleVersions = new Map();
      }
      if (firmwareVersion) {
        window.dispatchEvent(new CustomEvent('uvstudio:appfirmwareversion', {
          detail: { firmwareVersion }
        }));
      }
    } catch (e) {
      // Radio not answering at all: a plain connection error, not a capability issue.
      log(t('appsError', e?.message ?? String(e)), 'error');
      return;
    }

    const firstInfo = await appsProbe(fw);
    if (!firstInfo) return;                    // unsupported firmware -> modal shown

    log(t('appsScanning'), 'info');
    appRenderRow(APP_SLOT_FIRST, await appCheckCompat(firstInfo));   // already read by the probe
    for (let s = APP_SLOT_FIRST + 1; s < appActiveSlotCount; s++) {
      try { appRenderRow(s, await appCheckCompat(await appInfo(s))); }
      catch (e) {
        if (e?.code === 'UVSTUDIO_SERIAL_SESSION_CHANGED' || !port) throw e;
        appRenderRow(s, { slot: s, status: 6, hdr: null });
      }
    }
    appResetOrder();
    appUpdateManagerSummary();
    appSelectFirstEmptySlot();
    log(t('appsScanDone'), 'success');
  } catch (e) {
    log(t('appsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishAppOperation(op);
  }
}

let appDeleteAllResolve = null;
let appDeleteAllFocusOrigin = null;

function closeAppDeleteAllModal(confirmed) {
  if (!appDeleteAllModal?.classList.contains('show')) return;
  const resolve = appDeleteAllResolve;
  const focusTarget = appDeleteAllFocusOrigin;
  appDeleteAllResolve = null;
  appDeleteAllFocusOrigin = null;
  appDeleteAllModal.classList.remove('show');
  appDeleteAllModal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (focusTarget && document.contains(focusTarget)) {
    focusTarget.focus({ preventScroll: true });
  }
  if (resolve) resolve(Boolean(confirmed));
}

function confirmAppDeleteAll(count) {
  if (!appDeleteAllModal || appDeleteAllResolve) return Promise.resolve(false);
  appDeleteAllFocusOrigin = document.activeElement;
  if (appDeleteAllTitle) appDeleteAllTitle.textContent = t('appDeleteAllTitle');
  if (appDeleteAllBody) appDeleteAllBody.textContent = t('appDeleteAllConfirm', count);
  appDeleteAllModal.classList.add('show');
  appDeleteAllModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => appDeleteAllCancelBtn?.focus());
  return new Promise(resolve => { appDeleteAllResolve = resolve; });
}

if (appDeleteAllClose) {
  appDeleteAllClose.addEventListener('click', () => closeAppDeleteAllModal(false));
}
if (appDeleteAllCancelBtn) {
  appDeleteAllCancelBtn.addEventListener('click', () => closeAppDeleteAllModal(false));
}
if (appDeleteAllConfirmBtn) {
  appDeleteAllConfirmBtn.addEventListener('click', () => closeAppDeleteAllModal(true));
}
if (appDeleteAllModal) {
  appDeleteAllModal.addEventListener('click', event => {
    if (event.target === appDeleteAllModal) closeAppDeleteAllModal(false);
  });
  appDeleteAllModal.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeAppDeleteAllModal(false);
  });
}

async function appDeleteFlow(slot) {
  if (appOrderIsDirty()) {
    log(t('appOrderApplyFirst'), 'error');
    return;
  }
  const op = beginToolsOperation('apps-delete', true);
  if (!op) return;
  try {
    if (!port) await connect();
    readBuffer = []; await sleep(500);
    const dev = await requestDeviceInfo();
    if (!(await appsProbe(dev))) return;   // unsupported firmware -> modal, no 30 s erase hang
    log(t('appErasing', appSlotLabel(slot)), 'info');
    const st = await appErase(slot, dev.timestamp);
    if (st !== 0) throw new Error(appStatusText(st));
    log(t('appErased', appSlotLabel(slot)), 'success');
    appRenderRow(slot, await appInfo(slot));
    appResetOrder();
    appUpdateManagerSummary();
    appSelectFirstEmptySlot();
  } catch (e) {
    log(t('appsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishAppOperation(op);
  }
}

async function appDeleteAllFlow() {
  if (appOrderIsDirty()) {
    log(t('appOrderApplyFirst'), 'error');
    return;
  }
  if (appSlotStatuses.size !== appActiveSlotCount) return;
  const slots = [...appSlotStatuses.entries()]
    .filter(([, status]) => status === 0)
    .map(([slot]) => slot)
    .sort((a, b) => a - b);
  if (!slots.length || !await confirmAppDeleteAll(slots.length)) return;

  const op = beginToolsOperation('apps-delete-all', true);
  if (!op) return;
  updateAppButtons();
  if (progressContainer) progressContainer.style.display = 'block';
  updateProgress(0);
  try {
    if (!port) await connect();
    readBuffer = []; await sleep(500);
    const dev = await requestDeviceInfo();
    if (!(await appsProbe(dev))) return;
    for (let index = 0; index < slots.length; index++) {
      const slot = slots[index];
      log(t('appErasing', appSlotLabel(slot)), 'info');
      const status = await appErase(slot, dev.timestamp);
      if (status !== 0) throw new Error(appStatusText(status));
      appRenderRow(slot, await appInfo(slot));
      updateProgress(Math.round((index + 1) * 100 / slots.length));
    }
    log(t('appDeleteAllDone'), 'success');
  } catch (error) {
    log(t('appsError', error?.message ?? String(error)), 'error');
  } finally {
    appResetOrder();
    appUpdateManagerSummary();
    appSelectFirstEmptySlot();
    setTimeout(() => { if (progressContainer) progressContainer.style.display = 'none'; }, 1200);
    await finishAppOperation(op);
  }
}

// onProgress (optional): report progress to the caller (catalog card mini gauge)
// instead of the shared progress bar under the tool.
async function appInstallFlow({ onProgress } = {}) {
  if (appOrderIsDirty()) {
    log(t('appOrderApplyFirst'), 'error');
    return;
  }
  if (!appImage) return;
  if (appSlotStatuses.size !== appActiveSlotCount) {
    log(t('appManagerScanBeforeInstall'), 'error');
    return;
  }
  const slot = appTargetSelect ? parseInt(appTargetSelect.value, 10) : APP_SLOT_FIRST;
  if (!(slot >= APP_SLOT_FIRST && slot < appActiveSlotCount)) return;
  // .app = header + code (codeSize bytes) + optional read-only assets. The code
  // goes to the code sector, the assets to the header sector at APP_ASSET_OFFSET.
  const header = appImage.subarray(0, APP_HDR_SIZE);
  const codeEnd = APP_HDR_SIZE + appMeta.codeSize;
  const code = appImage.subarray(APP_HDR_SIZE, codeEnd);
  const assets = appImage.subarray(codeEnd);
  if (appMeta.codeSize === 0 || codeEnd > appImage.length ||
      assets.length !== appMeta.assetSize) { log(t('appBadFile'), 'error'); return; }
  if (code.length > 0x1000 || assets.length > APP_ASSET_MAX) { log(t('appTooBig'), 'error'); return; }
  const total = code.length + assets.length;

  const op = beginToolsOperation('apps-install', true);
  if (!op) return;
  const inline = typeof onProgress === 'function';
  let inlinePercent = -1;
  const reportProgress = percent => {
    if (!inline) return updateProgress(percent);
    const rounded = Math.round(percent);
    if (rounded === inlinePercent) return false;
    inlinePercent = rounded;
    onProgress(rounded);
    return true;
  };
  if (!inline && progressContainer) progressContainer.style.display = 'block';
  reportProgress(0);
  try {
    if (!port) await connect();
    readBuffer = []; await sleep(500);
    const dev = await requestDeviceInfo();
    if (!(await appsProbe(dev))) {           // unsupported firmware -> modal, abort before erase
      if (!inline && progressContainer) progressContainer.style.display = 'none';
      return;
    }
    const ts = dev.timestamp;

    log(t('appErasing', appSlotLabel(slot)), 'info');
    let st = await appErase(slot, ts);
    if (st !== 0) throw new Error('erase: ' + appStatusText(st));

    log(t('appInstalling', appSlotLabel(slot)), 'info');
    let done = 0;
    for (const [part, base] of [[code, APP_IMG_OFFSET], [assets, APP_ASSET_OFFSET]]) {
      for (let off = 0; off < part.length; off += APP_WRITE_CHUNK) {
        const chunk = part.subarray(off, Math.min(off + APP_WRITE_CHUNK, part.length));
        st = await appWriteChunkRetry(slot, base + off, ts, chunk);
        if (st !== 0) throw new Error('write @' + (base + off) + ': ' + appStatusText(st));
        done += chunk.length;
        const changed = reportProgress((done / total) * 95);
        if (changed) await waitForProgressPaint();
      }
    }
    // header last: it carries the committed flag, so a partial write never validates
    st = await appWriteChunkRetry(slot, 0, ts, header);
    if (st !== 0) throw new Error('header: ' + appStatusText(st));

    reportProgress(97); await waitForProgressPaint();
    log(t('appVerifying', appSlotLabel(slot)), 'info');
    const vs = await appValidate(slot);
    if (vs !== 0 && !APP_STATUS_INCOMPATIBLE.has(vs)) throw new Error('verify: ' + appStatusText(vs));
    reportProgress(100);
    if (vs === 0) log(t('appInstalled', appSlotLabel(slot)), 'success');
    else log(t('appInstalledIncompatible', appSlotLabel(slot), appStatusText(vs)), 'warning');
    const installed = await appInfo(slot);
    installed.compat = vs;                 // just validated: no second round trip
    appRenderRow(slot, installed);
    appResetOrder();
    appUpdateManagerSummary();
    appSelectFirstEmptySlot();
    if (!inline) setTimeout(() => { if (progressContainer) progressContainer.style.display = 'none'; }, 1200);
  } catch (e) {
    log(t('appsError', e?.message ?? String(e)), 'error');
  } finally {
    await finishAppOperation(op);
  }
}

function appUpdateOrderControls() {
  const busy = appUpdateDownloadPending || Boolean(activeOperationToken);
  const canReorder = appCanReorder();
  const dirty = appOrderIsDirty();
  const canRenumber = appCanRenumber();
  if (appRenumberBtn) {
    appRenumberBtn.hidden = !canRenumber;
    appRenumberBtn.disabled = busy || !canRenumber;
  }
  if (appOrderActions) appOrderActions.hidden = !dirty;
  if (appOrderApplyBtn) appOrderApplyBtn.disabled = busy || !dirty;
  if (appOrderCancelBtn) appOrderCancelBtn.disabled = busy || !dirty;
  if (appOrderNotice && !dirty) appOrderNotice.hidden = true;

  if (!appsTableBody) return;
  appsTableBody.querySelectorAll('tr[data-slot]').forEach(row => {
    const slot = Number(row.dataset.slot);
    const visible = canReorder && appSlotStatuses.get(slot) === 0;
    row.draggable = visible && !busy;
    row.classList.toggle('app-slot-draggable', visible && !busy);
  });
}

async function appRewriteOrderFlow(moves, validateTargets, operation, doneKey) {
  const op = beginToolsOperation(operation, true);
  if (!op) return;
  updateAppButtons();
  let storageTouched = false;
  let refreshNeeded = false;
  if (progressContainer) progressContainer.style.display = 'block';
  updateProgress(0);

  try {
    if (!port) await connect();
    readBuffer = []; await sleep(300);
    const dev = await requestDeviceInfo();
    if (!(await appsProbe(dev))) return;
    if (!(await hasExternalFlashSupport(dev.timestamp))) return;

    const sources = [...new Set(moves.map(move => move.source))];
    const images = new Map();
    log(t('appOrderReading'), 'info');
    for (let index = 0; index < sources.length; index++) {
      const slot = sources[index];
      images.set(slot, await appReadSlotImage(slot, dev.timestamp));
      updateProgress(((index + 1) / sources.length) * 35);
      await waitForProgressPaint();
    }

    const crcSupported = await detectExternalFlashCrcSupport(dev.timestamp);
    log(t('appOrderWriting'), 'info');
    for (let index = 0; index < moves.length; index++) {
      const move = moves[index];
      storageTouched = true;
      await appWriteSlotImage(move.target, images.get(move.source), dev.timestamp, crcSupported);
      updateProgress(35 + ((index + 1) / moves.length) * 60);
      await waitForProgressPaint();
    }

    for (const target of validateTargets) {
      const status = await appValidate(target);
      if (status !== 0 && !APP_STATUS_INCOMPATIBLE.has(status)) throw new Error(appStatusText(status));
    }
    updateProgress(100);
    refreshNeeded = true;
    log(t(doneKey), 'success');
  } catch (e) {
    refreshNeeded = storageTouched;
    log(t('appsError', e?.message ?? String(e)), 'error');
  } finally {
    if (progressContainer) progressContainer.style.display = 'none';
    await finishAppOperation(op);
    if (refreshNeeded) await appRefreshFlow();
  }
}

async function appApplyOrderFlow() {
  if (!appCanReorder()) return;
  const moves = appOrderMoves();
  if (!moves.length) return;
  await appRewriteOrderFlow(
    moves,
    [...new Set(moves.map(move => move.target))],
    'apps-reorder',
    'appOrderDone'
  );
}

async function appRenumberFlow() {
  if (!appCanRenumber()) return;
  const moves = appRenumberMoves();
  await appRewriteOrderFlow(
    moves,
    Array.from({ length: appOrderBaseline.length }, (_, slot) => slot),
    'apps-renumber',
    'appRenumberDone'
  );
}

function updateAppButtons() {
  const busy = appUpdateDownloadPending || Boolean(activeOperationToken);
  const orderDirty = appOrderIsDirty();
  const inventoryReady = appSlotStatuses.size === appActiveSlotCount;
  const installed = inventoryReady && [...appSlotStatuses.values()].some(status => status === 0);
  if (appInstallBtn) appInstallBtn.disabled = !serialSupported || busy || orderDirty || !appImage || appSlotStatuses.size !== appActiveSlotCount;
  if (appRefreshBtn) appRefreshBtn.disabled = !serialSupported || busy || orderDirty;
  if (appDeleteAllBtn) appDeleteAllBtn.disabled = !serialSupported || busy || orderDirty || !installed;
  if (appsTableBody) {
    appsTableBody.querySelectorAll('.app-act-delete').forEach(button => {
      button.disabled = busy || orderDirty || !button.closest('tr')?.dataset.appName;
    });
    appRefreshUpdateIndicators();
  }
  appUpdateOrderControls();
}

function clearAppImage() {
  appImage = null;
  appMeta = { name: '', version: '', codeSize: 0, assetSize: 0 };
  if (appFileName) { appFileName.setAttribute('data-i18n', 'fileNoFile'); appFileName.textContent = t('fileNoFile'); appFileName.classList.remove('has-file'); }
  if (appFileLabel) appFileLabel.classList.remove('has-file');
  if (appMetaEl) appMetaEl.textContent = '';
  updateAppButtons();
}

function beginAppImageLoad(source) {
  const seq = ++appImageLoadSeq;
  if (appImageLoadAbort) {
    try { appImageLoadAbort.abort(); } catch (e) {}
    appImageLoadAbort = null;
  }
  clearAppImage();
  if (source === 'catalog' && appFileInput) appFileInput.value = '';
  window.dispatchEvent(new CustomEvent('uvstudio:appselect', { detail: { source } }));
  return seq;
}

function setAppImageBuffer(buf, name) {
  const bytes = new Uint8Array(buf);
  if (bytes.length <= APP_HDR_SIZE) { log(t('appBadFile'), 'error'); clearAppImage(); return false; }
  const hdr = appParseHeader(bytes);
  if (hdr.magic !== APP_MAGIC) { log(t('appBadFile'), 'error'); clearAppImage(); return false; }
  appImage = bytes;
  appMeta = { name: hdr.name, version: hdr.version, codeSize: hdr.codeSize, assetSize: hdr.assetSize };
  if (appFileName) { appFileName.removeAttribute('data-i18n'); appFileName.textContent = name; appFileName.classList.add('has-file'); }
  if (appFileLabel) appFileLabel.classList.add('has-file');
  if (appMetaEl) appMetaEl.textContent = t('appDetected', hdr.name || '?', hdr.version || '?', (hdr.codeSize / 1024).toFixed(1));
  updateAppButtons();
  return true;
}

async function sha256Hex(buffer) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', buffer));
  return Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('');
}

// expectedSha256: a community app must be the very file its catalog entry
// describes (raw.githubusercontent.com caches files and the manifest apart).
async function loadAppFromURL(url, catalogName = 'application.app', expectedSha256 = '') {
  const seq = beginAppImageLoad('catalog');
  const controller = new AbortController();
  appImageLoadAbort = controller;
  try {
    const urlObj = new URL(url);
    // blob: is a file of the developer's local build folder, read by this page.
    if (urlObj.protocol !== 'https:' && urlObj.protocol !== 'blob:') throw new Error('HTTPS required');
    const response = await fetch(urlObj.toString(), {
      cache: 'no-cache',
      mode: 'cors',
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const buf = await response.arrayBuffer();
    if (seq !== appImageLoadSeq) return false;
    if (expectedSha256 && await sha256Hex(buf) !== expectedSha256) {
      log(t('appCommunityHashMismatch'), 'error');
      if (seq === appImageLoadSeq) clearAppImage();
      return false;
    }
    if (seq !== appImageLoadSeq) return false;
    const filename = catalogName || urlObj.pathname.split('/').pop() || 'application.app';
    return setAppImageBuffer(buf, filename);
  } catch (error) {
    if (error && error.name === 'AbortError') return false;
    log(t('appsError', error?.message ?? String(error)), 'error');
    if (seq === appImageLoadSeq) clearAppImage();
    return false;
  } finally {
    if (appImageLoadAbort === controller) appImageLoadAbort = null;
  }
}

async function installAppFromURL(url, catalogName = 'application.app', options = {}) {
  if (appOrderIsDirty()) {
    log(t('appOrderApplyFirst'), 'error');
    return false;
  }
  if (appSlotStatuses.size !== appActiveSlotCount || ![...appSlotStatuses.values()].some(status => status === 2)) {
    log(t('appManagerNoFreeSlot'), 'error');
    return false;
  }
  const loaded = await loadAppFromURL(url, catalogName, options.sha256);
  if (!loaded) return false;
  appSelectFirstEmptySlot();
  await appInstallFlow(options);
  return true;
}

async function updateAppFromURL(slot, url, catalogName = 'application.app', options = {}) {
  if (!Number.isInteger(slot) || appSlotStatuses.get(slot) !== 0) return false;
  if (appOrderIsDirty()) {
    log(t('appOrderApplyFirst'), 'error');
    return false;
  }
  if (appUpdateDownloadPending || activeOperationToken) return false;

  appUpdateDownloadPending = true;
  updateAppButtons();
  try {
    const loaded = await loadAppFromURL(url, catalogName, options.sha256);
    if (!loaded) return false;
    if (appTargetSelect) appTargetSelect.value = String(slot);
    await appInstallFlow(options);
    return true;
  } finally {
    appUpdateDownloadPending = false;
    updateAppButtons();
  }
}

async function deleteAppSlot(slot) {
  if (!Number.isInteger(slot) || appSlotStatuses.get(slot) !== 0) return false;
  await appDeleteFlow(slot);
  return true;
}

async function appUpdateFlow(slot) {
  const row = appsTableBody?.querySelector(`tr[data-slot="${slot}"]`);
  const latest = row?.dataset.appName ? appLatestAvailable(row) : null;
  if (!latest?.url || appUpdateDownloadPending || activeOperationToken) return;

  appUpdateDownloadPending = true;
  updateAppButtons();
  try {
    const loaded = await loadAppFromURL(latest.url, latest.filename || `${latest.name}.app`, latest.sha256 || '');
    if (!loaded) return;
    if (appTargetSelect) appTargetSelect.value = String(slot);
    await appInstallFlow();
  } finally {
    appUpdateDownloadPending = false;
    updateAppButtons();
  }
}

if (appFileInput) {
  appFileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const seq = beginAppImageLoad('local');
    const fr = new FileReader();
    fr.onload = (ev) => {
      if (seq === appImageLoadSeq) setAppImageBuffer(ev.target.result, file.name);
    };
    fr.readAsArrayBuffer(file);
  });
}
if (appInstallBtn) appInstallBtn.addEventListener('click', () => { void appInstallFlow(); });
if (appRefreshBtn) appRefreshBtn.addEventListener('click', () => { void appRefreshFlow(); });
if (appDeleteAllBtn) appDeleteAllBtn.addEventListener('click', () => { void appDeleteAllFlow(); });
if (appRenumberBtn) appRenumberBtn.addEventListener('click', () => { void appRenumberFlow(); });
if (appOrderApplyBtn) appOrderApplyBtn.addEventListener('click', () => { void appApplyOrderFlow(); });
if (appOrderCancelBtn) appOrderCancelBtn.addEventListener('click', appCancelOrder);
if (appInstalledTab) appInstalledTab.addEventListener('click', () => appManagerSelectPanel('installed'));
// A pending order belongs to the Installed list: settle it there first.
[[appCatalogTab, 'catalog'], [appCommunityTab, 'community']].forEach(([tab, name]) => {
  if (tab) tab.addEventListener('click', () => {
    if (appOrderIsDirty()) {
      if (appOrderNotice) appOrderNotice.hidden = false;
      return;
    }
    appManagerSelectPanel(name);
  });
});
appBuildTable();
appResetOrder();
appUpdateManagerSummary();

// Refresh the app list on entering the Apps view once the shared runtime
// connection requested by the Studio shell is ready.
window.addEventListener('uvstudio:toolviewchange', event => {
  const nextView = event.detail?.view || 'flash';
  if (nextView === 'apps') {
    updateAppButtons();
    if (port && toolsSerial.isOwner()) void appRefreshFlow();
  }
});
window.addEventListener('uvstudio:appcatalogversions', event => {
  const apps = Array.isArray(event.detail?.apps) ? event.detail.apps : [];
  appLatestVersions = new Map(apps
    .filter(app => app && app.name && app.version)
    .map(app => [appCatalogKey(app.name), app]));
  appRefreshUpdateIndicators();
});
window.addEventListener('uvstudio:appcommunity', event => {
  const apps = Array.isArray(event.detail?.apps) ? event.detail.apps : [];
  appCommunityApps = new Map(apps
    .filter(app => app && app.name && app.version && app.url)
    .map(app => [appCatalogKey(app.name), app]));
  appRefreshUpdateIndicators();
});
window.addEventListener('uvstudio:appcatalogcompatibility', event => {
  if (String(event.detail?.firmwareVersion || '') !== appCurrentFirmwareVersion) return;
  const apps = Array.isArray(event.detail?.apps) ? event.detail.apps : [];
  appCompatibilityKnown = event.detail?.found === true;
  if (appManagerCompatibility) {
    appManagerCompatibility.textContent = appCompatibilityKnown
      ? t('appManagerCatalogCompatible')
      : t('appManagerCatalogUnavailable');
  }
  appCompatibleVersions = new Map(apps
    .filter(app => app && app.name && app.version)
    .map(app => [appCatalogKey(app.name), app]));
  appRefreshUpdateIndicators();
});
window.addEventListener('uvstudio:languagechange', () => {
  if (appsTableBody) appsTableBody.querySelectorAll('.app-act-delete').forEach(b => setTableActionIcon(b, 'delete', t('appDelete')));
  if (appImage && appMetaEl) appMetaEl.textContent = t('appDetected', appMeta.name || '?', appMeta.version || '?', (appMeta.codeSize / 1024).toFixed(1));
  appUpdateManagerSummary();
  appRefreshUpdateIndicators();
  appUpdateOrderControls();
});

// ========== CAPABILITY CHECK ==========
if (!('serial' in navigator)) {
  log(t('webSerialNotSupported'), 'error');
  updateActionButtons();
}

updateActionButtons();

})();
